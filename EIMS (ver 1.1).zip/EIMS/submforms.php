<?php
// Start session to store messages
session_start();
ob_start();  // Start output buffering

// Include the database connection file
include_once "dbconnect.php";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve data from the form
    $firstname = $_POST['firstname'];
    $middleinitial = $_POST['middleinitial'];
    $lastname = $_POST['lastname'];
    $yearlvl = $_POST['yearlvl'];
    $course = $_POST['course'];
    $studidnum = $_POST['studidnum'];
    $email = $_POST['email'];
    $nameofgrdn = $_POST['nameofgrdn'];
    $address = $_POST['address'];
    $cpnnumber = $_POST['cpnnumber'];
    $consent = isset($_POST['consent']) ? 1 : 0; // Set consent to 1 if checked

    // Handle file uploads (ID Photo, Registration Form, Signature)
    $idphoto = $_FILES['idphoto']['name'];
    $regform = $_FILES['regform']['name'];
    $signature = $_FILES['signature']['name'];

    // Define the target directory for file uploads
    $targetDir = "uploads/";
    
    // Move uploaded files to the target directory
    move_uploaded_file($_FILES['idphoto']['tmp_name'], $targetDir . $idphoto);
    move_uploaded_file($_FILES['regform']['tmp_name'], $targetDir . $regform);
    move_uploaded_file($_FILES['signature']['tmp_name'], $targetDir . $signature);

    // Insert data into the database
    $sql = "INSERT INTO students_info (firstname, middleinitial, lastname, yearlevel, course, studidnum, email, nameofgrdn, address, cpnnumber, consent, idphoto, regform, signature, submission_date)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssisssssss", $firstname, $middleinitial, $lastname, $yearlvl, $course, $studidnum, $email, $nameofgrdn, $address, $cpnnumber, $consent, $idphoto, $regform, $signature);
    $stmt->execute();

    // Check for success and set a session message
    if ($stmt->affected_rows > 0) {
        $_SESSION['message'] = "Submission successful!";
    } else {
        $_SESSION['message'] = "Submission failed. Please try again.";
    }

    // Redirect to the same page to avoid form resubmission
    header("Location: submforms.php");
    exit();
}

// Fetch existing submissions (if needed)
$sql = "SELECT * FROM students_info";
$result = $conn->query($sql);
ob_end_flush(); // Flush output buffer
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="istyle.css">
    <title>AdminHub</title>
</head>
<body data-page="submforms">

<!-- SIDEBAR -->
<section id="sidebar">
		<a href="#" class="brand">
			<i class='bx bxs-face'></i>
			<span class="text">BIPS</span>
		</a>
		<ul class="side-menu top">
			<li class="active">
				<a href="index.html">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Dashboard</span>
				</a>
			</li>
			<li>
				<a href="adminmng.php">
					<i class='bx bx-group' ></i>
					<span class="text">Admin Management</span>
				</a>
			</li>
			<li>
				<a href="submforms.php">
					<i class='bx bx-clipboard'></i>
					<span class="text">Submission Forms</span>
				</a>
			</li>
			<li>
				<a href="idgen.php">
					<i class='bx bxs-id-card'></i>
					<span class="text">ID Generation</span>
				</a>
			</li>
		</ul>
		<ul class="side-menu">
			<li>
				<a href="login.php" class="logout">
					<i class='bx bxs-log-out' ></i>
					<span class="text">Logout</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->


    <!-- CONTENT -->
    <section id="content">
        <nav>
            <i class='bx bx-menu'></i>
            <a href="#" class="nav-link">Categories</a>
            <form action="#">
                <div class="form-input">
                    <input type="search" placeholder="Search...">
                    <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
                </div>
            </form>
            <input type="checkbox" id="switch-mode" hidden>
            <label for="switch-mode" class="switch-mode"></label>
            <a href="#" class="notification">
                <i class='bx bxs-bell'></i>
                <span class="num">8</span>
            </a>
            <a href="#" class="profile">
                <img src="img/people.png">
            </a>
        </nav>

        <main>
            <div class="head-title">
                <div class="left">
                    <h1>Submission Forms</h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="">Submission Forms</a>
                        </li>
                        <li><i class='bx bx-chevron-right'></i></li>
                        <li>
                            <a class="active" href="submforms.php">Form</a>
                        </li>
                    </ul>
                </div>
                <a href="#" class="btn-download" onclick="copyFormLink()">
    <i class='bx bx-copy'></i>
    <span class="text">Copy Form Link</span>
</a>
            </div>

            <div class="table-data">
            <div class="order">
        <div class="head">
            <h3>Submission Forms</h3>
            <i class='bx bx-search'></i>
            <i class='bx bx-filter'></i>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Student's Name</th>
                    <th>Date Submitted</th> <!-- Add this header for submission date -->
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
            <?php if ($result->num_rows > 0): ?>
                            <?php while ($row = $result->fetch_assoc()): ?>
                                <tr data-id="<?php echo $row['id']; ?>" class="student-row">
                                    <td><?php echo htmlspecialchars($row['firstname']) . " " . htmlspecialchars($row['lastname']); ?></td>
                                    <td><?php echo htmlspecialchars($row['submission_date'] ?? 'Not submitted'); ?></td>
                                    <td id="status-<?php echo $row['id']; ?>"><?php echo $row['status']; ?></td> <!-- Display current status -->
                                </tr>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
                <div class="todo">
                    <div class="head">
                        <h3>Student ID Information Form</h3>
                    </div>
                    <form id="studentDetailsForm" action="submforms.php" method="POST" enctype="multipart/form-data">
                        <input type="hidden" id="subforms" name="id">
                        
                        <div class="form-group">
                            <label for="firstname">First Name</label>
                            <div class="input-group">
                                <input type="text" id="firstname" name="firstname" placeholder="First Name" required>
                                <i class='bx bx-user'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="middleinitial">Middle Initial</label>
                            <div class="input-group">
                                <input type="text" id="middleinitial" name="middleinitial" placeholder="Middle Initial" required>
                                <i class='bx bx-user'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="lastname">Last Name</label>
                            <div class="input-group">
                                <input type="text" id="lastname" name="lastname" placeholder="Last Name" required>
                                <i class='bx bx-user'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="yearlvl">Year Level</label>
                            <div class="input-group">
                                <select id="yearlvl" name="yearlvl" required>
                                    <option value="" disabled selected>Select Year Level</option>
                                    <option value="firstyr">1st Year</option>
                                    <option value="secondyr">2nd Year</option>
                                    <option value="thirdyr">3rd Year</option>
                                    <option value="fourthyr">4th Year</option>
                                </select>
                                <i class='bx bx-chevron-down'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="course">Course</label>
                            <div class="input-group">
                                <select id="course" name="course" required>
                                    <option value="" disabled selected>Select Course</option>
                                    <option value="beed">Bachelor of Elementary Education (BEED)</option>
                                    <option value="bsede">Bachelor of Secondary Education (BSED) Major in English</option>
                                    <option value="bsedf">Bachelor of Secondary Education (BSED) Major in Filipino</option>
                                    <option value="bsedm">Bachelor of Secondary Education (BSED) Major in Mathematics</option>
                                    <option value="bseds">Bachelor of Secondary Education (BSED) Major in Science</option>
                                    <option value="bsedss">Bachelor of Secondary Education (BSED) Major in Social Studies</option>
                                    <option value="bsedv">Bachelor of Secondary Education (BSED) Major in Values Education</option>
                                    <option value="bsis">Bachelor of Science in Information Systems (BSIS)</option>
                                    <option value="bsbahrm">Bachelor of Science in Business Administration (BSBA) Major in Human Resource Management</option>
                                    <option value="bsbafm">Bachelor of Science in Business Administration (BSBA) Major in Financial Management</option>
                                    <option value="bsa">Bachelor of Science in Accountancy (BSA)</option>
									<option value="bsais">Bachelor of Science in Accounting Information Systems (BSAIS)</option>
									<option value="ccnt">Certificate of Computer and Network Technology (CCNT)</option>
									<option value="chrm">Certificate in Hotel and Restaurant Management (CHRM)</option>
                                </select>
                                <i class='bx bx-chevron-down'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="studidnum">Student ID Number</label>
                            <div class="input-group">
                                <input type="text" id="studidnum" name="studidnum" placeholder="Student ID Number" required>
                                <i class='bx bx-id-card'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="email">Email</label>
                            <div class="input-group">
                                <input type="email" id="email" name="email" placeholder="Email" required>
                                <i class='bx bx-envelope'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="nameofgrdn">Name of Guardian</label>
                            <div class="input-group">
                                <input type="text" id="nameofgrdn" name="nameofgrdn" placeholder="Guardian's Name" required>
                                <i class='bx bx-user'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="address">Address</label>
                            <div class="input-group">
                                <input type="text" id="address" name="address" placeholder="Address" required>
                                <i class='bx bx-map'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="cpnnumber">Contact Number</label>
                            <div class="input-group">
                                <input type="text" id="cpnnumber" name="cpnnumber" placeholder="Contact Number" required>
                                <i class='bx bx-phone'></i>
                            </div>
                        </div>

                        <div class="form-group">
    <label for="idphoto">Attach your ID Photo</label>
    <div class="upload-container">
        <div class="upload-preview">
            <img id="idphoto-preview" src="#" alt="ID Photo" style="display:none;">
        </div>
        <label for="idphoto" class="upload-box">
            <div class="upload-icon">
                <i class='bx bx-cloud-upload'></i>
                <p>Upload Image</p>
                <p class="file-size-note">Image size must be less than 2MB</p>
            </div>
        </label>
        <input type="file" id="idphoto" name="idphoto" style="display: none;" onchange="previewImage(event, 'idphoto-preview')">
    </div>
</div>

<div class="form-group">
    <label for="regform">Attach photo of your Registration Form</label>
    <div class="upload-container">
        <div class="upload-preview">
            <img id="regform-preview" src="#" alt="Registration Form" style="display:none;">
        </div>
        <label for="regform" class="upload-box">
            <div class="upload-icon">
                <i class='bx bx-cloud-upload'></i>
                <p>Upload Image</p>
                <p class="file-size-note">Image size must be less than 2MB</p>
            </div>
        </label>
        <input type="file" id="regform" name="regform" style="display: none;" onchange="previewImage(event, 'regform-preview')">
    </div>
</div>

<div class="form-group">
    <label for="signature">Attach photo of your Signature</label>
    <div class="upload-container">
        <div class="upload-preview">
            <img id="signature-preview" src="#" alt="Signature" style="display:none;">
        </div>
        <label for="signature" class="upload-box">
            <div class="upload-icon">
                <i class='bx bx-cloud-upload'></i>
                <p>Upload Image</p>
                <p class="file-size-note">Image size must be less than 2MB</p>
            </div>
        </label>
        <input type="file" id="signature" name="signature" style="display: none;" onchange="previewImage(event, 'signature-preview')">
    </div>
</div>



                        <!-- Consent Checkbox -->
						<div class="form-group">
							<label class="checkbox-container">
								<input type="checkbox" id="consent" name="consent" required>
								<span>I confirm that all the information provided in this form is accurate and correct, and I consent to sharing my data for ID card creation.</span>
							</label>
						</div>

                        <button type="button" class="btn-accept" data-id="<?php echo $row['id']; ?>" onclick="updateStatus(<?php echo $row['id']; ?>, 'accepted')">Accept</button>
                        <button type="button" class="btn-reject" data-id="<?php echo $row['id']; ?>" onclick="updateStatus(<?php echo $row['id']; ?>, 'rejected')">Reject</button>


                    </form>
                </div>
            </div>
        </main>
    </section>

    <script>
document.addEventListener("DOMContentLoaded", () => {
    const rows = document.querySelectorAll(".student-row");

    rows.forEach(row => {
        row.addEventListener("click", function () {
            const studentId = this.getAttribute("data-id");
            console.log("Selected row ID:", studentId);  // Log the selected ID to the console

            // Fetch the student data based on the ID
            fetch(`fetch_student_info.php?id=${studentId}`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error("Failed to fetch student data");
                    }
                    return response.json(); 
                })
                .then(data => {
                    if (data.error) {
                        console.error(data.error);  
                    } else {
                        // Populate form fields with the fetched data
                        document.getElementById("firstname").value = data.firstname;
                        document.getElementById("middleinitial").value = data.middleinitial;
                        document.getElementById("lastname").value = data.lastname;
                        document.getElementById("yearlvl").value = data.yearlvl;
                        document.getElementById("course").value = data.course;
                        document.getElementById("studidnum").value = data.studidnum;
                        document.getElementById("email").value = data.email;
                        document.getElementById("nameofgrdn").value = data.nameofgrdn;
                        document.getElementById("address").value = data.address;
                        document.getElementById("cpnnumber").value = data.cpnnumber;

                        // Set hidden ID field
                        document.getElementById("subforms").value = data.id; // Ensure ID is set here

                         // Update preview images
                         if (data.idphoto) {
                            const idPhotoPreview = document.getElementById("idphoto-preview");
                            idPhotoPreview.src = `data:image/jpeg;base64,${data.idphoto}`;
                            idPhotoPreview.style.display = "block";
                        }
                        if (data.regform) {
                            const regFormPreview = document.getElementById("regform-preview");
                            regFormPreview.src = `data:image/jpeg;base64,${data.regform}`;
                            regFormPreview.style.display = "block";
                        }
                        if (data.signature) {
                            const signaturePreview = document.getElementById("signature-preview");
                            signaturePreview.src = `data:image/jpeg;base64,${data.signature}`;
                            signaturePreview.style.display = "block";
                        }

                        // Set consent checkbox based on the data
                        document.getElementById("consent").checked = data.consent == 1;
                    // Attach Accept and Reject event listeners dynamically with the correct ID
                    const acceptButton = document.querySelector(".btn-accept");
                        const rejectButton = document.querySelector(".btn-reject");

                        acceptButton.onclick = () => updateStatus(data.id, "accepted");
                        rejectButton.onclick = () => updateStatus(data.id, "rejected");
                    }
                })
                .catch(error => console.error("Error fetching student data:", error));
        });
    });

    function updateStatus(id, status) {
    fetch('update_status.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ id: id, status: status })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Status updated successfully!');
            // Optionally refresh the table or update it dynamically
            location.reload(); // This will refresh the page
        } else {
            alert('Failed to update status: ' + data.error);
        }
    })
    .catch((error) => {
        console.error('Error:', error);
    });
}

    function copyFormLink() {
    const formLink = "http://localhost/Try%20Lang/form.php";
    navigator.clipboard.writeText(formLink)
        .then(() => alert("Form link copied to clipboard!"))
        .catch(err => console.error("Failed to copy link: ", err));
}

// Attach to the global window object
window.copyFormLink = copyFormLink;

});

</script>

<script src="script.js"></script>
</body>
</html>
