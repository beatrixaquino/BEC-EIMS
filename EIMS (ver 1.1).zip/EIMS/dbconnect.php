<?php

$servername = "localhost";
$username = "root";
$password = "BEC123";
$db = "my_database";
$port = 3307; // Updated port number

// Correct the variable names in the mysqli_connect function
$conn = mysqli_connect($servername, $username, $password, $db, $port);

if(!$conn) {
    die("Connection Failed: ".mysqli_connect_error());
}
?>