<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Include the database connection
include_once "dbconnect.php";

// Check if the 'id' is passed via GET request
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);  // Convert the id to an integer to prevent SQL injection

    // Prepare the SQL query to fetch the student data
    $sql = "SELECT firstname, middleinitial, lastname, yearlvl, course, studidnum, email, nameofgrdn, address, cpnnumber, 
            idphoto, regform, signature, consent
            FROM students_info WHERE id = ?";
    $stmt = $conn->prepare($sql);
    
    // Check if the query preparation was successful
    if ($stmt === false) {
        echo json_encode(["error" => "Failed to prepare the query: " . $conn->error]);
        exit();
    }

    // Bind the parameter for the query
    $stmt->bind_param("i", $id);

    // Execute the query
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if there is a row with the student data
    if ($result->num_rows > 0) {
        // Fetch the data
        $data = $result->fetch_assoc();

        // Base64 encode the BLOB fields if they exist
        if (isset($data['idphoto']) && !empty($data['idphoto'])) {
            $data['idphoto'] = base64_encode($data['idphoto']); // Encode the ID photo BLOB
        }
        if (isset($data['regform']) && !empty($data['regform'])) {
            $data['regform'] = base64_encode($data['regform']); // Encode the Registration Form BLOB
        }
        if (isset($data['signature']) && !empty($data['signature'])) {
            $data['signature'] = base64_encode($data['signature']); // Encode the Signature BLOB
        }

        // Return the student data as a JSON response
        echo json_encode($data);
    } else {
        // If no student data found, return an error message
        echo json_encode(["error" => "No data found"]);
    }

    // Close the prepared statement
    $stmt->close();
} else {
    // Return an error if the 'id' parameter is missing
    echo json_encode(["error" => "No student ID provided"]);
}

// Close the database connection
$conn->close();
?>

