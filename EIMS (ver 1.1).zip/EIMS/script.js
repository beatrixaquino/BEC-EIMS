document.addEventListener('DOMContentLoaded', function () {
    // Existing script: Sidebar functionality
    const allSideMenu = document.querySelectorAll('#sidebar .side-menu.top li a');

    // Get the current page from the body 'data-page' attribute
    let currentPage = document.body.getAttribute('data-page');

    // Handle index.html as the dashboard page
    if (currentPage === 'index' || currentPage === 'dashboard') {
        currentPage = 'index';  // Treat dashboard as 'index'
    }

    // Set up sidebar active class
    allSideMenu.forEach(item => {
        const li = item.parentElement;
        const pageName = item.getAttribute("href").split("/").pop().split(".")[0];
        
        // Handle index.html as dashboard
        if (pageName === 'index' && currentPage === 'index') {
            li.classList.add('active');
        } else if (pageName !== 'index' && pageName === currentPage) {
            li.classList.add('active');
        } else {
            li.classList.remove('active');
        }

        // Add click event to update the active class
        item.addEventListener('click', function () {
            allSideMenu.forEach(i => {
                i.parentElement.classList.remove('active');
            });
            li.classList.add('active');
        });
    });

    // Toggle sidebar functionality
    const menuBar = document.querySelector('#content nav .bx.bx-menu');
    const sidebar = document.getElementById('sidebar');

    if (menuBar) {
        menuBar.addEventListener('click', function () {
            sidebar.classList.toggle('hide');
        });
    } else {
        console.error('Sidebar toggle element (bx bx-menu) not found.');
    }

    // Search functionality
    const searchButton = document.querySelector('#content nav form .form-input button');
    const searchButtonIcon = document.querySelector('#content nav form .form-input button .bx');
    const searchForm = document.querySelector('#content nav form');

    searchButton.addEventListener('click', function (e) {
        if (window.innerWidth < 576) {
            e.preventDefault();
            searchForm.classList.toggle('show');
            if (searchForm.classList.contains('show')) {
                searchButtonIcon.classList.replace('bx-search', 'bx-x');
            } else {
                searchButtonIcon.classList.replace('bx-x', 'bx-search');
            }
        }
    });

    // Responsive behavior on load
    if (window.innerWidth < 768) {
        sidebar.classList.add('hide');
    } else if (window.innerWidth > 576) {
        searchButtonIcon.classList.replace('bx-x', 'bx-search');
        searchForm.classList.remove('show');
    }

    window.addEventListener('resize', function () {
        if (this.innerWidth > 576) {
            searchButtonIcon.classList.replace('bx-x', 'bx-search');
            searchForm.classList.remove('show');
        }
    });

    // Dark mode toggle
    const switchMode = document.getElementById('switch-mode');
    if (switchMode) {
        switchMode.addEventListener('change', function () {
            if (this.checked) {
                document.body.classList.add('dark');
            } else {
                document.body.classList.remove('dark');
            }
        });
    }

    // Log the page loaded and check current page
    console.log("Page loaded. Current page:", currentPage);

    // Define the editAdmin function
    window.editAdmin = function(button) {
        console.log("Edit button clicked.");  // Log to confirm button click

        // Get data attributes from the clicked button
        const id = button.getAttribute('data-id');
        const username = button.getAttribute('data-username');
        const password = button.getAttribute('data-password');
        const acctype = button.getAttribute('data-acctype');

        // Debugging: Log the values to check if they are being captured correctly
        console.log("Admin ID:", id);
        console.log("Username:", username);
        console.log("Password:", password);
        console.log("Account Type:", acctype);

        // Populate the form fields with the clicked admin's details
        document.getElementById('username').value = username;
        document.getElementById('password').value = password; 
        document.getElementById('acctype').value = acctype;

        // Add hidden input field to store the ID of the admin being edited
        let hiddenIdField = document.getElementById('admin-id');
        if (!hiddenIdField) {
            hiddenIdField = document.createElement('input');
            hiddenIdField.type = 'hidden';
            hiddenIdField.id = 'admin-id';
            hiddenIdField.name = 'id';
            document.querySelector('form').appendChild(hiddenIdField);
        }
        hiddenIdField.value = id;

        // Confirm hidden ID field value for debugging
        console.log("Hidden ID Field Value:", hiddenIdField.value);
    };

    // Check if the current page is 'usermng' before setting up editAdmin
    if (currentPage === 'usermng') {
        console.log("Setting up editAdmin for admin management page.");

        // Attach event listeners to each edit button
        document.querySelectorAll('.btn-edit').forEach(button => {
            button.addEventListener('click', function () {
                console.log("Edit button was clicked on item with ID:", button.getAttribute('data-id'));
                editAdmin(button); // Call the editAdmin function
            });
        });
    } else {
        console.log("Current page is not 'usermng', editAdmin not set up.");
    }
});