<?php
session_start();
include_once "dbconnect.php";

// Get dashboard statistics
$stats = [];

// Count active users
$user_sql = "SELECT COUNT(*) as count FROM users WHERE status = 'active'";
$user_result = $conn->query($user_sql);
$stats['active_users'] = $user_result->fetch_assoc()['count'];

// Count pending requests
$pending_sql = "SELECT COUNT(*) as count FROM borrowers WHERE status = 'pending'";
$pending_result = $conn->query($pending_sql);
$stats['pending_requests'] = $pending_result->fetch_assoc()['count'];

// Count approved forms
$approved_sql = "SELECT COUNT(*) as count FROM borrowers WHERE status = 'approved'";
$approved_result = $conn->query($approved_sql);
$stats['approved_forms'] = $approved_result->fetch_assoc()['count'];

// Count returned items
$returned_sql = "SELECT COUNT(*) as count FROM borrowers WHERE status = 'returned'";
$returned_result = $conn->query($returned_sql);
$stats['returned_items'] = $returned_result->fetch_assoc()['count'];

// Get recent borrower forms for the table
$recent_forms_sql = "SELECT * FROM borrowers ORDER BY created_at DESC LIMIT 5";
$recent_forms_result = $conn->query($recent_forms_sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->
	<link rel="stylesheet" href="istyle.css">

	<title>Superadmin Hub</title>
</head>
<body data-page="dashboard_superadmin">


	<!-- SIDEBAR -->
	<section id="sidebar">
		<a href="#" class="brand">
			<i class='bx bxs-package' ></i>
			<span class="text">BEC EIMS</span>
		</a>
		<ul class="side-menu top">
			<li class="active">
				<a href="dashboard_superadmin.php">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Dashboard</span>
				</a>
			</li>
			<li>
				<a href="usermng.php">
					<i class='bx bx-group' ></i>
					<span class="text">User Management</span>
				</a>
			</li>
			<li>
				<a href="borrowform.php">
					<i class='bx bx-clipboard'></i>
					<span class="text">Borrowers Forms</span>
				</a>
			</li>
			<li>
				<a href="equiplist.php">
                <i class='bx bxs-wrench' ></i>
					<span class="text">Equipment List</span>
				</a>
			</li>
		</ul>
		<ul class="side-menu">
			<li>
				<a href="login.php" class="logout">
					<i class='bx bxs-log-out' ></i>
					<span class="text">Logout</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->



	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu' ></i>
			<a href="#" class="nav-link">Categories</a>
			<form action="#">
				<div class="form-input">
					<input type="search" placeholder="Search...">
					<button type="submit" class="search-btn"><i class='bx bx-search' ></i></button>
				</div>
			</form>
			<input type="checkbox" id="switch-mode" hidden>
			<label for="switch-mode" class="switch-mode"></label>
			<a href="#" class="notification" id="notificationIcon">
				<i class='bx bxs-bell' ></i>
				<span class="num" id="notificationCount">0</span>
			</a>
			<div class="notification-dropdown" id="notificationDropdown" style="display: none;">
				<div class="notification-header">
					<h4>Notifications</h4>
					<button id="markAllRead" class="mark-all-read">Mark all read</button>
				</div>
				<div class="notification-list" id="notificationList">
					<!-- Notifications will be loaded here -->
				</div>
			</div>
			<a href="#" class="profile">
				<img src="img/people.png">
			</a>
		</nav>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
			<div class="head-title">
				<div class="left">
					<h1>Dashboard</h1>
					<ul class="breadcrumb">
						<li>
							<a href="#">Dashboard</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="#">Home</a>
						</li>
					</ul>
				</div>
				<a href="#" class="btn-download">
					<i class='bx bxs-report'></i>
					<span class="text">Generate Report</span>
				</a>
			</div>

			<ul class="box-info">
				<a href="usermng.php" class="box-link">
				<li>
					<i class='bx bxs-user-pin'></i>
					<span class="text">
						<h3><?php echo $stats['active_users']; ?></h3>
						<p>Active Users</p>
					</span>
				</li>
				</a>
				<a href="borrowform.php?filter=pending" class="box-link">
				<li>
					<i class='bx bxs-hourglass' ></i>
					<span class="text">
						<h3><?php echo $stats['pending_requests']; ?></h3>
						<p>Pending Requests</p>
					</span>
				</li>
				</a>
				<a href="borrowform.php?filter=approved" class="box-link">
				<li>
					<i class='bx bx-check'></i>
					<span class="text">
						<h3><?php echo $stats['approved_forms']; ?></h3>
						<p>Approved Forms</p>
					</span>
				</li>
				</a>
				<a href="borrowform.php?filter=returned" class="box-link">
				<li>
					<i class='bx bx-archive-in' ></i>
					<span class="text">
						<h3><?php echo $stats['returned_items']; ?></h3>
						<p>Returned Items</p>
					</span>
				</li>
				</a>
			</ul>


			<div class="table-data">
				<div class="order">
					<div class="head">
						<h3>Submitted Borrowers Forms</h3>
						<i class='bx bx-search' ></i>
						<i class='bx bx-filter' ></i>
					</div>
					<table>
						<thead>
							<tr>
								<th>Name</th>
								<th>Department</th>
								<th>Date Submitted</th>
								<th>Status</th>
							</tr>
						</thead>
						<tbody>
							<?php if ($recent_forms_result && $recent_forms_result->num_rows > 0): ?>
								<?php while ($row = $recent_forms_result->fetch_assoc()): ?>
									<tr>
										<td>
											<img src="img/people.png">
											<p><?php echo htmlspecialchars($row['firstname'] . ' ' . $row['lastname']); ?></p>
										</td>
										<td><?php echo htmlspecialchars($row['department']); ?></td>
										<td><?php echo htmlspecialchars(date("M j, Y", strtotime($row['created_at']))); ?></td>
										<td>
											<?php 
											$status_class = '';
											switch($row['status']) {
												case 'pending':
													$status_class = 'pending';
													break;
												case 'approved':
													$status_class = 'completed';
													break;
												case 'rejected':
													$status_class = 'pending';
													break;
												case 'returned':
													$status_class = 'completed';
													break;
												default:
													$status_class = 'process';
											}
											?>
											<span class="status <?php echo $status_class; ?>"><?php echo ucfirst($row['status']); ?></span>
										</td>
									</tr>
								<?php endwhile; ?>
							<?php else: ?>
								<tr>
									<td colspan="4" style="text-align: center;">No recent forms submitted</td>
								</tr>
							<?php endif; ?>
						</tbody>
					</table>
				</div>
				<div class="todo">
					<div class="head">
						<h3>Calendar</h3>
						<i class='bx bx-plus' ></i>
						<i class='bx bx-filter' ></i>

					</div>
						<div class="calendar-controls">
            				<button id="prev-month">&lt; Previous</button>
            				<h2 id="current-month-year">Month Year</h2>
            				<button id="next-month">Next &gt;</button>
        				</div>

						<div class="calendar-grid" id="calendar-header">
            			<div class="calendar-header">Sun</div>
            			<div class="calendar-header">Mon</div>
            			<div class="calendar-header">Tue</div>
            			<div class="calendar-header">Wed</div>
            			<div class="calendar-header">Thu</div>
            			<div class="calendar-header">Fri</div>
            			<div class="calendar-header">Sat</div>
        			</div>

					<div class="calendar-grid" id="calendar-days"></div>

					<div class="modal" id="event-modal">
        				<div class="modal-content">
            				<div class="modal-header">
                				<h3 id="modal-event-title">Event Title</h3>
                				<button class="close-btn" id="close-modal">&times;</button>
            				</div>
            				<div class="event-meta">
                				<span class="event-type" id="modal-event-type">General</span>
                				<span class="event-time" id="modal-event-time">All day</span>
                				<span class="event-venue" id="modal-event-venue">Online</span>
            				</div>
            				<div class="event-details">
                				<p id="modal-event-description">Event description goes here.</p>
            				</div>
            				<div class="event-actions">
                				<button class="edit-btn">Edit</button>
                				<button class="delete-btn">Delete</button>
            				</div>
        				</div>

					</div>

    			</div>
			</div>
		</main>
		<!-- MAIN -->
	</section>
	<!-- CONTENT -->
	

	<script src="script.js"></script>
	
	<script>
		document.addEventListener("DOMContentLoaded", () => {
			// Notification functionality
			const notificationIcon = document.getElementById('notificationIcon');
			const notificationDropdown = document.getElementById('notificationDropdown');
			const notificationCount = document.getElementById('notificationCount');
			const notificationList = document.getElementById('notificationList');
			const markAllReadBtn = document.getElementById('markAllRead');

			// Load notification count
			function loadNotificationCount() {
				fetch('get_notifications.php?action=count')
					.then(response => response.json())
					.then(data => {
						if (data.count > 0) {
							notificationCount.textContent = data.count;
							notificationCount.style.display = 'block';
						} else {
							notificationCount.style.display = 'none';
						}
					})
					.catch(error => console.error('Error loading notification count:', error));
			}

			// Load notifications
			function loadNotifications() {
				fetch('get_notifications.php?action=list&limit=10')
					.then(response => response.json())
					.then(data => {
						if (data.notifications && data.notifications.length > 0) {
							let html = '';
							data.notifications.forEach(notification => {
								const isRead = notification.is_read ? 'read' : 'unread';
								const timeAgo = getTimeAgo(notification.created_at);
								html += `
									<div class="notification-item ${isRead}" data-id="${notification.id}">
										<div class="notification-content">
											<h5>${notification.title}</h5>
											<p>${notification.message}</p>
											<small>${timeAgo}</small>
										</div>
										${!notification.is_read ? '<div class="unread-indicator"></div>' : ''}
									</div>
								`;
							});
							notificationList.innerHTML = html;
						} else {
							notificationList.innerHTML = '<div class="no-notifications">No notifications</div>';
						}
					})
					.catch(error => console.error('Error loading notifications:', error));
			}

			// Get time ago
			function getTimeAgo(timestamp) {
				const now = new Date();
				const created = new Date(timestamp);
				const diffInSeconds = Math.floor((now - created) / 1000);
				
				if (diffInSeconds < 60) return 'Just now';
				if (diffInSeconds < 3600) return Math.floor(diffInSeconds / 60) + 'm ago';
				if (diffInSeconds < 86400) return Math.floor(diffInSeconds / 3600) + 'h ago';
				return Math.floor(diffInSeconds / 86400) + 'd ago';
			}

			// Toggle notification dropdown
			notificationIcon.addEventListener('click', function(e) {
				e.preventDefault();
				notificationDropdown.style.display = notificationDropdown.style.display === 'none' ? 'block' : 'none';
				if (notificationDropdown.style.display === 'block') {
					loadNotifications();
				}
			});

			// Mark all as read
			markAllReadBtn.addEventListener('click', function() {
				fetch('get_notifications.php?action=mark_all_read', {
					method: 'POST'
				})
				.then(response => response.json())
				.then(data => {
					if (data.success) {
						loadNotificationCount();
						loadNotifications();
					}
				})
				.catch(error => console.error('Error marking all as read:', error));
			});

			// Mark individual notification as read
			notificationList.addEventListener('click', function(e) {
				const notificationItem = e.target.closest('.notification-item');
				if (notificationItem && !notificationItem.classList.contains('read')) {
					const notificationId = notificationItem.getAttribute('data-id');
					fetch('get_notifications.php?action=mark_read', {
						method: 'POST',
						headers: {
							'Content-Type': 'application/x-www-form-urlencoded',
						},
						body: 'notification_id=' + notificationId
					})
					.then(response => response.json())
					.then(data => {
						if (data.success) {
							notificationItem.classList.remove('unread');
							notificationItem.classList.add('read');
							notificationItem.querySelector('.unread-indicator')?.remove();
							loadNotificationCount();
						}
					})
					.catch(error => console.error('Error marking notification as read:', error));
				}
			});

			// Close dropdown when clicking outside
			document.addEventListener('click', function(e) {
				if (!notificationIcon.contains(e.target) && !notificationDropdown.contains(e.target)) {
					notificationDropdown.style.display = 'none';
				}
			});

			// Load notification count on page load
			loadNotificationCount();

			// Refresh notification count every 30 seconds
			setInterval(loadNotificationCount, 30000);
		});
	</script>
</body>
</html>