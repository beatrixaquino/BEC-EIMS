<?php
// Start session and include DB connection
session_start();
include_once 'dbconnect.php'; // adjust if your connection file has a different name

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve data from the form
    $id = isset($_POST['id']) && !empty($_POST['id']) ? intval($_POST['id']) : null;
    $idnum = $_POST['idnum'];
    $firstname = $_POST['firstname'];
    $middleinitial = $_POST['middleinitial'];
    $lastname = $_POST['lastname'];
    $department = $_POST['department'];
    $course = $_POST['course'];
    $email = $_POST['email'];
    $cpnnumber = $_POST['cpnnumber'];
    $consent = isset($_POST['consent']) ? 1 : 0; // Set consent to 1 if checked
    $formstatus = $_POST['formstatus'];
    
    // Handle course field based on department
    if ($department === "Faculty Member") {
        $course = null; // Set course to null for faculty members
    }
    // Properly format dates for database storage
    $borrow_date = !empty($_POST['borrow_date']) ? date('Y-m-d', strtotime($_POST['borrow_date'])) : null;
    $return_date = !empty($_POST['return_date']) ? date('Y-m-d', strtotime($_POST['return_date'])) : null;

    if ($id) {
        // ✅ UPDATE existing borrower
        $sql = "UPDATE borrowers SET idnum=?, firstname=?, middleinitial=?, lastname=?, department=?, course=?, email=?, cpnnumber=?, consent=?, status=?, borrow_date=?, return_date=? WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssssssssi", $idnum, $firstname, $middleinitial, $lastname, $department, $course, $email, $cpnnumber, $consent, $formstatus, $borrow_date, $return_date, $id);
    } else {
        // ✅ INSERT new borrower
        $sql = "INSERT INTO borrowers (idnum, firstname, middleinitial, lastname, department, course, email, cpnnumber, consent, status, borrow_date, return_date)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssssssss", $idnum, $firstname, $middleinitial, $lastname, $department, $course, $email, $cpnnumber, $consent, $formstatus, $borrow_date, $return_date);
    }

    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        // Create notifications for status updates
        include_once "notification_helper.php";
        
        if ($id) {
            // Update notification for status change
            $borrower_name = $firstname . " " . $lastname;
            $status_message = "";
            $notification_type = "";
            
            switch ($formstatus) {
                case "approved":
                    $status_message = "Your borrow request has been approved!";
                    $notification_type = "form_approved";
                    break;
                case "rejected":
                    $status_message = "Your borrow request has been rejected.";
                    $notification_type = "form_rejected";
                    break;
                case "returned":
                    $status_message = "Your borrowed items have been returned successfully.";
                    $notification_type = "form_returned";
                    break;
            }
            
            if ($status_message) {
                // For now, create notification for admin to see the status change
                // Later, when user accounts are implemented, this can be sent to the specific borrower
                createNotification(
                    1, // Admin user ID - to track status changes
                    "Form Status Updated",
                    "Form for {$borrower_name} has been {$formstatus}",
                    $notification_type,
                    $id
                );
            }
        }
        
        $_SESSION['message'] = $id ? "Borrower updated successfully!" : "Submission successful!";
    } else {
        $_SESSION['message'] = "Database operation failed. Please try again.";
    }

    $stmt->close();
    header("Location: borrowform.php");
    exit();
}

// Fetch existing submissions with optional status filtering
$statusFilter = isset($_GET['filter']) ? $_GET['filter'] : null;

if ($statusFilter) {
    $stmt = $conn->prepare("SELECT * FROM borrowers WHERE status = ? ORDER BY created_at DESC");
    $stmt->bind_param("s", $statusFilter);
} else {
    $stmt = $conn->prepare("SELECT * FROM borrowers ORDER BY created_at DESC");
}

$stmt->execute();
$result = $stmt->get_result();
ob_end_flush(); // Flush output buffer
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="istyle.css">
    <style>
        #courseGroup {
            transition: opacity 0.3s ease-in-out;
        }
    </style>
    <title>Superadmin Hub</title>
</head>
<body data-page="borrowform">

<!-- SIDEBAR -->
<section id="sidebar">
		<a href="#" class="brand">
			<i class='bx bxs-package' ></i>
			<span class="text">BEC EIMS</span>
		</a>
		<ul class="side-menu top">
			<li class="active">
				<a href="dashboard_superadmin.php">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Dashboard</span>
				</a>
			</li>
			<li>
				<a href="usermng.php">
					<i class='bx bx-group' ></i>
					<span class="text">User Management</span>
				</a>
			</li>
			<li>
				<a href="borrowform.php">
					<i class='bx bxs-report'></i>
					<span class="text">Borrowers Forms</span>
				</a>
			</li>
			<li>
				<a href="equiplist.php">
					<i class='bx bxs-id-card'></i>
					<span class="text">Equipment List</span>
				</a>
			</li>
		</ul>
		<ul class="side-menu">
			<li>
				<a href="login.php" class="logout">
					<i class='bx bxs-log-out' ></i>
					<span class="text">Logout</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->


    <!-- CONTENT -->
    <section id="content">
        <nav>
            <i class='bx bx-menu'></i>
            <a href="#" class="nav-link">Categories</a>
            <form id="globalSearchForm" action="#" autocomplete="off">
                <div class="form-input">
                    <input type="search" id="globalSearchInput" placeholder="Search borrowers...">
                    <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
                </div>
            </form>
            <input type="checkbox" id="switch-mode" hidden>
            <label for="switch-mode" class="switch-mode"></label>
            <a href="#" class="notification" id="notificationIcon">
                <i class='bx bxs-bell'></i>
                <span class="num" id="notificationCount">0</span>
            </a>
            <div class="notification-dropdown" id="notificationDropdown" style="display: none;">
                <div class="notification-header">
                    <h4>Notifications</h4>
                    <button id="markAllRead" class="mark-all-read">Mark all read</button>
                </div>
                <div class="notification-list" id="notificationList">
                    <!-- Notifications will be loaded here -->
                </div>
            </div>
            <a href="#" class="profile">
                <img src="img/people.png">
            </a>
        </nav>

        <main>
                        <div class="head-title">
				<div class="left">
					<h1>
						<?php 
						$filter = $_GET['filter'] ?? '';
						if ($filter) {
							echo "Borrowers Forms - " . ucfirst($filter);
						} else {
							echo "Borrowers Forms";
						}
						?>
					</h1>
					<ul class="breadcrumb">
						<li>
							<a href="#">Borrowers Forms</a>
						</li>
						<li><i class='bx bx-chevron-right'></i></li>
						<li>
							<a class="active" href="submforms.php">
								<?php 
								if ($filter) {
									echo ucfirst($filter) . " Forms";
								} else {
									echo "Form";
								}
								?>
							</a>
						</li>
					</ul>
				</div>
                <a href="#" class="btn-download" onclick="copyFormLink()">
    <i class='bx bx-copy'></i>
    <span class="text">Generate Report</span>
</a>
            </div>

            <div class="table-data">
            <div class="order">
        <div class="head">
            <h3>Borrowers Forms</h3>
            <i class='bx bx-sort' id="sortBtn" title="Toggle Sort Order"></i>
            <i class='bx bx-filter' id="filterBtn"></i>
        </div>

        <div class="filter-group" id="filterGroup">
            <button class="filter-option" data-status="all">All</button>
            <button class="filter-option" data-status="pending">Pending</button>
            <button class="filter-option" data-status="approved">Approved</button>
            <button class="filter-option" data-status="rejected">Rejected</button>
            <button class="filter-option" data-status="returned">Returned</button>
        </div>
        <table>
    <thead>
        <tr>
            <th>Borrower's Name</th>
            <th>Date Submitted</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($result && $result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr data-id="<?php echo $row['id']; ?>" class="student-row">
                    <td><?php echo htmlspecialchars($row['firstname'] . ' ' . $row['lastname']); ?></td>
                    <td><?php echo htmlspecialchars(date("F j, Y g:i A", strtotime($row['created_at']))); ?></td>
                    <td id="status-<?php echo $row['id']; ?>"><?php echo htmlspecialchars($row['status']); ?></td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="3">No records found.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
            </div>
                <div class="todo">
                    <div class="head">
                        <h3>Tool Borrowers Form</h3>
                    </div>
                    <form id="studentDetailsForm" action="borrowform.php" method="POST" enctype="multipart/form-data">
                        <input type="hidden" id="borrowform" name="id">
                        
                        <div class="form-group">
                            <label for="idnum">ID Number</label>
                            <div class="input-group">
                                <input type="text" id="idnum" name="idnum" placeholder="ID Number" required>
                                <i class='bx bx-id-card'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="firstname">First Name</label>
                            <div class="input-group">
                                <input type="text" id="firstname" name="firstname" placeholder="First Name" required>
                                <i class='bx bx-user'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="middleinitial">Middle Initial</label>
                            <div class="input-group">
                                <input type="text" id="middleinitial" name="middleinitial" placeholder="Middle Initial" required>
                                <i class='bx bx-user'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="lastname">Last Name</label>
                            <div class="input-group">
                                <input type="text" id="lastname" name="lastname" placeholder="Last Name" required>
                                <i class='bx bx-user'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="department">Department</label>
                            <div class="input-group">
                                <select id="department" name="department" required>
                                    <option value="" disabled selected>Select Department</option>
                                    <option value="Student">Student</option>
                                    <option value="Faculty Member">Faculty Member</option>
                                </select>
                                <i class='bx bx-chevron-down'></i>
                            </div>
                        </div>

                        <div class="form-group" id="courseGroup">
                            <label for="course">Course</label>
                            <div class="input-group">
                                <select id="course" name="course" required>
                                    <option value="" disabled selected>Select Course</option>
                                    <option value="cookery">CHRM Cookery NC II</option>
                                    <option value="fbs">CHRM Food and Beverages NC II</option>
                                    <option value="fos">CHRM Front Office Services NC II</option>
                                    <option value="housekeeping">CHRM Housekeeping NC II</option>
                                    <option value="bartending">CHRM Bartending NC II</option>
                                </select>
                                <i class='bx bx-chevron-down'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="email">School Email</label>
                            <div class="input-group">
                                <input type="email" id="email" name="email" placeholder="School Email" required>
                                <i class='bx bx-envelope'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="cpnnumber">Contact Number</label>
                            <div class="input-group">
                                <input type="text" id="cpnnumber" name="cpnnumber" placeholder="Contact Number" required>
                                <i class='bx bx-phone'></i>
                            </div>
                        </div>

                        <div class="borrowed-items-card">
    <h3>Borrowed Items</h3>
    <table class="borrowed-items-table">
        <thead>
            <tr>
                <th>Item Name</th>
                <th>Quantity</th>
            </tr>
        </thead>
        <tbody id="borrowedItemsTable">
            
        </tbody>
    </table>
</div>

<div class="borrow-dates">
    <div class="form-group">
        <label for="borrow_date">Borrow Date</label>
        <div class="input-group">
            <input type="date" id="borrow_date" name="borrow_date" required>
        </div>
    </div>

    <div class="form-group">
        <label for="return_date">Return Date</label>
        <div class="input-group">
            <input type="date" id="return_date" name="return_date" required>
        </div>
    </div>
</div>

                        <!-- Consent Checkbox -->
						<div class="form-group">
							<label class="checkbox-container">
								<input type="checkbox" id="consent" name="consent" required>
								<span>I confirm that all the information I have provided is accurate and correct, and I consent to its use for processing my equipment borrowing request.</span>
							</label>
						</div>
                    
                        <div class="form-group">
                            <label for="formstatus">Form Status</label>
                            <div class="input-group">
                                <select id="formstatus" name="formstatus" required>
                                    <option value="" disabled selected>Select Status</option>
                                    <option value="pending">Pending</option>
                                    <option value="approved">Approved</option>
                                    <option value="rejected">Rejected</option>
                                    <option value="returned">Returned</option>
                                </select>
                                <i class='bx bx-chevron-down'></i>
                            </div>
                        </div>
                        

                        <button type="submit" class="btn-submit">Save Changes</button>
                        

                    </form>
                </div>
            </div>
        </main>
    </section>

    <script>
document.addEventListener("DOMContentLoaded", () => {
    // Department/Course conditional logic for superadmin form
    const departmentSelect = document.getElementById("department");
    const courseGroup = document.getElementById("courseGroup");
    const courseSelect = document.getElementById("course");

    function toggleCourseField() {
        const selectedDepartment = departmentSelect.value;
        
        if (selectedDepartment === "Faculty Member") {
            // Hide course field for faculty members
            courseGroup.style.display = "none";
            courseGroup.style.opacity = "0";
            courseSelect.removeAttribute("required");
            courseSelect.value = ""; // Clear the selection
        } else {
            // Show course field for students
            courseGroup.style.display = "block";
            courseGroup.style.opacity = "1";
            courseSelect.setAttribute("required", "required");
        }
    }

    // Add event listener for department change
    departmentSelect.addEventListener("change", toggleCourseField);

    const rows = document.querySelectorAll(".student-row");

    rows.forEach(row => {
    row.addEventListener("click", function () {
        const borrowerId = this.getAttribute("data-id");
        console.log("Selected row ID:", borrowerId);

        // Fetch the borrower data based on the ID
        fetch(`fetch_student_info.php?id=${borrowerId}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error("Failed to fetch borrower data");
                }
                return response.json();
            })
            .then(data => {
                if (data.error) {
                    console.error(data.error);
                } else {
                    console.log("Fetched data:", data);
                    // 👇 YOUR FORM FILLING LOGIC (already here)
                    document.getElementById("borrowform").value = data.id;
                    document.getElementById("idnum").value = data.idnum;
                    document.getElementById("firstname").value = data.firstname;
                    document.getElementById("middleinitial").value = data.middleinitial;
                    document.getElementById("lastname").value = data.lastname;
                    console.log("Department value from database:", data.department);
                    console.log("Department value type:", typeof data.department);
                    console.log("Department value length:", data.department ? data.department.length : 'null/undefined');
                    console.log("Department select element:", document.getElementById("department"));
                    console.log("Available department options:", Array.from(document.getElementById("department").options).map(opt => opt.value));
                    document.getElementById("department").value = data.department;
                    console.log("Department value after setting:", document.getElementById("department").value);
                    
                    // Handle course field - set to empty if null/undefined
                    if (data.course && data.course !== null && data.course !== '') {
                        document.getElementById("course").value = data.course;
                    } else {
                        document.getElementById("course").value = "";
                    }
                    document.getElementById("email").value = data.email;
                    document.getElementById("cpnnumber").value = data.cpnnumber;
                    // Handle borrow date
                    if (data.borrow_date && data.borrow_date !== "0000-00-00" && data.borrow_date !== null) {
                        document.getElementById("borrow_date").value = data.borrow_date;
                    } else {
                        document.getElementById("borrow_date").value = "";
                    }
                    
                    // Handle return date - fix the date format issue
                    if (data.return_date && data.return_date !== "0000-00-00" && data.return_date !== null) {
                        // Ensure proper date format for HTML date input (YYYY-MM-DD)
                        const returnDate = new Date(data.return_date);
                        if (!isNaN(returnDate.getTime())) {
                            document.getElementById("return_date").value = returnDate.toISOString().split('T')[0];
                        } else {
                            document.getElementById("return_date").value = "";
                        }
                    } else {
                        document.getElementById("return_date").value = "";
                    }
                    document.getElementById("consent").checked = data.consent == 1;
                    
                    // Set the form status dropdown to current status from database
                    document.getElementById("formstatus").value = data.status;

                    // ✅ 🔽 INSERT THIS HERE
                    fetch(`fetch_borrowed_items.php?form_id=${data.id}`)
                        .then(response => response.json())
                        .then(items => {
                            const tableBody = document.getElementById("borrowedItemsTable");
                            tableBody.innerHTML = ""; // Clear previous rows

                            items.forEach(item => {
                                const row = `<tr>
                                    <td>${item.item_name}</td>
                                    <td>${item.quantity} ${item.unit}</td>
                                </tr>`;
                                tableBody.insertAdjacentHTML("beforeend", row);
                            });
                        });

                    // Status update buttons removed - using form status dropdown instead
                }
            })
            .catch(error => console.error("Error fetching borrower data:", error));
    });
});


    // updateStatus function removed - status updates are now handled through the form submission

    function copyFormLink() {
        const formLink = "http://localhost/Try%20Lang/form.php";
        navigator.clipboard.writeText(formLink)
            .then(() => alert("Form link copied to clipboard!"))
            .catch(err => console.error("Failed to copy link: ", err));
    }

    window.copyFormLink = copyFormLink;

    // Filter functionality
    const filterBtn = document.getElementById("filterBtn");
    const filterGroup = document.getElementById("filterGroup");
    const filterOptions = document.querySelectorAll(".filter-option");
    const studentRows = document.querySelectorAll(".student-row");

    // Start with filter group hidden
    filterGroup.classList.add("hide");
    console.log("Initial hide class:", filterGroup.classList.contains("hide"));

    // Toggle filter group visibility
    filterBtn.addEventListener("click", function(e) {
        e.stopPropagation();
        filterGroup.classList.toggle("hide");
        console.log("Filter button clicked, hide class:", filterGroup.classList.contains("hide"));
    });

    // Hide filter group when clicking outside
    document.addEventListener("click", function(e) {
        if (!filterGroup.contains(e.target) && e.target !== filterBtn) {
            filterGroup.classList.add("hide");
        }
    });

    // Filter functionality - server-side filtering
    filterOptions.forEach(btn => {
        btn.addEventListener("click", function() {
            const status = this.getAttribute("data-status");
            
            if (status === "all") {
                window.location.href = "borrowform.php";
            } else {
                window.location.href = `borrowform.php?filter=${status}`;
            }
        });
    });

    // Auto-filter functionality when coming from dashboard
    function applyAutoFilter() {
        const urlParams = new URLSearchParams(window.location.search);
        const filterParam = urlParams.get('filter');
        
        if (filterParam) {
            // Find the corresponding filter button
            const targetButton = filterOptions.find(btn => btn.getAttribute("data-status") === filterParam);
            
            if (targetButton) {
                // Remove active class from all filter buttons
                filterOptions.forEach(b => b.classList.remove("active"));
                // Add active class to target button
                targetButton.classList.add("active");
                
                // Show the filter group
                filterGroup.classList.remove("hide");
            }
        }
    }

    // Apply auto-filter on page load - ensure DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', applyAutoFilter);
    } else {
        applyAutoFilter();
    }

    // Simple sort toggle functionality
    const sortBtn = document.getElementById('sortBtn');
    let isReversed = false; // Track current sort state

    // Toggle sort order
    sortBtn.addEventListener('click', function() {
        isReversed = !isReversed; // Toggle the state
        
        // Sort the table rows
        sortTableRows();
        
        // Update icon to show current state
        if (isReversed) {
            sortBtn.classList.add('reversed');
            sortBtn.title = "Newest First (Click to reverse)";
        } else {
            sortBtn.classList.remove('reversed');
            sortBtn.title = "Oldest First (Click to reverse)";
        }
    });

    // Function to sort table rows
    function sortTableRows() {
        const tbody = document.querySelector('.table-data .order table tbody');
        const rows = Array.from(tbody.querySelectorAll('.student-row'));
        
        rows.sort((a, b) => {
            const dateA = new Date(a.querySelector('td:nth-child(2)').textContent);
            const dateB = new Date(b.querySelector('td:nth-child(2)').textContent);
            
            if (isReversed) {
                return dateA - dateB; // Oldest first (reversed)
            } else {
                return dateB - dateA; // Newest first (normal)
            }
        });
        
        // Clear and re-append sorted rows
        rows.forEach(row => tbody.appendChild(row));
        
        console.log(`Sorted forms: ${isReversed ? 'Oldest first' : 'Newest first'}`);
    }

    // Search functionality
    const globalSearchForm = document.getElementById("globalSearchForm");
    const globalSearchInput = document.getElementById("globalSearchInput");

    if (globalSearchForm && globalSearchInput) {
        globalSearchForm.addEventListener("submit", function(e) {
            e.preventDefault();
            const query = globalSearchInput.value.trim().toLowerCase();
            
            studentRows.forEach(row => {
                const name = row.querySelector("td:first-child").textContent.toLowerCase();
                const status = row.querySelector("td:last-child").textContent.toLowerCase();
                
                if (name.includes(query) || status.includes(query)) {
                    row.style.display = "";
                } else {
                    row.style.display = "none";
                }
            });
        });

        // Live search as you type
        globalSearchInput.addEventListener("input", function() {
            const query = globalSearchInput.value.trim().toLowerCase();
            
            studentRows.forEach(row => {
                const name = row.querySelector("td:first-child").textContent.toLowerCase();
                const status = row.querySelector("td:last-child").textContent.toLowerCase();
                
                if (name.includes(query) || status.includes(query)) {
                    row.style.display = "";
                } else {
                    row.style.display = "none";
                }
            });
        });
    }

    // Notification functionality
    const notificationIcon = document.getElementById('notificationIcon');
    const notificationDropdown = document.getElementById('notificationDropdown');
    const notificationCount = document.getElementById('notificationCount');
    const notificationList = document.getElementById('notificationList');
    const markAllReadBtn = document.getElementById('markAllRead');

    // Load notification count
    function loadNotificationCount() {
        fetch('get_notifications.php?action=count')
            .then(response => response.json())
            .then(data => {
                if (data.count > 0) {
                    notificationCount.textContent = data.count;
                    notificationCount.style.display = 'block';
                } else {
                    notificationCount.style.display = 'none';
                }
            })
            .catch(error => console.error('Error loading notification count:', error));
    }

    // Load notifications
    function loadNotifications() {
        fetch('get_notifications.php?action=list&limit=10')
            .then(response => response.json())
            .then(data => {
                if (data.notifications && data.notifications.length > 0) {
                    let html = '';
                    data.notifications.forEach(notification => {
                        const isRead = notification.is_read ? 'read' : 'unread';
                        const timeAgo = getTimeAgo(notification.created_at);
                        html += `
                            <div class="notification-item ${isRead}" data-id="${notification.id}">
                                <div class="notification-content">
                                    <h5>${notification.title}</h5>
                                    <p>${notification.message}</p>
                                    <small>${timeAgo}</small>
                                </div>
                                ${!notification.is_read ? '<div class="unread-indicator"></div>' : ''}
                            </div>
                        `;
                    });
                    notificationList.innerHTML = html;
                } else {
                    notificationList.innerHTML = '<div class="no-notifications">No notifications</div>';
                }
            })
            .catch(error => console.error('Error loading notifications:', error));
    }

    // Get time ago
    function getTimeAgo(timestamp) {
        const now = new Date();
        const created = new Date(timestamp);
        const diffInSeconds = Math.floor((now - created) / 1000);
        
        if (diffInSeconds < 60) return 'Just now';
        if (diffInSeconds < 3600) return Math.floor(diffInSeconds / 60) + 'm ago';
        if (diffInSeconds < 86400) return Math.floor(diffInSeconds / 3600) + 'h ago';
        return Math.floor(diffInSeconds / 86400) + 'd ago';
    }

    // Toggle notification dropdown
    notificationIcon.addEventListener('click', function(e) {
        e.preventDefault();
        notificationDropdown.style.display = notificationDropdown.style.display === 'none' ? 'block' : 'none';
        if (notificationDropdown.style.display === 'block') {
            loadNotifications();
        }
    });

    // Mark all as read
    markAllReadBtn.addEventListener('click', function() {
        fetch('get_notifications.php?action=mark_all_read', {
            method: 'POST'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                loadNotificationCount();
                loadNotifications();
            }
        })
        .catch(error => console.error('Error marking all as read:', error));
    });

    // Mark individual notification as read
    notificationList.addEventListener('click', function(e) {
        const notificationItem = e.target.closest('.notification-item');
        if (notificationItem && !notificationItem.classList.contains('read')) {
            const notificationId = notificationItem.getAttribute('data-id');
            fetch('get_notifications.php?action=mark_read', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'notification_id=' + notificationId
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    notificationItem.classList.remove('unread');
                    notificationItem.classList.add('read');
                    notificationItem.querySelector('.unread-indicator')?.remove();
                    loadNotificationCount();
                }
            })
            .catch(error => console.error('Error marking notification as read:', error));
        }
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
        if (!notificationIcon.contains(e.target) && !notificationDropdown.contains(e.target)) {
            notificationDropdown.style.display = 'none';
        }
    });

    // Load notification count on page load
    loadNotificationCount();

    // Refresh notification count every 30 seconds
    setInterval(loadNotificationCount, 30000);
});
</script>

<script src="script.js"></script>
</body>
</html>
