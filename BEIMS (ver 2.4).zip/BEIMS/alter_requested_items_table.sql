-- Alter requested_items table to match the application requirements

-- Remove the date_needed column
ALTER TABLE requested_items DROP COLUMN date_needed;

-- Remove the item_name column (we'll use item_id instead)
ALTER TABLE requested_items DROP COLUMN item_name;

-- Rename form_id to borrower_id (if needed)
ALTER TABLE requested_items CHANGE COLUMN form_id borrower_id INT(11) NOT NULL;

-- Add item_id column (foreign key to item_list.id)
ALTER TABLE requested_items ADD COLUMN item_id INT(11) NOT NULL AFTER borrower_id;

-- Add created_at column
ALTER TABLE requested_items ADD COLUMN created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP AFTER unit;

-- Add foreign key constraint for item_id
ALTER TABLE requested_items ADD CONSTRAINT fk_requested_items_item_id 
FOREIGN KEY (item_id) REFERENCES item_list(id);

-- Add foreign key constraint for borrower_id
ALTER TABLE requested_items ADD CONSTRAINT fk_requested_items_borrower_id 
FOREIGN KEY (borrower_id) REFERENCES borrowers(id);

-- Show the final table structure
DESCRIBE requested_items; 