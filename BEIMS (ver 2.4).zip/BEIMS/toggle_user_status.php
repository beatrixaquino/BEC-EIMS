<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Output as JSON
header('Content-Type: application/json');

// Include the database connection
include_once "dbconnect.php";

// Check if the request is POST and has the required parameters
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_id']) && isset($_POST['action'])) {
    $user_id = intval($_POST['user_id']);
    $action = $_POST['action'];
    
    // Validate action
    if (!in_array($action, ['deactivate', 'reactivate'])) {
        echo json_encode(['success' => false, 'error' => 'Invalid action']);
        exit();
    }
    
    // Set the new status
    $new_status = ($action === 'deactivate') ? 'inactive' : 'active';
    
    // Update the user status
    $sql = "UPDATE users SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        echo json_encode(['success' => false, 'error' => 'Query preparation failed: ' . $conn->error]);
        exit();
    }
    
    $stmt->bind_param("si", $new_status, $user_id);
    
    if ($stmt->execute()) {
        $message = ($action === 'deactivate') ? 'User deactivated successfully' : 'User reactivated successfully';
        echo json_encode(['success' => true, 'message' => $message, 'new_status' => $new_status]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to update user status']);
    }
    
    $stmt->close();
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request']);
}

$conn->close();
?> 