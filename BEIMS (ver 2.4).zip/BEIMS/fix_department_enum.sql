-- Make department field more flexible
-- Currently it's limited to 'Student' and 'Faculty Member'

-- Step 1: Check current department values
SELECT DISTINCT department FROM borrowers;

-- Step 2: Change department to VARCHAR to allow more flexibility
ALTER TABLE borrowers MODIFY COLUMN department VARCHAR(100) NOT NULL;

-- Step 3: Verify the change
DESCRIBE borrowers; 