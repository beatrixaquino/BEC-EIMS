<?php
session_start();
include_once "notification_helper.php";

// Test different user roles
$roles = ['student', 'admin', 'super_admin'];

echo "<h2>Notification Filtering Test</h2>";
echo "<p>This page shows how notifications are filtered based on user role.</p>";

foreach ($roles as $role) {
    echo "<h3>User Role: {$role}</h3>";
    
    // Simulate user with this role
    $user_id = 1; // Same user ID for testing
    
    echo "<h4>Unread Count:</h4>";
    $count = getUnreadNotificationsCount($user_id, $role);
    echo "Count: {$count}<br>";
    
    echo "<h4>Notifications:</h4>";
    $notifications = getNotifications($user_id, 10, 0, $role);
    
    if (empty($notifications)) {
        echo "No notifications for this role.<br>";
    } else {
        foreach ($notifications as $notif) {
            echo "- {$notif['title']}: {$notif['message']} (Type: {$notif['type']})<br>";
        }
    }
    
    echo "<hr>";
}

echo "<h3>How It Works:</h3>";
echo "<ul>";
echo "<li><strong>Student/Teacher:</strong> Only sees 'form_approved', 'form_rejected', 'form_submitted'</li>";
echo "<li><strong>Admin:</strong> Sees 'new_form', 'form_approved', 'form_rejected', 'form_returned'</li>";
echo "<li><strong>Super Admin:</strong> Sees all notifications including 'equipment_added'</li>";
echo "</ul>";

echo "<h3>Current Notifications in Database:</h3>";
$sql = "SELECT * FROM notifications ORDER BY created_at DESC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "- {$row['title']}: {$row['message']} (Type: {$row['type']})<br>";
    }
} else {
    echo "No notifications in database.";
}
?> 