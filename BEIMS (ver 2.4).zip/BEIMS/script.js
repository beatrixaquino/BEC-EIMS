console.log("JS file loaded!");
document.addEventListener('DOMContentLoaded', function () {
    // Existing script: Sidebar functionality
    const allSideMenu = document.querySelectorAll('#sidebar .side-menu.top li a');

    // Get the current page from the body 'data-page' attribute
    let currentPage = document.body.getAttribute('data-page');

    // Set up sidebar active class
    allSideMenu.forEach(item => {
        const li = item.parentElement;
        const pageName = item.getAttribute("href").split("/").pop().split(".")[0];
        
        // Handle index.html as dashboard
        if (pageName === 'index' && currentPage === 'index') {
            li.classList.add('active');
        } else if (pageName !== 'index' && pageName === currentPage) {
            li.classList.add('active');
        } else {
            li.classList.remove('active');
        }

        // Add click event to update the active class
        item.addEventListener('click', function () {
            allSideMenu.forEach(i => {
                i.parentElement.classList.remove('active');
            });
            li.classList.add('active');
        });
    });

    // Toggle sidebar functionality
    const menuBar = document.querySelector('#content nav .bx.bx-menu');
    const sidebar = document.getElementById('sidebar');

    if (menuBar) {
        menuBar.addEventListener('click', function () {
            sidebar.classList.toggle('hide');
        });
    } else {
        console.error('Sidebar toggle element (bx bx-menu) not found.');
    }

    // Search functionality
    const searchButton = document.querySelector('#content nav form .form-input button');
    const searchButtonIcon = document.querySelector('#content nav form .form-input button .bx');
    const searchForm = document.querySelector('#content nav form');

    searchButton.addEventListener('click', function (e) {
        if (window.innerWidth < 576) {
            e.preventDefault();
            searchForm.classList.toggle('show');
            if (searchForm.classList.contains('show')) {
                searchButtonIcon.classList.replace('bx-search', 'bx-x');
            } else {
                searchButtonIcon.classList.replace('bx-x', 'bx-search');
            }
        }
    });

    // Responsive behavior on load
    if (window.innerWidth < 768) {
        sidebar.classList.add('hide');
    } else if (window.innerWidth > 576) {
        searchButtonIcon.classList.replace('bx-x', 'bx-search');
        searchForm.classList.remove('show');
    }

    window.addEventListener('resize', function () {
        if (this.innerWidth > 576) {
            searchButtonIcon.classList.replace('bx-x', 'bx-search');
            searchForm.classList.remove('show');
        }
    });

    // Dark mode toggle
    const switchMode = document.getElementById('switch-mode');
    if (switchMode) {
        switchMode.addEventListener('change', function () {
            if (this.checked) {
                document.body.classList.add('dark');
            } else {
                document.body.classList.remove('dark');
            }
        });
    }

    // Log the page loaded and check current page
    console.log("Page loaded. Current page:", currentPage);

    // Define the editAdmin function
    window.editAdmin = function(button) {
        console.log("Edit button clicked.");  // Log to confirm button click

        // Get data attributes from the clicked button
        const id = button.getAttribute('data-id');
        const username = button.getAttribute('data-username');
        const password = button.getAttribute('data-password');
        const acctype = button.getAttribute('data-acctype');

        // Debugging: Log the values to check if they are being captured correctly
        console.log("Admin ID:", id);
        console.log("Username:", username);
        console.log("Password:", password);
        console.log("Account Type:", acctype);

        // Populate the form fields with the clicked admin's details
        document.getElementById('username').value = username;
        document.getElementById('password').value = password; 
        document.getElementById('acctype').value = acctype;

        // Add hidden input field to store the ID of the admin being edited
        let hiddenIdField = document.getElementById('admin-id');
        if (!hiddenIdField) {
            hiddenIdField = document.createElement('input');
            hiddenIdField.type = 'hidden';
            hiddenIdField.id = 'admin-id';
            hiddenIdField.name = 'id';
            document.querySelector('form').appendChild(hiddenIdField);
        }
        hiddenIdField.value = id;

        // Confirm hidden ID field value for debugging
        console.log("Hidden ID Field Value:", hiddenIdField.value);
    };

    // Check if the current page is 'usermng' before setting up editAdmin
    if (currentPage === 'usermng') {
        console.log("Setting up editAdmin for admin management page.");

        // Attach event listeners to each edit button
        document.querySelectorAll('.btn-edit').forEach(button => {
            button.addEventListener('click', function () {
                console.log("Edit button was clicked on item with ID:", button.getAttribute('data-id'));
                editAdmin(button); // Call the editAdmin function
            });
        });
    } else {
        console.log("Current page is not 'usermng', editAdmin not set up.");
    }

   // --- CALENDAR SETUP WITH NAVIGATION ---

// Global month names so it's accessible by multiple functions
const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
];

// Track current displayed month and year
let currentMonth = new Date().getMonth();
let currentYear = new Date().getFullYear();

// Global variable to store calendar events
let calendarEvents = [];

// Function to load calendar events from the server
async function loadCalendarEvents() {
    try {
        const response = await fetch('fetch_calendar_events.php');
        const data = await response.json();
        
        if (data.success) {
            calendarEvents = data.events;
            console.log('Loaded calendar events:', calendarEvents);
        } else {
            console.error('Failed to load calendar events:', data.error);
        }
    } catch (error) {
        console.error('Error loading calendar events:', error);
    }
}

// Function to render the calendar grid with events
function renderCalendar(month, year) {
    const header = document.getElementById('current-month-year');
    const calendarDays = document.getElementById('calendar-days');

    if (!header || !calendarDays) {
        console.error("Missing #current-month-year or #calendar-days");
        return;
    }

    header.textContent = `${monthNames[month]} ${year}`;
    calendarDays.innerHTML = '';

    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    // Empty slots before the first day
    for (let i = 0; i < firstDay; i++) {
        const empty = document.createElement('div');
        empty.classList.add('calendar-day', 'empty');
        calendarDays.appendChild(empty);
    }

    // Real days of the month
    for (let d = 1; d <= daysInMonth; d++) {
        const day = document.createElement('div');
        day.classList.add('calendar-day');
        day.textContent = d;
        
        // Check for events on this day
        const currentDate = new Date(year, month, d);
        const dateString = currentDate.toISOString().split('T')[0]; // YYYY-MM-DD format
        
        const dayEvents = calendarEvents.filter(event => event.date === dateString);
        
        if (dayEvents.length > 0) {
            console.log(`Day ${d} has ${dayEvents.length} events:`, dayEvents);
            day.classList.add('has-events');
            
            // Create event indicators
            dayEvents.forEach(event => {
                const eventIndicator = document.createElement('div');
                eventIndicator.classList.add('event-indicator', `event-${event.type}`);
                eventIndicator.setAttribute('data-event-id', event.id);
                eventIndicator.setAttribute('data-event-type', event.type);
                eventIndicator.setAttribute('data-borrower-name', event.borrower_name);
                eventIndicator.setAttribute('data-description', event.description);
                eventIndicator.title = event.title;
                day.appendChild(eventIndicator);
                console.log(`Created event indicator for ${event.type} event:`, event);
            });
        }
        
        calendarDays.appendChild(day);
    }

    console.log(`Rendered ${daysInMonth} days for ${monthNames[month]} ${year} with ${calendarEvents.length} events`);
}

// Button functionality
const prevButton = document.getElementById('prev-month');
const nextButton = document.getElementById('next-month');

if (prevButton && nextButton) {
    prevButton.addEventListener('click', async () => {
        currentMonth--;
        if (currentMonth < 0) {
            currentMonth = 11;
            currentYear--;
        }
        await loadCalendarEvents();
        renderCalendar(currentMonth, currentYear);
    });

    nextButton.addEventListener('click', async () => {
        currentMonth++;
        if (currentMonth > 11) {
            currentMonth = 0;
            currentYear++;
        }
        await loadCalendarEvents();
        renderCalendar(currentMonth, currentYear);
    });
} else {
    console.warn("Prev/Next buttons not found.");
}

// Load events and render calendar
async function initializeCalendar() {
    await loadCalendarEvents();
    renderCalendar(currentMonth, currentYear);
    
    // Add click handlers for event indicators and calendar days
    document.addEventListener('click', function(e) {
        console.log('Click detected on:', e.target);
        console.log('Element classes:', e.target.classList);
        
        // Check if clicking on event indicator
        if (e.target.classList.contains('event-indicator')) {
            console.log('Event indicator clicked!');
            const eventType = e.target.getAttribute('data-event-type');
            const borrowerName = e.target.getAttribute('data-borrower-name');
            const description = e.target.getAttribute('data-description');
            const eventId = e.target.getAttribute('data-event-id');
            const borrowerId = eventId.split('_')[0];
            
            console.log('Event details:', { eventType, borrowerName, description, eventId, borrowerId });
            
            // Show detailed modal
            showEventDetails(eventType, borrowerName, description, borrowerId);
        }
        // Check if clicking on calendar day with events
        else if (e.target.classList.contains('calendar-day') && e.target.classList.contains('has-events')) {
            console.log('Calendar day with events clicked!');
            
            // Find the first event indicator in this day
            const eventIndicator = e.target.querySelector('.event-indicator');
            if (eventIndicator) {
                console.log('Found event indicator, triggering click');
                const eventType = eventIndicator.getAttribute('data-event-type');
                const borrowerName = eventIndicator.getAttribute('data-borrower-name');
                const description = eventIndicator.getAttribute('data-description');
                const eventId = eventIndicator.getAttribute('data-event-id');
                const borrowerId = eventId.split('_')[0];
                
                console.log('Event details from day click:', { eventType, borrowerName, description, eventId, borrowerId });
                
                // Show detailed modal
                showEventDetails(eventType, borrowerName, description, borrowerId);
            }
        }
    });
}

// Function to show detailed event information
async function showEventDetails(eventType, borrowerName, description, borrowerId) {
    console.log('showEventDetails called with:', { eventType, borrowerName, description, borrowerId });
    
    try {
        console.log('Fetching borrower details for ID:', borrowerId);
        // Fetch detailed borrower information
        const response = await fetch(`fetch_student_info.php?id=${borrowerId}`);
        const borrowerData = await response.json();
        
        console.log('Borrower data received:', borrowerData);
        
        if (borrowerData.error) {
            console.error('Error fetching borrower details:', borrowerData.error);
            return;
        }
        
        // Create modal content
        const modal = document.createElement('div');
        modal.className = 'event-details-modal';
        modal.innerHTML = `
            <div class="event-details-content">
                <div class="event-details-header">
                    <h3>${eventType === 'borrow' ? '📦 Equipment Borrowed' : '📤 Equipment Returned'}</h3>
                    <button class="close-event-modal">&times;</button>
                </div>
                <div class="event-details-body">
                    <div class="borrower-info">
                        <h4>👤 Borrower Information</h4>
                        <div class="info-grid">
                            <div class="info-item">
                                <strong>Name:</strong> ${borrowerData.firstname} ${borrowerData.lastname}
                            </div>
                            <div class="info-item">
                                <strong>ID Number:</strong> ${borrowerData.idnum}
                            </div>
                            <div class="info-item">
                                <strong>Department:</strong> ${borrowerData.department}
                            </div>
                            <div class="info-item">
                                <strong>Course:</strong> ${borrowerData.course}
                            </div>
                            <div class="info-item">
                                <strong>Email:</strong> ${borrowerData.email}
                            </div>
                            <div class="info-item">
                                <strong>Contact:</strong> ${borrowerData.cpnnumber}
                            </div>
                        </div>
                    </div>
                    
                    <div class="event-dates">
                        <h4>📅 Event Details</h4>
                        <div class="info-grid">
                            <div class="info-item">
                                <strong>Borrow Date:</strong> ${formatDate(borrowerData.borrow_date)}
                            </div>
                            <div class="info-item">
                                <strong>Return Date:</strong> ${formatDate(borrowerData.return_date)}
                            </div>
                            <div class="info-item">
                                <strong>Event Type:</strong> 
                                <span class="event-type-badge ${eventType}">
                                    ${eventType === 'borrow' ? 'Borrow' : 'Return'}
                                </span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="borrowed-items-section">
                        <h4>🛠️ Borrowed Items</h4>
                        <div id="borrowed-items-list">
                            <div class="loading">Loading borrowed items...</div>
                        </div>
                    </div>
                </div>
                <div class="event-details-footer">
                    <button class="btn-view-details" data-borrower-id="${borrowerId}">
                        📋 View Details
                    </button>
                    <button class="btn-close-modal">Close</button>
                </div>
            </div>
        `;
        
        // Add modal to page
        console.log('Adding modal to page');
        document.body.appendChild(modal);
        console.log('Modal added successfully');
        
        // Load borrowed items
        loadBorrowedItems(borrowerId, 'borrowed-items-list');
        
        // Add event listeners
        modal.querySelector('.close-event-modal').addEventListener('click', () => {
            modal.remove();
        });
        
        modal.querySelector('.btn-close-modal').addEventListener('click', () => {
            modal.remove();
        });
        
        // Add event listener for view details button
        modal.querySelector('.btn-view-details').addEventListener('click', (e) => {
            e.preventDefault();
            const borrowerId = e.target.getAttribute('data-borrower-id');
            console.log('View details clicked for borrower ID:', borrowerId);
            viewBorrowerDetails(borrowerId);
        });
        
        // Close modal when clicking outside
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });
        
    } catch (error) {
        console.error('Error showing event details:', error);
        alert('Error loading event details. Please try again.');
    }
}

// Function to format date
function formatDate(dateString) {
    if (!dateString || dateString === '0000-00-00') return 'Not set';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

// Function to load borrowed items
async function loadBorrowedItems(borrowerId, containerId) {
    try {
        const response = await fetch(`fetch_borrowed_items.php?form_id=${borrowerId}`);
        const items = await response.json();
        
        const container = document.getElementById(containerId);
        
        if (items && items.length > 0) {
            let html = '<div class="items-grid">';
            items.forEach(item => {
                html += `
                    <div class="item-card">
                        <div class="item-name">${item.item_name}</div>
                        <div class="item-quantity">${item.quantity} ${item.unit}</div>
                    </div>
                `;
            });
            html += '</div>';
            container.innerHTML = html;
        } else {
            container.innerHTML = '<div class="no-items">No borrowed items found</div>';
        }
    } catch (error) {
        console.error('Error loading borrowed items:', error);
        document.getElementById(containerId).innerHTML = '<div class="error">Error loading items</div>';
    }
}

// Function to view borrower details in a modal (similar to equipment view)
window.viewBorrowerDetails = function(borrowerId) {
    console.log('viewBorrowerDetails called with borrowerId:', borrowerId);
    
    // Create modal if it doesn't exist
    let borrowerModal = document.getElementById('borrowerDetailsModal');
    if (!borrowerModal) {
        console.log('Creating new borrower modal');
        borrowerModal = document.createElement('div');
        borrowerModal.id = 'borrowerDetailsModal';
        borrowerModal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background-color: rgba(0,0,0,0.4);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 2000;
        `;
        
        borrowerModal.innerHTML = `
            <div class="modal-content" style="background:#fff; padding:25px; border-radius:12px; max-width:600px; width:90%; margin:auto; position:relative;">
                <span id="closeBorrowerModal" style="position:absolute; top:15px; right:20px; cursor:pointer; font-size:24px; color:#666;">&times;</span>
                <div id="borrowerDetailsContent">
                    <!-- Content will be loaded here -->
                </div>
            </div>
        `;
        
        document.body.appendChild(borrowerModal);
        console.log('Modal added to DOM');
        
        // Add close functionality
        const closeBtn = borrowerModal.querySelector('#closeBorrowerModal');
        closeBtn.addEventListener('click', () => {
            borrowerModal.style.display = 'none';
        });
        
        borrowerModal.addEventListener('click', (e) => {
            if (e.target === borrowerModal) {
                borrowerModal.style.display = 'none';
            }
        });
    }
    
    // Show loading state
    const content = document.getElementById('borrowerDetailsContent');
    content.innerHTML = '<div style="text-align: center; padding: 20px;"><i class="bx bx-loader-alt bx-spin" style="font-size: 2rem;"></i><p>Loading borrower details...</p></div>';
    borrowerModal.style.display = 'flex';
    console.log('Modal should be visible now');
    
    // Fetch borrower details
    console.log('Fetching borrower details for ID:', borrowerId);
    fetch(`fetch_student_info.php?id=${borrowerId}`)
        .then(response => response.json())
        .then(data => {
            console.log('Borrower data received:', data);
            if (data.error) {
                content.innerHTML = `<div style="text-align: center; padding: 20px; color: red;"><p>Error: ${data.error}</p></div>`;
            } else {
                // Fetch borrowed items
                fetch(`fetch_borrowed_items.php?form_id=${borrowerId}`)
                    .then(response => response.json())
                    .then(items => {
                        let itemsHtml = '';
                        if (items && items.length > 0) {
                            items.forEach(item => {
                                itemsHtml += `
                                    <div style="background: #f8f9fa; padding: 10px; border-radius: 6px; margin: 5px 0;">
                                        <strong>${item.item_name}</strong> - ${item.quantity} ${item.unit}
                                    </div>
                                `;
                            });
                        } else {
                            itemsHtml = '<div style="color: #666; font-style: italic;">No borrowed items found</div>';
                        }
                        
                        content.innerHTML = `
                            <div style="margin-bottom: 20px;">
                                <h2 style="margin: 0 0 15px 0; color: #333;">Borrower Details</h2>
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                                    <div>
                                        <strong>Name:</strong><br>
                                        <span>${data.firstname} ${data.middleinitial} ${data.lastname}</span>
                                    </div>
                                    <div>
                                        <strong>ID Number:</strong><br>
                                        <span>${data.idnum}</span>
                                    </div>
                                    <div>
                                        <strong>Department:</strong><br>
                                        <span>${data.department}</span>
                                    </div>
                                    <div>
                                        <strong>Course:</strong><br>
                                        <span>${data.course}</span>
                                    </div>
                                    <div>
                                        <strong>Email:</strong><br>
                                        <span>${data.email}</span>
                                    </div>
                                    <div>
                                        <strong>Contact:</strong><br>
                                        <span>${data.cpnnumber}</span>
                                    </div>
                                </div>
                            </div>
                            
                            <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                                <h3 style="margin: 0 0 10px 0; color: #495057;">Borrowing Information</h3>
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                                    <div>
                                        <strong>Borrow Date:</strong><br>
                                        <span>${formatDate(data.borrow_date)}</span>
                                    </div>
                                    <div>
                                        <strong>Return Date:</strong><br>
                                        <span>${formatDate(data.return_date)}</span>
                                    </div>
                                    <div>
                                        <strong>Status:</strong><br>
                                        <span style="padding: 4px 8px; border-radius: 4px; background: ${getStatusColor(data.status)}; color: white; font-size: 0.8rem;">${data.status}</span>
                                    </div>
                                    <div>
                                        <strong>Consent:</strong><br>
                                        <span>${data.consent == 1 ? 'Yes' : 'No'}</span>
                                    </div>
                                </div>
                            </div>
                            
                            <div style="background: #f8f9fa; padding: 15px; border-radius: 8px;">
                                <h3 style="margin: 0 0 10px 0; color: #495057;">Borrowed Items</h3>
                                ${itemsHtml}
                            </div>
                            
                            <div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid #dee2e6;">
                                <small style="color: #6c757d;">Borrower ID: ${data.id} | Created: ${data.created_at || 'Unknown'}</small>
                            </div>
                        `;
                    })
                    .catch(error => {
                        content.innerHTML = `<div style="text-align: center; padding: 20px; color: red;"><p>Error loading borrowed items: ${error.message}</p></div>`;
                    });
            }
        })
        .catch(error => {
            content.innerHTML = `<div style="text-align: center; padding: 20px; color: red;"><p>Error loading borrower details: ${error.message}</p></div>`;
        });
}

// Function to get status color
function getStatusColor(status) {
    switch(status) {
        case 'pending': return '#ffc107';
        case 'approved': return '#28a745';
        case 'rejected': return '#dc3545';
        case 'returned': return '#17a2b8';
        default: return '#6c757d';
    }
}

// Initialize calendar
initializeCalendar();
    

});