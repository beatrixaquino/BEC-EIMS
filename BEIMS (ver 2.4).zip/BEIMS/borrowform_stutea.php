<?php
// Start session and include DB connection
session_start();
include_once 'dbconnect.php'; // adjust if your connection file has a different name

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve data from the form
    $idnum = $_POST['idnum'];
    $firstname = $_POST['firstname'];
    $middleinitial = $_POST['middleinitial'];
    $lastname = $_POST['lastname'];
    $department = $_POST['department'];
    $course = $_POST['course'];
    $email = $_POST['email'];
    $cpnnumber = $_POST['cpnnumber'];
    $consent = isset($_POST['consent']) ? 1 : 0; // Set consent to 1 if checked
    
    // Handle course field based on department
    if ($department === "Faculty Member") {
        $course = null; // Set course to null for faculty members
    }
    // Properly format dates for database storage
    $borrow_date = !empty($_POST['borrow_date']) ? date('Y-m-d', strtotime($_POST['borrow_date'])) : null;
    $return_date = !empty($_POST['return_date']) ? date('Y-m-d', strtotime($_POST['return_date'])) : null;

    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Prepare SQL insert statement for borrowers table
        $sql = "INSERT INTO borrowers (idnum, firstname, middleinitial, lastname, department, course, email, cpnnumber, consent, borrow_date, return_date, status, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', NOW())";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssssssssss", $idnum, $firstname, $middleinitial, $lastname, $department, $course, $email, $cpnnumber, $consent, $borrow_date, $return_date);
        $stmt->execute();
        
        $borrower_id = $conn->insert_id; // Get the ID of the inserted borrower
        
        // Process borrowed items
        foreach ($_POST as $key => $value) {
            if (strpos($key, 'quantity_') === 0) {
                $item_id = substr($key, 9); // Remove 'quantity_' prefix
                $quantity = $value;
                $unit = $_POST['unit_' . $item_id];
                
                // Insert into requested_items table
                $item_sql = "INSERT INTO requested_items (borrower_id, item_id, quantity, unit, created_at)
                            VALUES (?, ?, ?, ?, NOW())";
                $item_stmt = $conn->prepare($item_sql);
                $item_stmt->bind_param("iiis", $borrower_id, $item_id, $quantity, $unit);
                $item_stmt->execute();
            }
        }
        
        // Commit transaction
        $conn->commit();
        
        // Create notifications
        include_once "notification_helper.php";
        
        // Notification for the super admin only (since students/teachers don't have user accounts yet)
        $submitter_name = $firstname . " " . $lastname;
        createNotification(
            1, // Super admin user ID
            "New Borrow Form Submitted",
            "A new borrow form has been submitted by {$submitter_name} ({$department})",
            "new_form",
            $borrower_id
        );
        
        $_SESSION['message'] = "Borrow request submitted successfully!";
        header("Location: borrowform_stutea.php");
        exit();
        
    } catch (Exception $e) {
        // Rollback transaction on error
        $conn->rollback();
        $_SESSION['error'] = "Submission failed. Please try again. Error: " . $e->getMessage();
        header("Location: borrowform_stutea.php");
        exit();
    }
}

// Fetch equipment items for borrowers to see
$sql = "SELECT * FROM item_list ORDER BY created_at DESC";
$result = $conn->query($sql);
ob_end_flush(); // Flush output buffer
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="istyle.css">
    <style>
        #courseGroup {
            transition: opacity 0.3s ease-in-out;
        }
    </style>
    <title>Teacher & Student Borrowers Form</title>
</head>
<body data-page="borrowform">

<!-- SIDEBAR -->
<section id="sidebar">
		<a href="#" class="brand">
			<i class='bx bxs-package' ></i>
			<span class="text">BEC EIMS</span>
		</a>
		<ul class="side-menu top">
			<li class="active">
				<a href="dashboard_superadmin.php">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Dashboard</span>
				</a>
			</li>
			<li>
				<a href="borrowform.php">
					<i class='bx bxs-report'></i>
					<span class="text">Borrowers Forms</span>
				</a>
			</li>
			<li>
				<a href="equiplist.php">
					<i class='bx bxs-id-card'></i>
					<span class="text">Equipment List</span>
				</a>
			</li>
		</ul>
		<ul class="side-menu">
			<li>
				<a href="login.php" class="logout">
					<i class='bx bxs-log-out' ></i>
					<span class="text">Logout</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->


    <!-- CONTENT -->
    <section id="content">
        <nav>
            <i class='bx bx-menu'></i>
            <a href="#" class="nav-link">Categories</a>
            <form id="globalSearchForm" action="#" autocomplete="off">
                <div class="form-input">
                    <input type="search" id="globalSearchInput" placeholder="Search equipment...">
                    <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
                </div>
            </form>
            <input type="checkbox" id="switch-mode" hidden>
            <label for="switch-mode" class="switch-mode"></label>
            <a href="#" class="notification" id="notificationIcon">
                <i class='bx bxs-bell'></i>
                <span class="num" id="notificationCount">0</span>
            </a>
            <div class="notification-dropdown" id="notificationDropdown" style="display: none;">
                <div class="notification-header">
                    <h4>Notifications</h4>
                    <button id="markAllRead" class="mark-all-read">Mark all read</button>
                </div>
                <div class="notification-list" id="notificationList">
                    <!-- Notifications will be loaded here -->
                </div>
            </div>
            <a href="#" class="profile">
                <img src="img/people.png">
            </a>
        </nav>

        <main>
            <div class="head-title">
                <div class="left">
                    <h1>Borrowers Forms</h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="#">Borrowers Forms</a>
                        </li>
                        <li><i class='bx bx-chevron-right'></i></li>
                        <li>
                            <a class="active" href="submforms.php">Form</a>
                        </li>
                    </ul>
                </div>
                <a href="#" class="btn-download" onclick="copyFormLink()">
    <i class='bx bx-copy'></i>
    <span class="text">Generate Report</span>
</a>
            </div>

            <div class="table-data">
            <div class="order">
            <div class="head">
                        <h3>Available Equipment for Borrowing</h3>
                        <i class='bx bx-sort' id="sortBtn" title="Toggle Sort Order"></i>
                        <i class='bx bx-filter' id="filterBtn"></i>
                       
                    </div>
                    <div class="filter-group" id="filterGroup">
                        <button class="filter-option" data-category="all">All</button>
                        <?php
                        $catResult = $conn->query("SELECT name FROM categories ORDER BY name ASC");
                        while ($catRow = $catResult->fetch_assoc()) {
                            $catName = $catRow['name'];
                            echo '<button class="filter-option" data-category="' . htmlspecialchars($catName) . '">' . htmlspecialchars(ucfirst($catName)) . '</button>';
                        }
                        ?>
                    </div>

                    <div class="equipment-grid">
                        <?php if ($result->num_rows > 0): ?>
                            <?php while ($row = $result->fetch_assoc()): ?>
                                <?php
                                $item_id = $row['id'];
                                $catNames = [];
                                $catRes = $conn->query("SELECT c.name FROM item_categories ic JOIN categories c ON ic.category_id = c.id WHERE ic.item_id = $item_id");
                                while ($catRow = $catRes->fetch_assoc()) {
                                    $catNames[] = $catRow['name'];
                                }
                                $dataCategory = htmlspecialchars(implode(',', $catNames));
                                ?>
                                <div class="equipment-card" data-category="<?php echo $dataCategory; ?>">
                                    <img src="uploads/<?php echo htmlspecialchars($row['eqpphoto'] ?? 'placeholder.png'); ?>" alt="Equipment Image" class="equipment-img">
                                    <h4><?php echo htmlspecialchars($row['itemname']); ?></h4>
                                    <p><strong>Category:</strong> <?php 
                                    $item_id = $row['id'];
                                    $catNames = [];
                                    $catRes = $conn->query("SELECT c.name FROM item_categories ic JOIN categories c ON ic.category_id = c.id WHERE ic.item_id = $item_id");
                                    while ($catRow = $catRes->fetch_assoc()) {
                                        $catNames[] = ucfirst($catRow['name']);
                                    }
                                    echo implode(', ', $catNames);
                                    ?></p>
                                    <p><strong>Available:</strong> <?php echo htmlspecialchars($row['quantityon']); ?> <?php echo htmlspecialchars($row['unit_on']); ?></p>
                                    <div class="card-actions">
                                        <button class="btn-view-card" data-id="<?php echo $row['id']; ?>">View Details</button>
                                        <button class="btn-borrow-card" data-id="<?php echo $row['id']; ?>" data-name="<?php echo htmlspecialchars($row['itemname']); ?>">Request to Borrow</button>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <p>No equipment available for borrowing.</p>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="todo">
                    <div class="head">
                        <h3>Tool Borrowers Form</h3>
                    </div>
                    
                    <?php if (isset($_SESSION['message'])): ?>
                        <div class="alert alert-success" style="background-color: #d4edda; color: #155724; padding: 10px; border-radius: 4px; margin-bottom: 15px; border: 1px solid #c3e6cb;">
                            <?php echo $_SESSION['message']; ?>
                            <?php unset($_SESSION['message']); ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (isset($_SESSION['error'])): ?>
                        <div class="alert alert-danger" style="background-color: #f8d7da; color: #721c24; padding: 10px; border-radius: 4px; margin-bottom: 15px; border: 1px solid #f5c6cb;">
                            <?php echo $_SESSION['error']; ?>
                            <?php unset($_SESSION['error']); ?>
                        </div>
                    <?php endif; ?>
                    <form id="studentDetailsForm" action="borrowform_stutea.php" method="POST" enctype="multipart/form-data">
                        <input type="hidden" id="borrowform" name="id">
                        
                        <div class="form-group">
                            <label for="idnum">ID Number</label>
                            <div class="input-group">
                                <input type="text" id="idnum" name="idnum" placeholder="ID Number" required>
                                <i class='bx bx-id-card'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="firstname">First Name</label>
                            <div class="input-group">
                                <input type="text" id="firstname" name="firstname" placeholder="First Name" required>
                                <i class='bx bx-user'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="middleinitial">Middle Initial</label>
                            <div class="input-group">
                                <input type="text" id="middleinitial" name="middleinitial" placeholder="Middle Initial" required>
                                <i class='bx bx-user'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="lastname">Last Name</label>
                            <div class="input-group">
                                <input type="text" id="lastname" name="lastname" placeholder="Last Name" required>
                                <i class='bx bx-user'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="department">Department</label>
                            <div class="input-group">
                                <select id="department" name="department" required>
                                    <option value="" disabled selected>Select Department</option>
                                    <option value="Student">Student</option>
                                    <option value="Faculty Member">Faculty Member</option>
                                </select>
                                <i class='bx bx-chevron-down'></i>
                            </div>
                        </div>

                        <div class="form-group" id="courseGroup">
                            <label for="course">Course</label>
                            <div class="input-group">
                                <select id="course" name="course" required>
                                    <option value="" disabled selected>Select Course</option>
                                    <option value="cookery">CHRM Cookery NC II</option>
                                    <option value="fbs">CHRM Food and Beverages NC II</option>
                                    <option value="fos">CHRM Front Office Services NC II</option>
                                    <option value="housekeeping">CHRM Housekeeping NC II</option>
                                    <option value="bartending">CHRM Bartending NC II</option>
                                </select>
                                <i class='bx bx-chevron-down'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="email">School Email</label>
                            <div class="input-group">
                                <input type="email" id="email" name="email" placeholder="School Email" required>
                                <i class='bx bx-envelope'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="cpnnumber">Contact Number</label>
                            <div class="input-group">
                                <input type="text" id="cpnnumber" name="cpnnumber" placeholder="Contact Number" required>
                                <i class='bx bx-phone'></i>
                            </div>
                        </div>

                        <div class="borrowed-items-card">
    <h3>Borrowed Items</h3>
    <table class="borrowed-items-table">
        <thead>
            <tr>
                <th>Item Name</th>
                <th>Quantity</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody id="borrowedItemsTable">
            
        </tbody>
    </table>
</div>

<div class="borrow-dates">
    <div class="form-group">
        <label for="borrow_date">Borrow Date</label>
        <div class="input-group">
            <input type="date" id="borrow_date" name="borrow_date" required>
        </div>
    </div>

    <div class="form-group">
        <label for="return_date">Return Date</label>
        <div class="input-group">
            <input type="date" id="return_date" name="return_date" required>
        </div>
    </div>
</div>

                        <!-- Consent Checkbox -->
						<div class="form-group">
							<label class="checkbox-container">
								<input type="checkbox" id="consent" name="consent" required>
								<span>I confirm that all the information I have provided is accurate and correct, and I consent to its use for processing my equipment borrowing request.</span>
							</label>
						</div>
                    

                        

                        <button type="submit" class="btn-submit">Submit</button>


                    </form>
                </div>
            </div>
        </main>
    </section>

    <!-- View Item Details Modal -->
    <div id="viewItemModal" style="display:none;">
        <div class="modal-content" style="background:#fff; padding:25px; border-radius:12px; max-width:600px; width:90%; margin:auto; position:relative;">
            <span id="closeViewModal" style="position:absolute; top:15px; right:20px; cursor:pointer; font-size:24px; color:#666;">&times;</span>
            <div id="itemDetailsContent">
                <!-- Content will be loaded here -->
            </div>
        </div>
    </div>

    <script>
document.addEventListener("DOMContentLoaded", () => {
    // Department/Course conditional logic
    const departmentSelect = document.getElementById("department");
    const courseGroup = document.getElementById("courseGroup");
    const courseSelect = document.getElementById("course");

    function toggleCourseField() {
        const selectedDepartment = departmentSelect.value;
        
        if (selectedDepartment === "Faculty Member") {
            // Hide course field for faculty members
            courseGroup.style.display = "none";
            courseGroup.style.opacity = "0";
            courseSelect.removeAttribute("required");
            courseSelect.value = ""; // Clear the selection
        } else {
            // Show course field for students
            courseGroup.style.display = "block";
            courseGroup.style.opacity = "1";
            courseSelect.setAttribute("required", "required");
        }
    }

    // Add event listener for department change
    departmentSelect.addEventListener("change", toggleCourseField);

    // Filter button functionality
    const filterBtn = document.getElementById("filterBtn");
    const filterGroup = document.getElementById("filterGroup");
    
    // Start with filter group hidden
    filterGroup.classList.add("hide");
    
    // Toggle filter group visibility
    filterBtn.addEventListener("click", function(e) {
        e.stopPropagation();
        filterGroup.classList.toggle("hide");
    });
    
    // Hide filter group when clicking outside
    document.addEventListener("click", function(e) {
        if (!filterGroup.contains(e.target) && e.target !== filterBtn) {
            filterGroup.classList.add("hide");
        }
    });

    // Equipment card functionality
    const filterOptions = document.querySelectorAll(".filter-option");
    const equipmentCards = document.querySelectorAll(".equipment-card");

    filterOptions.forEach(btn => {
        btn.addEventListener("click", function() {
            // Remove active class from all
            filterOptions.forEach(b => b.classList.remove("active"));
            this.classList.add("active");

            const category = this.getAttribute("data-category");
            equipmentCards.forEach(card => {
                if (category === "all" || card.getAttribute("data-category") === category) {
                    card.style.display = "";
                } else {
                    card.style.display = "none";
                }
            });
        });
    });

    // Handle VIEW button for equipment
    document.querySelectorAll(".btn-view-card").forEach(btn => {
        btn.addEventListener("click", function(e) {
            e.stopPropagation(); // Prevent row click
            const itemId = this.getAttribute("data-id");
            
            console.log("View button clicked for item ID:", itemId);

            // Show loading state
            const modal = document.getElementById("viewItemModal");
            const content = document.getElementById("itemDetailsContent");
            
            console.log("Modal element:", modal);
            console.log("Content element:", content);
            
            content.innerHTML = '<div style="text-align: center; padding: 20px;"><i class="bx bx-loader-alt bx-spin" style="font-size: 2rem;"></i><p>Loading item details...</p></div>';
            modal.style.display = "block";
            modal.style.position = "fixed";
            modal.style.zIndex = "1000";
            modal.style.left = "0";
            modal.style.top = "0";
            modal.style.width = "100vw";
            modal.style.height = "100vh";
            modal.style.backgroundColor = "rgba(0,0,0,0.4)";
            modal.style.display = "flex";
            modal.style.justifyContent = "center";
            modal.style.alignItems = "center";
            
            console.log("Modal display set to:", modal.style.display);

            fetch(`fetch_equipment_info.php?id=${itemId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.error) {
                        content.innerHTML = `<div style="text-align: center; padding: 20px; color: red;"><p>Error: ${data.error}</p></div>`;
                    } else {
                        // Fetch categories for this item
                        fetch(`fetch_item_categories.php?item_id=${itemId}`)
                            .then(response => response.json())
                            .then(categories => {
                                const categoryNames = categories.map(cat => cat.name).join(', ');
                                
                                content.innerHTML = `
                                    <div style="display: flex; gap: 20px; margin-bottom: 20px;">
                                        <div style="flex: 1;">
                                            <img src="uploads/${data.eqpphoto || 'placeholder.png'}" alt="Equipment Image" style="width: 100%; max-width: 300px; height: auto; border-radius: 8px; object-fit: cover;">
                                        </div>
                                        <div style="flex: 2;">
                                            <h2 style="margin: 0 0 15px 0; color: #333;">${data.itemname}</h2>
                                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                                                <div>
                                                    <strong>Specification:</strong><br>
                                                    <span>${data.specification || 'Not specified'}</span>
                                                </div>
                                                <div>
                                                    <strong>Categories:</strong><br>
                                                    <span>${categoryNames || 'No categories'}</span>
                                                </div>
                                                <div>
                                                    <strong>Description:</strong><br>
                                                    <span>${data.itemdescription || 'No description'}</span>
                                                </div>
                                                <div>
                                                    <strong>Remarks:</strong><br>
                                                    <span>${data.remarks || 'No remarks'}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-top: 20px;">
                                        <div style="background: #f8f9fa; padding: 15px; border-radius: 8px;">
                                            <h3 style="margin: 0 0 10px 0; color: #495057;">Quantity Information</h3>
                                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                                                <div>
                                                    <strong>Required:</strong><br>
                                                    <span>${data.quantityreq || 0} ${data.unit_req || 'pcs'}</span>
                                                </div>
                                                <div>
                                                    <strong>Available:</strong><br>
                                                    <span>${data.quantityon || 0} ${data.unit_on || 'pcs'}</span>
                                                </div>
                                                <div>
                                                    <strong>Difference:</strong><br>
                                                    <span>${data.difference || 'Not calculated'}</span>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div style="background: #f8f9fa; padding: 15px; border-radius: 8px;">
                                            <h3 style="margin: 0 0 10px 0; color: #495057;">Compliance Audit</h3>
                                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                                                <div>
                                                    <strong>Year 1:</strong><br>
                                                    <span>${data.complianceauditone || 0} ${data.unit1 || 'pcs'}</span>
                                                </div>
                                                <div>
                                                    <strong>Year 2:</strong><br>
                                                    <span>${data.complianceaudittwo || 0} ${data.unit2 || 'pcs'}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid #dee2e6;">
                                        <small style="color: #6c757d;">Item ID: ${data.id} | Created: ${data.created_at || 'Unknown'}</small>
                                    </div>
                                `;
                            })
                            .catch(error => {
                                content.innerHTML = `<div style="text-align: center; padding: 20px; color: red;"><p>Error loading categories: ${error.message}</p></div>`;
                            });
                    }
                })
                .catch(error => {
                    content.innerHTML = `<div style="text-align: center; padding: 20px; color: red;"><p>Error loading item details: ${error.message}</p></div>`;
                });
        });
    });

    // Handle BORROW button for equipment
    document.querySelectorAll(".btn-borrow-card").forEach(btn => {
        btn.addEventListener("click", function(e) {
            e.stopPropagation();
            const itemId = this.getAttribute("data-id");
            const itemName = this.getAttribute("data-name");
            
            // Add item to borrow form
            addItemToBorrowForm(itemId, itemName);
        });
    });

    function addItemToBorrowForm(itemId, itemName) {
        const tableBody = document.getElementById("borrowedItemsTable");
        
        // Check if item is already in the table
        const existingRows = tableBody.querySelectorAll("tr");
        for (let row of existingRows) {
            const itemNameCell = row.querySelector("td:first-child");
            if (itemNameCell && itemNameCell.textContent === itemName) {
                alert(`"${itemName}" is already in your borrow request!`);
                return;
            }
        }
        
        // Create a new row for the borrowed item
        const newRow = document.createElement("tr");
        newRow.setAttribute("data-item-id", itemId);
        newRow.innerHTML = `
            <td>${itemName}</td>
            <td>
                <input type="number" name="quantity_${itemId}" min="1" value="1" required style="width: 60px; margin-right: 5px;"> 
                <select name="unit_${itemId}" style="width: 80px;">
                    <option value="pcs">pcs</option>
                    <option value="sets">sets</option>
                    <option value="units">units</option>
                </select>
            </td>
            <td>
                <button type="button" class="btn-delete-item" onclick="removeItem(this)" title="Remove item">
                    <i class='bx bx-trash' style="color: #dc3545;"></i>
                </button>
            </td>
        `;
        
        tableBody.appendChild(newRow);
        
        // Scroll to the form
        document.querySelector('.todo').scrollIntoView({ behavior: 'smooth' });
        
        alert(`"${itemName}" added to your borrow request!`);
    }




    function updateStatus(id, status) {
        fetch('update_status.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ id: id, status: status })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Status updated successfully!');
                location.reload(); // Refresh page to reflect changes
            } else {
                alert('Failed to update status: ' + data.error);
            }
        })
        .catch((error) => {
            console.error('Error:', error);
        });
    }

    function removeItem(button) {
        const row = button.closest('tr');
        const itemName = row.querySelector('td:first-child').textContent;
        
        if (confirm(`Are you sure you want to remove "${itemName}" from your borrow request?`)) {
            row.remove();
        }
    }

    function copyFormLink() {
        const formLink = "http://localhost/Try%20Lang/form.php";
        navigator.clipboard.writeText(formLink)
            .then(() => alert("Form link copied to clipboard!"))
            .catch(err => console.error("Failed to copy link: ", err));
    }

    window.copyFormLink = copyFormLink;
    window.removeItem = removeItem;

    // Search functionality
    const globalSearchForm = document.getElementById("globalSearchForm");
    const globalSearchInput = document.getElementById("globalSearchInput");

    if (globalSearchForm && globalSearchInput) {
        globalSearchForm.addEventListener("submit", function(e) {
            e.preventDefault();
            const query = globalSearchInput.value.trim().toLowerCase();
            
            equipmentCards.forEach(card => {
                const name = card.querySelector("h4").textContent.toLowerCase();
                const category = card.getAttribute("data-category").toLowerCase();
                const spec = card.querySelector("p") ? card.querySelector("p").textContent.toLowerCase() : "";
                
                if (name.includes(query) || category.includes(query) || spec.includes(query)) {
                    card.style.display = "";
                } else {
                    card.style.display = "none";
                }
            });
        });

        // Live search as you type
        globalSearchInput.addEventListener("input", function() {
            const query = globalSearchInput.value.trim().toLowerCase();
            
            equipmentCards.forEach(card => {
                const name = card.querySelector("h4").textContent.toLowerCase();
                const category = card.getAttribute("data-category").toLowerCase();
                const spec = card.querySelector("p") ? card.querySelector("p").textContent.toLowerCase() : "";
                
                if (name.includes(query) || category.includes(query) || spec.includes(query)) {
                    card.style.display = "";
                } else {
                    card.style.display = "none";
                }
            });
        });
    }

    // Notification functionality
    const notificationIcon = document.getElementById('notificationIcon');
    const notificationDropdown = document.getElementById('notificationDropdown');
    const notificationCount = document.getElementById('notificationCount');
    const notificationList = document.getElementById('notificationList');
    const markAllReadBtn = document.getElementById('markAllRead');

    // Load notification count
    function loadNotificationCount() {
        fetch('get_notifications.php?action=count')
            .then(response => response.json())
            .then(data => {
                if (data.count > 0) {
                    notificationCount.textContent = data.count;
                    notificationCount.style.display = 'block';
                } else {
                    notificationCount.style.display = 'none';
                }
            })
            .catch(error => console.error('Error loading notification count:', error));
    }

    // Load notifications
    function loadNotifications() {
        fetch('get_notifications.php?action=list&limit=10')
            .then(response => response.json())
            .then(data => {
                if (data.notifications && data.notifications.length > 0) {
                    let html = '';
                    data.notifications.forEach(notification => {
                        const isRead = notification.is_read ? 'read' : 'unread';
                        const timeAgo = getTimeAgo(notification.created_at);
                        html += `
                            <div class="notification-item ${isRead}" data-id="${notification.id}">
                                <div class="notification-content">
                                    <h5>${notification.title}</h5>
                                    <p>${notification.message}</p>
                                    <small>${timeAgo}</small>
                                </div>
                                ${!notification.is_read ? '<div class="unread-indicator"></div>' : ''}
                            </div>
                        `;
                    });
                    notificationList.innerHTML = html;
                } else {
                    notificationList.innerHTML = '<div class="no-notifications">No notifications</div>';
                }
            })
            .catch(error => console.error('Error loading notifications:', error));
    }

    // Get time ago
    function getTimeAgo(timestamp) {
        const now = new Date();
        const created = new Date(timestamp);
        const diffInSeconds = Math.floor((now - created) / 1000);
        
        if (diffInSeconds < 60) return 'Just now';
        if (diffInSeconds < 3600) return Math.floor(diffInSeconds / 60) + 'm ago';
        if (diffInSeconds < 86400) return Math.floor(diffInSeconds / 3600) + 'h ago';
        return Math.floor(diffInSeconds / 86400) + 'd ago';
    }

    // Toggle notification dropdown
    notificationIcon.addEventListener('click', function(e) {
        e.preventDefault();
        notificationDropdown.style.display = notificationDropdown.style.display === 'none' ? 'block' : 'none';
        if (notificationDropdown.style.display === 'block') {
            loadNotifications();
        }
    });

    // Mark all as read
    markAllReadBtn.addEventListener('click', function() {
        fetch('get_notifications.php?action=mark_all_read', {
            method: 'POST'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                loadNotificationCount();
                loadNotifications();
            }
        })
        .catch(error => console.error('Error marking all as read:', error));
    });

    // Mark individual notification as read
    notificationList.addEventListener('click', function(e) {
        const notificationItem = e.target.closest('.notification-item');
        if (notificationItem && !notificationItem.classList.contains('read')) {
            const notificationId = notificationItem.getAttribute('data-id');
            fetch('get_notifications.php?action=mark_read', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'notification_id=' + notificationId
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    notificationItem.classList.remove('unread');
                    notificationItem.classList.add('read');
                    notificationItem.querySelector('.unread-indicator')?.remove();
                    loadNotificationCount();
                }
            })
            .catch(error => console.error('Error marking notification as read:', error));
        }
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
        if (!notificationIcon.contains(e.target) && !notificationDropdown.contains(e.target)) {
            notificationDropdown.style.display = 'none';
        }
    });

    // Load notification count on page load
    loadNotificationCount();

    // Refresh notification count every 30 seconds
    setInterval(loadNotificationCount, 30000);

    // Simple sort toggle functionality
    const sortBtn = document.getElementById('sortBtn');
    let isReversed = false; // Track current sort state

    // Toggle sort order
    sortBtn.addEventListener('click', function() {
        isReversed = !isReversed; // Toggle the state
        
        // Sort the equipment cards
        sortEquipmentCards();
        
        // Update icon to show current state
        if (isReversed) {
            sortBtn.classList.add('reversed');
            sortBtn.title = "Oldest First (Click to reverse)";
        } else {
            sortBtn.classList.remove('reversed');
            sortBtn.title = "Newest First (Click to reverse)";
        }
    });

    // Function to sort equipment cards
    function sortEquipmentCards() {
        const equipmentGrid = document.querySelector('.equipment-grid');
        const cards = Array.from(equipmentGrid.querySelectorAll('.equipment-card'));
        
        cards.sort((a, b) => {
            const nameA = a.querySelector('h4').textContent.toLowerCase();
            const nameB = b.querySelector('h4').textContent.toLowerCase();
            
            if (isReversed) {
                return nameA.localeCompare(nameB); // A-Z (reversed)
            } else {
                return nameB.localeCompare(nameA); // Z-A (normal)
            }
        });
        
        // Clear and re-append sorted cards
        cards.forEach(card => equipmentGrid.appendChild(card));
        
        console.log(`Sorted equipment: ${isReversed ? 'A-Z' : 'Z-A'}`);
    }

    // View modal close functionality
    const closeViewModal = document.getElementById("closeViewModal");
    const viewItemModal = document.getElementById("viewItemModal");

    closeViewModal.addEventListener("click", function() {
        viewItemModal.style.display = "none";
    });

    window.addEventListener("click", function(event) {
        if (event.target == viewItemModal) {
            viewItemModal.style.display = "none";
        }
    });
});
</script>

<script src="script.js"></script>
</body>
</html>
