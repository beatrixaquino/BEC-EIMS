<?php
session_start();
header('Content-Type: application/json');

include_once "notification_helper.php";

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // For now, use user_id = 1 for super admin (you can change this later when user system is implemented)
    $user_id = 1;
} else {
    $user_id = $_SESSION['user_id'];
}
$user_role = getUserRole(); // Get user role for filtering
$action = $_GET['action'] ?? '';

switch ($action) {
    case 'count':
        // Get unread count
        $count = getUnreadNotificationsCount($user_id, $user_role);
        echo json_encode(['count' => $count]);
        break;
        
    case 'list':
        // Get notifications list
        $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 10;
        $offset = isset($_GET['offset']) ? intval($_GET['offset']) : 0;
        
        $notifications = getNotifications($user_id, $limit, $offset, $user_role);
        echo json_encode(['notifications' => $notifications]);
        break;
        
    case 'mark_read':
        // Mark notification as read
        $notification_id = isset($_POST['notification_id']) ? intval($_POST['notification_id']) : 0;
        
        if ($notification_id > 0) {
            $success = markNotificationAsRead($notification_id, $user_id);
            echo json_encode(['success' => $success]);
        } else {
            echo json_encode(['error' => 'Invalid notification ID']);
        }
        break;
        
    case 'mark_all_read':
        // Mark all notifications as read
        $success = markAllNotificationsAsRead($user_id);
        echo json_encode(['success' => $success]);
        break;
        
    default:
        echo json_encode(['error' => 'Invalid action']);
        break;
}
?> 