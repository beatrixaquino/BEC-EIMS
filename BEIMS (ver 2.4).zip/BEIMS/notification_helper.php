<?php
// Notification helper functions
include_once "dbconnect.php";

/**
 * Create a new notification
 */
function createNotification($user_id, $title, $message, $type, $related_id = null) {
    global $conn;
    
    $sql = "INSERT INTO notifications (user_id, title, message, type, related_id) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isssi", $user_id, $title, $message, $type, $related_id);
    
    return $stmt->execute();
}

/**
 * Get unread notifications count for a user (with role filtering)
 */
function getUnreadNotificationsCount($user_id, $user_role = 'admin') {
    global $conn;
    
    // Different queries based on user role
    switch ($user_role) {
        case 'student':
        case 'teacher':
            // Students/teachers only see their own form notifications
            $sql = "SELECT COUNT(*) as count FROM notifications 
                    WHERE user_id = ? AND is_read = FALSE 
                    AND type IN ('form_approved', 'form_rejected', 'form_submitted')";
            break;
            
        case 'admin':
            // Admins see form notifications and system notifications
            $sql = "SELECT COUNT(*) as count FROM notifications 
                    WHERE user_id = ? AND is_read = FALSE 
                    AND type IN ('new_form', 'form_approved', 'form_rejected', 'form_returned')";
            break;
            
        case 'super_admin':
        default:
            // Super admin sees everything
            $sql = "SELECT COUNT(*) as count FROM notifications 
                    WHERE user_id = ? AND is_read = FALSE";
            break;
    }
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    
    return $row['count'];
}

/**
 * Get notifications for a user (with role filtering)
 */
function getNotifications($user_id, $limit = 10, $offset = 0, $user_role = 'admin') {
    global $conn;
    
    // Different queries based on user role
    switch ($user_role) {
        case 'student':
        case 'teacher':
            // Students/teachers only see their own form notifications
            $sql = "SELECT * FROM notifications 
                    WHERE user_id = ? AND type IN ('form_approved', 'form_rejected', 'form_submitted')
                    ORDER BY created_at DESC LIMIT ? OFFSET ?";
            break;
            
        case 'admin':
            // Admins see form notifications and system notifications
            $sql = "SELECT * FROM notifications 
                    WHERE user_id = ? AND type IN ('new_form', 'form_approved', 'form_rejected', 'form_returned')
                    ORDER BY created_at DESC LIMIT ? OFFSET ?";
            break;
            
        case 'super_admin':
        default:
            // Super admin sees everything
            $sql = "SELECT * FROM notifications 
                    WHERE user_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?";
            break;
    }
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iii", $user_id, $limit, $offset);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $notifications = [];
    while ($row = $result->fetch_assoc()) {
        $notifications[] = $row;
    }
    
    return $notifications;
}

/**
 * Mark notification as read
 */
function markNotificationAsRead($notification_id, $user_id) {
    global $conn;
    
    $sql = "UPDATE notifications SET is_read = TRUE WHERE id = ? AND user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $notification_id, $user_id);
    
    return $stmt->execute();
}

/**
 * Mark all notifications as read for a user
 */
function markAllNotificationsAsRead($user_id) {
    global $conn;
    
    $sql = "UPDATE notifications SET is_read = TRUE WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    
    return $stmt->execute();
}

/**
 * Delete old notifications (older than 30 days)
 */
function cleanupOldNotifications() {
    global $conn;
    
    $sql = "DELETE FROM notifications WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)";
    $stmt = $conn->prepare($sql);
    
    return $stmt->execute();
}

/**
 * Get user role from session or default
 */
function getUserRole() {
    // For now, return 'super_admin' as default
    // Later, this would check $_SESSION['user_role'] or similar
    return 'super_admin';
}
?> 