-- Add status column to existing users table
-- Run this script if you have an existing users table without the status column

USE beims;

-- Add status column to users table
ALTER TABLE users ADD COLUMN status ENUM('active', 'inactive') DEFAULT 'active' AFTER acctype;

-- Update existing users to be active by default
UPDATE users SET status = 'active' WHERE status IS NULL;

-- Show the updated table structure
DESCRIBE users; 