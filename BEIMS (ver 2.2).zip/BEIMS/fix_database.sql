-- Fix the users table structure to prevent ID 0 issues
-- First, delete any records with ID 0
DELETE FROM users WHERE id = 0;

-- Make sure the id column is properly set up as AUTO_INCREMENT
-- This will ensure new records get proper IDs
ALTER TABLE users MODIFY id INT AUTO_INCREMENT PRIMARY KEY;

-- If the above doesn't work, try this alternative:
-- ALTER TABLE users DROP PRIMARY KEY;
-- ALTER TABLE users ADD PRIMARY KEY (id);
-- ALTER TABLE users MODIFY id INT AUTO_INCREMENT;

-- Show the current state of the users table
SELECT * FROM users ORDER BY id; 