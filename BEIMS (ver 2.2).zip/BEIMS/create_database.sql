-- BEIMS Database Schema
-- Equipment Inventory Management System

-- Use the database
USE beims;

-- Create categories table
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create item_list table
CREATE TABLE IF NOT EXISTS item_list (
    id INT AUTO_INCREMENT PRIMARY KEY,
    itemname VARCHAR(255) NOT NULL,
    specification TEXT,
    quantityreq INT DEFAULT 0,
    unit_req VARCHAR(50) DEFAULT 'pcs',
    quantityon INT DEFAULT 0,
    unit_on VARCHAR(50) DEFAULT 'pcs',
    difference VARCHAR(255),
    remarks TEXT,
    itemdescription TEXT,
    complianceauditone INT NULL,
    unit1 VARCHAR(50) NULL,
    complianceaudittwo INT NULL,
    unit2 VARCHAR(50) NULL,
    eqpphoto VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create item_categories junction table (many-to-many relationship)
CREATE TABLE IF NOT EXISTS item_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    item_id INT NOT NULL,
    category_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (item_id) REFERENCES item_list(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE,
    UNIQUE KEY unique_item_category (item_id, category_id)
);

-- Create borrowers table
CREATE TABLE IF NOT EXISTS borrowers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    idnum VARCHAR(50) NOT NULL,
    firstname VARCHAR(255) NOT NULL,
    middleinitial VARCHAR(10),
    lastname VARCHAR(255) NOT NULL,
    department VARCHAR(100) NOT NULL,
    course VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    cpnnumber VARCHAR(50) NOT NULL,
    borrow_date DATE NOT NULL,
    return_date DATE NOT NULL,
    formstatus ENUM('pending', 'approved', 'rejected', 'returned') DEFAULT 'pending',
    consent BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create requested_items table
CREATE TABLE IF NOT EXISTS requested_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    borrower_id INT NOT NULL,
    item_name VARCHAR(255) NOT NULL,
    quantity INT NOT NULL,
    date_needed DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (borrower_id) REFERENCES borrowers(id) ON DELETE CASCADE
);

-- Create users table (if not exists)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    acctype ENUM('admin', 'superadmin') DEFAULT 'admin',
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create students_info table (if not exists)
CREATE TABLE IF NOT EXISTS students_info (
    id INT AUTO_INCREMENT PRIMARY KEY,
    firstname VARCHAR(255) NOT NULL,
    middleinitial VARCHAR(10),
    lastname VARCHAR(255) NOT NULL,
    yearlvl VARCHAR(50),
    course VARCHAR(255),
    studidnum VARCHAR(50) UNIQUE,
    email VARCHAR(255),
    nameofgrdn VARCHAR(255),
    address TEXT,
    cpnnumber VARCHAR(50),
    idphoto LONGBLOB,
    regform LONGBLOB,
    signature LONGBLOB,
    consent BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert some default categories
INSERT INTO categories (name) VALUES 
('kitchenware'),
('electronics'),
('furniture'),
('tools'),
('sports'),
('office'),
('medical'),
('laboratory')
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- Insert default superadmin user (password: admin123)
INSERT INTO users (username, password, acctype) VALUES 
('superadmin', 'admin123', 'superadmin')
ON DUPLICATE KEY UPDATE username = VALUES(username);

-- Add status column to existing users table (if it doesn't exist)
ALTER TABLE users ADD COLUMN IF NOT EXISTS status ENUM('active', 'inactive') DEFAULT 'active' AFTER acctype;

-- Update existing users to be active by default (if status is NULL)
UPDATE users SET status = 'active' WHERE status IS NULL;

-- Show table structure
DESCRIBE categories;
DESCRIBE item_list;
DESCRIBE item_categories;
DESCRIBE borrowers;
DESCRIBE requested_items;
DESCRIBE users;
DESCRIBE students_info;
