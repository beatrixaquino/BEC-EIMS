<?php
include_once "dbconnect.php";

echo "<h2>🔍 Item List Table Structure Check</h2>";

// Check if item_list table exists and show its structure
echo "<h3>Item List Table Structure:</h3>";
$sql = "DESCRIBE item_list";
$result = $conn->query($sql);

if ($result) {
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr style='background: #f0f0f0;'><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td style='padding: 8px; border: 1px solid #ddd;'><strong>" . $row['Field'] . "</strong></td>";
        echo "<td style='padding: 8px; border: 1px solid #ddd;'>" . $row['Type'] . "</td>";
        echo "<td style='padding: 8px; border: 1px solid #ddd;'>" . $row['Null'] . "</td>";
        echo "<td style='padding: 8px; border: 1px solid #ddd;'>" . $row['Key'] . "</td>";
        echo "<td style='padding: 8px; border: 1px solid #ddd;'>" . $row['Default'] . "</td>";
        echo "<td style='padding: 8px; border: 1px solid #ddd;'>" . $row['Extra'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>Item_list table not found or error: " . $conn->error . "</p>";
}

// Show sample data
echo "<h3>Sample Item Data (ID 6 - Square Table Cloth):</h3>";
$sql = "SELECT * FROM item_list WHERE id = 6";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr style='background: #f0f0f0;'><th>Field</th><th>Value</th></tr>";
    foreach ($row as $field => $value) {
        $bgColor = ($value === null) ? '#ffe6e6' : '#f9f9f9';
        echo "<tr>";
        echo "<td style='padding: 8px; border: 1px solid #ddd; background: #f0f0f0;'><strong>" . $field . "</strong></td>";
        echo "<td style='padding: 8px; border: 1px solid #ddd; background: " . $bgColor . ";'>" . ($value === null ? '<em>NULL</em>' : htmlspecialchars($value)) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No data found for ID 6 or error: " . $conn->error . "</p>";
}

$conn->close();
?> 