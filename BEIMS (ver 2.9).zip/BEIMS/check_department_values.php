<?php
include_once "dbconnect.php";

echo "<h2>Checking Department Values in Database</h2>";

// Check what department values are stored
$sql = "SELECT DISTINCT department FROM borrowers ORDER BY department";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    echo "<h3>Department values in database:</h3>";
    echo "<ul>";
    while ($row = $result->fetch_assoc()) {
        echo "<li>" . htmlspecialchars($row['department']) . "</li>";
    }
    echo "</ul>";
} else {
    echo "<p>No department values found or error: " . $conn->error . "</p>";
}

// Show a few sample records
echo "<h3>Sample records:</h3>";
$sql = "SELECT id, firstname, lastname, department FROM borrowers LIMIT 5";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    echo "<table border='1'>";
    echo "<tr><th>ID</th><th>Name</th><th>Department</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['firstname'] . ' ' . $row['lastname']) . "</td>";
        echo "<td>" . htmlspecialchars($row['department']) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No records found.</p>";
}

$conn->close();
?> 