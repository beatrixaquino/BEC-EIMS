<?php
// Prevent direct access
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Start output buffering to prevent any HTML output
ob_start();

// Include database connection
require_once 'dbconnect.php';

// Set headers for JSON response
header('Content-Type: application/json');

try {
    // Get POST data
    $title = $_POST['title'] ?? '';
    $date = $_POST['date'] ?? '';
    $time = $_POST['time'] ?? '';
    $description = $_POST['description'] ?? '';
    $assignedTo = $_POST['assigned_to'] ?? '';
    
    // Validate required fields
    if (empty($title) || empty($date) || empty($time) || empty($assignedTo)) {
        throw new Exception('All required fields must be filled');
    }
    
    // Validate date format
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        throw new Exception('Invalid date format');
    }
    
    // Validate time format
    if (!preg_match('/^\d{2}:\d{2}$/', $time)) {
        throw new Exception('Invalid time format');
    }
    
    // Check if audit_schedule table exists, if not create it
    $checkTable = $conn->query("SHOW TABLES LIKE 'audit_schedule'");
    if ($checkTable->num_rows == 0) {
        // Create the table
        $createTable = "CREATE TABLE IF NOT EXISTS `audit_schedule` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `title` varchar(255) NOT NULL,
            `audit_date` date NOT NULL,
            `audit_time` time NOT NULL,
            `description` text,
            `assigned_to` varchar(100) NOT NULL,
            `status` enum('pending','in_progress','completed','cancelled') DEFAULT 'pending',
            `created_by` varchar(100) DEFAULT NULL,
            `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `idx_audit_date` (`audit_date`),
            KEY `idx_status` (`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        if (!$conn->query($createTable)) {
            throw new Exception('Failed to create audit_schedule table: ' . $conn->error);
        }
    }
    
    // Prepare and execute the insert statement
    $stmt = $conn->prepare("INSERT INTO audit_schedule (title, audit_date, audit_time, description, assigned_to, created_by) VALUES (?, ?, ?, ?, ?, ?)");
    
    if (!$stmt) {
        throw new Exception('Failed to prepare statement: ' . $conn->error);
    }
    
    $createdBy = 'superadmin'; // You can get this from session later
    
    $stmt->bind_param("ssssss", $title, $date, $time, $description, $assignedTo, $createdBy);
    
    if (!$stmt->execute()) {
        throw new Exception('Failed to save audit: ' . $stmt->error);
    }
    
    $auditId = $conn->insert_id;
    
    // Clear any output buffer
    ob_end_clean();
    
    // Return success response
    echo json_encode([
        'success' => true,
        'message' => 'Audit scheduled successfully',
        'audit_id' => $auditId,
        'data' => [
            'title' => $title,
            'date' => $date,
            'time' => $time,
            'description' => $description,
            'assigned_to' => $assignedTo
        ]
    ]);
    
} catch (Exception $e) {
    // Clear any output buffer
    ob_end_clean();
    
    // Return error response
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}

$conn->close();
?> 