<?php
require_once 'dbconnect.php';

echo "<h2>🔧 Adding Missing Columns to Equipment Audits Table</h2>";

try {
    // Check if columns already exist
    $checkDiff = $conn->query("SHOW COLUMNS FROM equipment_audits LIKE 'difference'");
    $checkAvail = $conn->query("SHOW COLUMNS FROM equipment_audits LIKE 'available'");
    
    if ($checkDiff->num_rows == 0) {
        echo "Adding 'difference' column...<br>";
        $conn->query("ALTER TABLE equipment_audits ADD COLUMN difference INT NULL COMMENT 'Surplus/Shortage: quantity_onsite - quantity_required' AFTER requirement_id");
        echo "✅ 'difference' column added successfully<br>";
    } else {
        echo "✅ 'difference' column already exists<br>";
    }
    
    if ($checkAvail->num_rows == 0) {
        echo "Adding 'available' column...<br>";
        $conn->query("ALTER TABLE equipment_audits ADD COLUMN available INT NULL COMMENT 'Available for borrowing: quantity_onsite - total_borrowed' AFTER difference");
        echo "✅ 'available' column added successfully<br>";
    } else {
        echo "✅ 'available' column already exists<br>";
    }
    
    // Show updated table structure
    echo "<h3>Updated Table Structure:</h3>";
    $structure = $conn->query("DESCRIBE equipment_audits");
    echo "<table border='1' style='border-collapse: collapse;'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    
    while ($row = $structure->fetch_assoc()) {
        echo "<tr>";
        echo "<td>{$row['Field']}</td>";
        echo "<td>{$row['Type']}</td>";
        echo "<td>{$row['Null']}</td>";
        echo "<td>{$row['Key']}</td>";
        echo "<td>{$row['Default']}</td>";
        echo "<td>{$row['Extra']}</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    echo "<br><strong>✅ Table structure updated successfully!</strong><br>";
    echo "<a href='test_audit_table.php'>Test the API again</a>";
    
} catch (Exception $e) {
    echo "<strong>❌ Error:</strong> " . $e->getMessage();
}
?> 