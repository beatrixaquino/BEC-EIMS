<?php
session_start();
include_once "dbconnect.php";

echo "<h2>Notification API Test</h2>";

// Simulate a logged-in user (superadmin)
$_SESSION['user_id'] = 1;
$_SESSION['acctype'] = 'superadmin';

echo "<h3>Session Info:</h3>";
echo "<p>User ID: " . $_SESSION['user_id'] . "</p>";
echo "<p>Account Type: " . $_SESSION['acctype'] . "</p>";

// Test the count endpoint
echo "<h3>Testing Count Endpoint:</h3>";
include_once "get_notifications.php";

// Test creating a notification first
echo "<h3>Creating Test Notification:</h3>";
$sql = "INSERT INTO notifications (user_id, title, message, type, created_at) VALUES (1, 'Test Notification', 'This is a test notification', 'test', NOW())";
$result = $conn->query($sql);

if ($result) {
    echo "<p style='color: green;'>✅ Test notification created</p>";
    
    // Now test the count endpoint
    echo "<h3>Testing Count After Creation:</h3>";
    $count_sql = "SELECT COUNT(*) as count FROM notifications WHERE is_read = FALSE";
    $count_result = $conn->query($count_sql);
    $count_row = $count_result->fetch_assoc();
    echo "<p>Unread notifications: " . $count_row['count'] . "</p>";
    
    // Test the list endpoint
    echo "<h3>Testing List Endpoint:</h3>";
    $list_sql = "SELECT * FROM notifications ORDER BY created_at DESC LIMIT 5";
    $list_result = $conn->query($list_sql);
    
    if ($list_result->num_rows > 0) {
        echo "<table border='1' style='border-collapse: collapse;'>";
        echo "<tr><th>ID</th><th>User ID</th><th>Title</th><th>Message</th><th>Type</th><th>Is Read</th></tr>";
        while ($row = $list_result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row['id'] . "</td>";
            echo "<td>" . $row['user_id'] . "</td>";
            echo "<td>" . htmlspecialchars($row['title']) . "</td>";
            echo "<td>" . htmlspecialchars($row['message']) . "</td>";
            echo "<td>" . $row['type'] . "</td>";
            echo "<td>" . ($row['is_read'] ? 'Yes' : 'No') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
    // Clean up test notification
    $cleanup_sql = "DELETE FROM notifications WHERE type = 'test'";
    $conn->query($cleanup_sql);
    echo "<p>Test notification cleaned up</p>";
} else {
    echo "<p style='color: red;'>❌ Failed to create test notification</p>";
    echo "<p>Error: " . $conn->error . "</p>";
}
?> 