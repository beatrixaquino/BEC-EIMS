<?php
// Equipment Audit Functions
require_once 'dbconnect.php';

/**
 * Save equipment audit entries
 */
function saveEquipmentAudits($itemId, $audits) {
    global $conn;
    
    try {
        // Start transaction
        $conn->begin_transaction();
        
        // Delete existing audits for this item (if updating)
        $deleteStmt = $conn->prepare("DELETE FROM equipment_audits WHERE item_id = ?");
        $deleteStmt->bind_param("i", $itemId);
        $deleteStmt->execute();
        
        // Insert new audit entries
        $insertStmt = $conn->prepare("
            INSERT INTO equipment_audits (item_id, quantity_onsite, unit, audit_date, semester, requirement_id, difference, available) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        foreach ($audits as $audit) {
            $requirementId = !empty($audit['requirement_id']) ? $audit['requirement_id'] : null;
            $difference = isset($audit['difference']) ? $audit['difference'] : null;
            $available = isset($audit['available']) ? $audit['available'] : null;
            
            $insertStmt->bind_param("iisssiii", 
                $itemId,
                $audit['quantity_onsite'],
                $audit['unit'],
                $audit['audit_date'],
                $audit['semester'],
                $requirementId,
                $difference,
                $available
            );
            $insertStmt->execute();
        }
        
        // Commit transaction
        $conn->commit();
        return ['success' => true, 'message' => 'Audit entries saved successfully'];
        
    } catch (Exception $e) {
        // Rollback transaction on error
        $conn->rollback();
        return ['success' => false, 'error' => 'Database error: ' . $e->getMessage()];
    }
}

/**
 * Get equipment audits for a specific item
 */
function getEquipmentAudits($itemId) {
    global $conn;
    
    try {
        $stmt = $conn->prepare("
            SELECT ea.*, er.quantity_required, er.unit as required_unit
            FROM equipment_audits ea
            LEFT JOIN equipment_requirements er ON ea.requirement_id = er.id
            WHERE ea.item_id = ?
            ORDER BY ea.audit_date DESC, ea.created_at DESC
        ");
        
        $stmt->bind_param("i", $itemId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $audits = [];
        while ($row = $result->fetch_assoc()) {
            $audits[] = $row;
        }
        
        return ['success' => true, 'audits' => $audits];
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => 'Database error: ' . $e->getMessage()];
    }
}

/**
 * Delete a specific audit entry
 */
function deleteEquipmentAudit($auditId) {
    global $conn;
    
    try {
        $stmt = $conn->prepare("DELETE FROM equipment_audits WHERE id = ?");
        $stmt->bind_param("i", $auditId);
        $stmt->execute();
        
        if ($stmt->affected_rows > 0) {
            return ['success' => true, 'message' => 'Audit entry deleted successfully'];
        } else {
            return ['success' => false, 'error' => 'Audit entry not found'];
        }
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => 'Database error: ' . $e->getMessage()];
    }
}

/**
 * Get semester options for dropdown
 */
function getSemesterOptions() {
    return [
        "1st Semester",
        "2nd Semester", 
        "Summer",
        "Midyear"
    ];
}

/**
 * Calculate difference between audit quantity and requirement
 */
function calculateAuditDifference($auditQuantity, $auditUnit, $requiredQuantity, $requiredUnit) {
    // Simple comparison - in real implementation, you might need unit conversion
    if ($auditUnit === $requiredUnit) {
        return $auditQuantity - $requiredQuantity;
    }
    return null; // Cannot compare different units
}
?> 