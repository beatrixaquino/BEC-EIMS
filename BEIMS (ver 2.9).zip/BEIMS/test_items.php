<?php
include_once "dbconnect.php";

echo "<h2>Testing Requested Items Table</h2>";

// Check if requested_items table exists and has data
$sql = "SELECT COUNT(*) as count FROM requested_items";
$result = $conn->query($sql);
if ($result) {
    $row = $result->fetch_assoc();
    echo "<p>Total items in requested_items table: " . $row['count'] . "</p>";
} else {
    echo "<p>Error: " . $conn->error . "</p>";
}

// Show sample data
$sql = "SELECT * FROM requested_items LIMIT 5";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    echo "<h3>Sample requested_items data:</h3>";
    echo "<table border='1'>";
    echo "<tr><th>ID</th><th>Borrower ID</th><th>Item ID</th><th>Quantity</th><th>Unit</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['borrower_id'] . "</td>";
        echo "<td>" . $row['item_id'] . "</td>";
        echo "<td>" . $row['quantity'] . "</td>";
        echo "<td>" . $row['unit'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No data found in requested_items table</p>";
}

// Check item_list table
$sql = "SELECT COUNT(*) as count FROM item_list";
$result = $conn->query($sql);
if ($result) {
    $row = $result->fetch_assoc();
    echo "<p>Total items in item_list table: " . $row['count'] . "</p>";
} else {
    echo "<p>Error: " . $conn->error . "</p>";
}

// Test the join query
$sql = "SELECT il.itemname as item_name, ri.quantity, ri.unit 
        FROM requested_items ri 
        JOIN item_list il ON ri.item_id = il.id 
        LIMIT 5";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    echo "<h3>Sample joined data:</h3>";
    echo "<table border='1'>";
    echo "<tr><th>Item Name</th><th>Quantity</th><th>Unit</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['item_name'] . "</td>";
        echo "<td>" . $row['quantity'] . "</td>";
        echo "<td>" . $row['unit'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No joined data found</p>";
}

$conn->close();
?> 