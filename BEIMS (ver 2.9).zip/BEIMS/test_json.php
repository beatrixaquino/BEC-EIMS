<?php
// Test to see if there's any HTML output before JSON
header('Content-Type: application/json');

// Test the database connection
include_once "dbconnect.php";

// Simple test query
$sql = "SELECT COUNT(*) as count FROM borrowers WHERE deleted_at IS NULL";
$result = $conn->query($sql);

if ($result) {
    $row = $result->fetch_assoc();
    echo json_encode([
        "success" => true,
        "borrower_count" => $row['count'],
        "message" => "Database connection successful"
    ]);
} else {
    echo json_encode([
        "success" => false,
        "error" => $conn->error,
        "message" => "Database connection failed"
    ]);
}

$conn->close();
?> 