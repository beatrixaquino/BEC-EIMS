<?php
// Simple test to verify calculation logic
require_once 'dbconnect.php';

echo "<h2>🔍 Simple Calculation Test</h2>";

// Test 1: Check database connection
echo "<h3>Test 1: Database Connection</h3>";
if (isset($conn)) {
    echo "✅ Database connection successful<br>";
} else {
    echo "❌ Database connection failed<br>";
    exit;
}

// Test 2: Check if equipment_requirements table has data
echo "<h3>Test 2: Equipment Requirements Data</h3>";
$result = $conn->query("SELECT COUNT(*) as count FROM equipment_requirements");
if ($result) {
    $count = $result->fetch_assoc()['count'];
    echo "✅ Equipment requirements count: $count<br>";
    
    if ($count > 0) {
        $items = $conn->query("SELECT item_name, quantity_required FROM equipment_requirements LIMIT 5");
        echo "Sample items:<br>";
        while ($row = $items->fetch_assoc()) {
            echo "- {$row['item_name']}: {$row['quantity_required']} pcs<br>";
        }
    }
} else {
    echo "❌ Error checking equipment_requirements table<br>";
}

// Test 3: Test calculation logic
echo "<h3>Test 3: Manual Calculation</h3>";
$itemName = "Menu Folder";
$quantityOnSite = 25;

// Get required quantity
$stmt = $conn->prepare("SELECT quantity_required FROM equipment_requirements WHERE item_name = ?");
$stmt->bind_param("s", $itemName);
$stmt->execute();
$result = $stmt->get_result();
$required = $result->fetch_assoc()['quantity_required'] ?? 0;

// Calculate difference
$difference = $quantityOnSite - $required;

echo "Item: $itemName<br>";
echo "Quantity Required: $required<br>";
echo "Quantity On Site: $quantityOnSite<br>";
echo "Difference: $difference (" . ($difference >= 0 ? "Surplus" : "Shortage") . ")<br>";

// Test 4: Check if requested_items table exists
echo "<h3>Test 4: Borrowed Items Check</h3>";
$tableCheck = $conn->query("SHOW TABLES LIKE 'requested_items'");
if ($tableCheck->num_rows > 0) {
    echo "✅ requested_items table exists<br>";
    
    // Check for borrowed items
    $borrowedResult = $conn->query("SELECT COUNT(*) as count FROM requested_items");
    $borrowedCount = $borrowedResult->fetch_assoc()['count'];
    echo "Borrowed items count: $borrowedCount<br>";
} else {
    echo "❌ requested_items table does not exist<br>";
    echo "Available for borrowing will show 0<br>";
}

echo "<h3>✅ Test Complete!</h3>";
echo "<p>If all tests pass, the calculation system should work in the audit form.</p>";
?> 