<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notification Test</title>
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="istyle.css">
</head>
<body>
    <div style="padding: 20px;">
        <h1>Notification System Test</h1>
        
        <!-- Test notification elements -->
        <div style="margin: 20px 0;">
            <a href="#" class="notification" id="notificationIcon">
                <i class='bx bxs-bell'></i>
                <span class="num" id="notificationCount">0</span>
            </a>
            <div class="notification-dropdown" id="notificationDropdown" style="display: none;">
                <div class="notification-header">
                    <h4>Notifications</h4>
                    <button id="markAllRead" class="mark-all-read">Mark all read</button>
                </div>
                <div class="notification-list" id="notificationList">
                    <!-- Notifications will be loaded here -->
                </div>
            </div>
        </div>
        
        <div style="margin: 20px 0;">
            <button onclick="testNotificationCount()">Test Notification Count</button>
            <button onclick="testNotificationList()">Test Notification List</button>
            <button onclick="checkElements()">Check Elements</button>
        </div>
        
        <div id="debugOutput" style="margin: 20px 0; padding: 10px; background: #f0f0f0; border: 1px solid #ccc;">
            <h3>Debug Output:</h3>
            <div id="debugContent"></div>
        </div>
    </div>

    <script src="script.js"></script>
    <script src="notification.js"></script>
    
    <script>
        function checkElements() {
            const elements = {
                notificationIcon: document.getElementById('notificationIcon'),
                notificationDropdown: document.getElementById('notificationDropdown'),
                notificationCount: document.getElementById('notificationCount'),
                notificationList: document.getElementById('notificationList'),
                markAllRead: document.getElementById('markAllRead')
            };
            
            let output = '<h4>Element Check Results:</h4>';
            for (const [name, element] of Object.entries(elements)) {
                output += `<p>${name}: ${element ? '✅ Found' : '❌ Not found'}</p>`;
            }
            
            document.getElementById('debugContent').innerHTML = output;
        }
        
        function testNotificationCount() {
            console.log('Testing notification count...');
            fetch('get_notifications.php?action=count')
                .then(response => {
                    console.log('Response status:', response.status);
                    return response.json();
                })
                .then(data => {
                    console.log('Notification count data:', data);
                    document.getElementById('debugContent').innerHTML = 
                        `<h4>Notification Count Test:</h4><p>Response: ${JSON.stringify(data)}</p>`;
                })
                .catch(error => {
                    console.error('Error:', error);
                    document.getElementById('debugContent').innerHTML = 
                        `<h4>Notification Count Test:</h4><p>Error: ${error.message}</p>`;
                });
        }
        
        function testNotificationList() {
            console.log('Testing notification list...');
            fetch('get_notifications.php?action=list&limit=5')
                .then(response => {
                    console.log('Response status:', response.status);
                    return response.json();
                })
                .then(data => {
                    console.log('Notification list data:', data);
                    document.getElementById('debugContent').innerHTML = 
                        `<h4>Notification List Test:</h4><p>Response: ${JSON.stringify(data)}</p>`;
                })
                .catch(error => {
                    console.error('Error:', error);
                    document.getElementById('debugContent').innerHTML = 
                        `<h4>Notification List Test:</h4><p>Error: ${error.message}</p>`;
                });
        }
        
        // Check elements on page load
        document.addEventListener('DOMContentLoaded', function() {
            console.log('Page loaded, checking elements...');
            checkElements();
        });
    </script>
</body>
</html> 