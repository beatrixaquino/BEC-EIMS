<?php
// Notification helper functions
include_once "dbconnect.php";
include_once "notification_system.php"; // Include the new notification system

/**
 * Create a new notification (legacy function for backward compatibility)
 */
function createNotification($user_id, $title, $message, $type, $related_id = null) {
    $notificationSystem = getNotificationSystem();
    return $notificationSystem->createNotification($user_id, $title, $message, $type, $related_id);
}

/**
 * Get unread notifications count for a user (with role filtering)
 */
function getUnreadNotificationsCount($user_id, $user_role = 'admin') {
    global $conn;
    
    error_log("getUnreadNotificationsCount called - User ID: $user_id, Role: $user_role");
    
    // Different queries based on user role
    switch ($user_role) {
        case 'borrower':
        case 'student':
        case 'teacher':
            // Borrowers only see their own form notifications
            $sql = "SELECT COUNT(*) as count FROM notifications 
                    WHERE user_id = ? AND is_read = FALSE 
                    AND type IN ('form_submitted', 'form_approved', 'form_rejected', 'form_failed', 'due_soon', 'overdue_item', 'return_received', 'item_unavailable')";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $user_id);
            break;
            
        case 'admin':
            // Admins see form notifications and system notifications
            $sql = "SELECT COUNT(*) as count FROM notifications 
                    WHERE user_id = ? AND is_read = FALSE 
                    AND type IN ('new_form', 'form_approved', 'form_rejected', 'form_returned', 'equipment_added', 'equipment_edited', 'equipment_deleted', 'overdue_item_exists', 'item_running_low')";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $user_id);
            break;
            
        case 'superadmin':
        case 'super_admin':
            // Super admin sees ALL notifications (no user_id filter)
            $sql = "SELECT COUNT(*) as count FROM notifications 
                    WHERE is_read = FALSE";
            $stmt = $conn->prepare($sql);
            break;
            
        default:
            // Default to borrower view
            $sql = "SELECT COUNT(*) as count FROM notifications 
                    WHERE user_id = ? AND is_read = FALSE 
                    AND type IN ('form_submitted', 'form_approved', 'form_rejected', 'form_failed', 'due_soon', 'overdue_item', 'return_received', 'item_unavailable')";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $user_id);
            break;
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    
    $count = $row['count'];
    error_log("getUnreadNotificationsCount result: $count");
    
    return $count;
}

/**
 * Get notifications for a user (with role filtering)
 */
function getNotifications($user_id, $limit = 10, $offset = 0, $user_role = 'admin') {
    global $conn;
    
    error_log("getNotifications called - User ID: $user_id, Role: $user_role, Limit: $limit, Offset: $offset");
    
    // Different queries based on user role
    switch ($user_role) {
        case 'borrower':
        case 'student':
        case 'teacher':
            // Borrowers only see their own form notifications
            $sql = "SELECT * FROM notifications 
                    WHERE user_id = ? AND type IN ('form_submitted', 'form_approved', 'form_rejected', 'form_failed', 'due_soon', 'overdue_item', 'return_received', 'item_unavailable')
                    ORDER BY created_at DESC LIMIT ? OFFSET ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("iii", $user_id, $limit, $offset);
            break;
            
        case 'admin':
            // Admins see form notifications and system notifications
            $sql = "SELECT * FROM notifications 
                    WHERE user_id = ? AND type IN ('new_form', 'form_approved', 'form_rejected', 'form_returned', 'equipment_added', 'equipment_edited', 'equipment_deleted', 'overdue_item_exists', 'item_running_low')
                    ORDER BY created_at DESC LIMIT ? OFFSET ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("iii", $user_id, $limit, $offset);
            break;
            
        case 'superadmin':
        case 'super_admin':
            // Super admin sees ALL notifications (no user_id filter)
            $sql = "SELECT * FROM notifications 
                    ORDER BY created_at DESC LIMIT ? OFFSET ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ii", $limit, $offset);
            break;
            
        default:
            // Default to borrower view
            $sql = "SELECT * FROM notifications 
                    WHERE user_id = ? AND type IN ('form_submitted', 'form_approved', 'form_rejected', 'form_failed', 'due_soon', 'overdue_item', 'return_received', 'item_unavailable')
                    ORDER BY created_at DESC LIMIT ? OFFSET ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("iii", $user_id, $limit, $offset);
            break;
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    $notifications = [];
    while ($row = $result->fetch_assoc()) {
        $notifications[] = $row;
    }
    
    error_log("getNotifications result: " . count($notifications) . " notifications found");
    
    return $notifications;
}

/**
 * Mark notification as read
 */
function markNotificationAsRead($notification_id, $user_id) {
    global $conn;
    
    // Get user role to determine scope
    $user_role = getUserRole();
    
    if ($user_role === 'super_admin') {
        // Super admin can mark any notification as read
        $sql = "UPDATE notifications SET is_read = TRUE WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $notification_id);
    } else {
        // Other users can only mark their own notifications as read
        $sql = "UPDATE notifications SET is_read = TRUE WHERE id = ? AND user_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $notification_id, $user_id);
    }
    
    return $stmt->execute();
}

/**
 * Mark all notifications as read for a user
 */
function markAllNotificationsAsRead($user_id) {
    global $conn;
    
    // Get user role to determine scope
    $user_role = getUserRole();
    
    if ($user_role === 'super_admin') {
        // Super admin can mark all notifications as read
        $sql = "UPDATE notifications SET is_read = TRUE";
        $stmt = $conn->prepare($sql);
    } else {
        // Other users can only mark their own notifications as read
        $sql = "UPDATE notifications SET is_read = TRUE WHERE user_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
    }
    
    return $stmt->execute();
}

/**
 * Delete old notifications (older than 30 days)
 */
function cleanupOldNotifications() {
    global $conn;
    
    $sql = "DELETE FROM notifications WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)";
    $stmt = $conn->prepare($sql);
    
    return $stmt->execute();
}

/**
 * Get user role from session or default
 */
function getUserRole() {
    $acctype = $_SESSION['acctype'] ?? 'not set';
    error_log("getUserRole called - Session acctype: $acctype");
    
    if (isset($_SESSION['acctype'])) {
        switch ($_SESSION['acctype']) {
            case 'student':
                $role = 'student';
                break;
            case 'teacher':
                $role = 'teacher';
                break;
            case 'admin':
                $role = 'admin';
                break;
            case 'superadmin':
                $role = 'super_admin';
                break;
            default:
                $role = 'student';
                break;
        }
        error_log("getUserRole returning: $role");
        return $role;
    }
    error_log("getUserRole returning default: student");
    return 'student'; // Default to student if no session
}
?> 