<?php
session_start();
header('Content-Type: application/json');

include_once "notification_helper.php";

// Debug logging
error_log("Notification API called - User ID: " . ($_SESSION['user_id'] ?? 'not set') . ", Action: " . ($_GET['action'] ?? 'not set'));

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // Return error if not logged in
    echo json_encode(['error' => 'User not logged in']);
    exit();
}

$user_id = $_SESSION['user_id'];
$user_role = getUserRole(); // Get user role for filtering
$action = $_GET['action'] ?? '';

error_log("User ID: $user_id, User Role: $user_role, Action: $action");

switch ($action) {
    case 'count':
        // Get unread count
        error_log("Getting unread count for user $user_id with role $user_role");
        $count = getUnreadNotificationsCount($user_id, $user_role);
        error_log("Unread count: $count");
        echo json_encode(['count' => $count]);
        break;
        
    case 'list':
        // Get notifications list
        $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 10;
        $offset = isset($_GET['offset']) ? intval($_GET['offset']) : 0;
        
        error_log("Getting notifications list for user $user_id with role $user_role, limit: $limit, offset: $offset");
        $notifications = getNotifications($user_id, $limit, $offset, $user_role);
        error_log("Found " . count($notifications) . " notifications");
        echo json_encode(['notifications' => $notifications]);
        break;
        
    case 'mark_read':
        // Mark notification as read
        $notification_id = isset($_POST['notification_id']) ? intval($_POST['notification_id']) : 0;
        
        if ($notification_id > 0) {
            $success = markNotificationAsRead($notification_id, $user_id);
            echo json_encode(['success' => $success]);
        } else {
            echo json_encode(['error' => 'Invalid notification ID']);
        }
        break;
        
    case 'mark_all_read':
        // Mark all notifications as read
        $success = markAllNotificationsAsRead($user_id);
        echo json_encode(['success' => $success]);
        break;
        
    default:
        echo json_encode(['error' => 'Invalid action']);
        break;
}
?> 