<?php
require_once 'dbconnect.php';

echo "<h2>🔍 Requested Items Table Structure</h2>";

// Check if requested_items table exists
$tableCheck = $conn->query("SHOW TABLES LIKE 'requested_items'");
if ($tableCheck->num_rows > 0) {
    echo "✅ requested_items table exists<br><br>";
    
    // Get table structure
    $structure = $conn->query("DESCRIBE requested_items");
    echo "<h3>Table Structure:</h3>";
    echo "<table border='1' style='border-collapse: collapse;'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    
    while ($row = $structure->fetch_assoc()) {
        echo "<tr>";
        echo "<td>{$row['Field']}</td>";
        echo "<td>{$row['Type']}</td>";
        echo "<td>{$row['Null']}</td>";
        echo "<td>{$row['Key']}</td>";
        echo "<td>{$row['Default']}</td>";
        echo "<td>{$row['Extra']}</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // Check sample data
    echo "<h3>Sample Data:</h3>";
    $sample = $conn->query("SELECT * FROM requested_items LIMIT 3");
    if ($sample->num_rows > 0) {
        echo "<table border='1' style='border-collapse: collapse;'>";
        $first = true;
        while ($row = $sample->fetch_assoc()) {
            if ($first) {
                echo "<tr>";
                foreach (array_keys($row) as $key) {
                    echo "<th>$key</th>";
                }
                echo "</tr>";
                $first = false;
            }
            echo "<tr>";
            foreach ($row as $value) {
                echo "<td>" . htmlspecialchars($value) . "</td>";
            }
            echo "</tr>";
        }
        echo "</table>";
    }
    
} else {
    echo "❌ requested_items table does not exist";
}
?> 