<?php

$servername = "localhost";
$username = "root";
$password = "bea092203";
$db = "beims";
$port = 3306; // Updated port number

// Correct the variable names in the mysqli_connect function
$conn = mysqli_connect($servername, $username, $password, $db, $port);

if(!$conn) {
    // Check if we're expecting JSON output
    if (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false) {
        header('Content-Type: application/json');
        echo json_encode(["error" => "Database connection failed: " . mysqli_connect_error()]);
        exit;
    } else {
        die("Connection Failed: ".mysqli_connect_error());
    }
}
?>