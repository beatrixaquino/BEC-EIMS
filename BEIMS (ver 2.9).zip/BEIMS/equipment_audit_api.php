<?php
// Equipment Audit API
header('Content-Type: application/json');
require_once 'equipment_audit_functions.php';

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'save':
        handleSaveAudits();
        break;
    case 'get':
        handleGetAudits();
        break;
    case 'delete':
        handleDeleteAudit();
        break;
    case 'calculate':
        handleCalculateAudit();
        break;
    case 'check_data':
        handleCheckData();
        break;
    default:
        echo json_encode(['success' => false, 'error' => 'Invalid action']);
}

function handleSaveAudits() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['success' => false, 'error' => 'Method not allowed']);
        return;
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['item_id']) || !isset($input['audits'])) {
        echo json_encode(['success' => false, 'error' => 'Missing required fields']);
        return;
    }
    
    $itemId = intval($input['item_id']);
    $audits = $input['audits'];
    
    // Validate audit data
    foreach ($audits as $audit) {
        if (!isset($audit['quantity_onsite']) || !isset($audit['audit_date']) || !isset($audit['semester'])) {
            echo json_encode(['success' => false, 'error' => 'Invalid audit data']);
            return;
        }
    }
    
    $result = saveEquipmentAudits($itemId, $audits);
    echo json_encode($result);
}

function handleGetAudits() {
    if (!isset($_GET['item_id'])) {
        echo json_encode(['success' => false, 'error' => 'Missing item_id']);
        return;
    }
    
    $itemId = intval($_GET['item_id']);
    $result = getEquipmentAudits($itemId);
    echo json_encode($result);
}

function handleDeleteAudit() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['success' => false, 'error' => 'Method not allowed']);
        return;
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['audit_id'])) {
        echo json_encode(['success' => false, 'error' => 'Missing audit_id']);
        return;
    }
    
    $auditId = intval($input['audit_id']);
    $result = deleteEquipmentAudit($auditId);
    echo json_encode($result);
}

function handleCalculateAudit() {
    if (!isset($_GET['item_id']) || !isset($_GET['semester'])) {
        echo json_encode(['success' => false, 'error' => 'Missing item_id or semester']);
        return;
    }
    
    $itemId = intval($_GET['item_id']);
    $semester = $_GET['semester'];
    
    try {
        // Ensure database connection is available
        if (!isset($conn)) {
            require_once 'dbconnect.php';
        }
        
        // Get quantity required from equipment_requirements table
        // Since the table doesn't have item_id and semester, we'll use the item name from item_list
        $itemQuery = "SELECT itemname FROM item_list WHERE id = ?";
        $itemStmt = $conn->prepare($itemQuery);
        $itemStmt->bind_param("i", $itemId);
        $itemStmt->execute();
        $itemResult = $itemStmt->get_result();
        $itemName = $itemResult->fetch_assoc()['itemname'] ?? '';
        
        // Get quantity required by matching item name
        $requiredQuery = "SELECT quantity_required FROM equipment_requirements 
                         WHERE item_name = ?";
        $requiredStmt = $conn->prepare($requiredQuery);
        $requiredStmt->bind_param("s", $itemName);
        $requiredStmt->execute();
        $requiredResult = $requiredStmt->get_result();
        $quantityRequired = $requiredResult->fetch_assoc()['quantity_required'] ?? 0;
        
        // Get total borrowed quantity for this item and semester
        // First, let's check if requested_items table exists and has the right structure
        $tableCheckQuery = "SHOW TABLES LIKE 'requested_items'";
        $tableCheckResult = $conn->query($tableCheckQuery);
        
        if ($tableCheckResult->num_rows > 0) {
            // Try to get borrowed quantity from requested_items
            $borrowedQuery = "SELECT SUM(quantity) as total_borrowed 
                             FROM requested_items ri 
                             JOIN borrowers b ON ri.borrower_id = b.id 
                             WHERE ri.item_id = ? AND b.semester LIKE ? 
                             AND b.status IN ('pending', 'approved')";
            $semesterPattern = $semester . '%';
            $borrowedStmt = $conn->prepare($borrowedQuery);
            $borrowedStmt->bind_param("is", $itemId, $semesterPattern);
            $borrowedStmt->execute();
            $borrowedResult = $borrowedStmt->get_result();
            $totalBorrowed = $borrowedResult->fetch_assoc()['total_borrowed'] ?? 0;
        } else {
            // Fallback: check if there's a different table structure
            // For now, set to 0 if table doesn't exist
            $totalBorrowed = 0;
        }
        
        echo json_encode([
            'success' => true,
            'quantity_required' => intval($quantityRequired),
            'total_borrowed' => intval($totalBorrowed)
        ]);
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
}

function handleCheckData() {
    try {
        // Ensure database connection is available
        if (!isset($conn)) {
            require_once 'dbconnect.php';
        }
        
        // Check equipment_requirements
        $reqResult = $conn->query("SELECT COUNT(*) as count FROM equipment_requirements");
        $requirementsCount = $reqResult->fetch_assoc()['count'];
        
        // Check item_list
        $itemsResult = $conn->query("SELECT COUNT(*) as count FROM item_list");
        $itemsCount = $itemsResult->fetch_assoc()['count'];
        
        // Check borrowers
        $borrowersResult = $conn->query("SELECT COUNT(*) as count FROM borrowers");
        $borrowersCount = $borrowersResult->fetch_assoc()['count'];
        
        echo json_encode([
            'success' => true,
            'requirements_count' => intval($requirementsCount),
            'items_count' => intval($itemsCount),
            'borrowers_count' => intval($borrowersCount)
        ]);
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
}
?> 