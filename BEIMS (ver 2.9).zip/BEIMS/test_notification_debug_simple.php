<?php
session_start();
include_once "dbconnect.php";
include_once "notification_helper.php";

echo "<h2>Simple Notification Debug Test</h2>";

// Check session
echo "<h3>1. Session Check:</h3>";
if (isset($_SESSION['user_id'])) {
    echo "<p style='color: green;'>✅ User logged in - ID: " . $_SESSION['user_id'] . "</p>";
    echo "<p>Account type: " . ($_SESSION['acctype'] ?? 'Not set') . "</p>";
} else {
    echo "<p style='color: red;'>❌ User not logged in</p>";
    echo "<p>Session data: " . print_r($_SESSION, true) . "</p>";
}

// Test getUserRole
echo "<h3>2. User Role Test:</h3>";
$user_role = getUserRole();
echo "<p>User role: " . $user_role . "</p>";

// Check database
echo "<h3>3. Database Check:</h3>";
$result = $conn->query("SELECT COUNT(*) as total FROM notifications");
$row = $result->fetch_assoc();
echo "<p>Total notifications in database: " . $row['total'] . "</p>";

$result = $conn->query("SELECT COUNT(*) as unread FROM notifications WHERE is_read = FALSE");
$row = $result->fetch_assoc();
echo "<p>Unread notifications: " . $row['unread'] . "</p>";

// Test the functions directly
if (isset($_SESSION['user_id'])) {
    echo "<h3>4. Function Tests:</h3>";
    
    $count = getUnreadNotificationsCount($_SESSION['user_id'], $user_role);
    echo "<p>getUnreadNotificationsCount result: " . $count . "</p>";
    
    $notifications = getNotifications($_SESSION['user_id'], 10, 0, $user_role);
    echo "<p>getNotifications result: " . count($notifications) . " notifications</p>";
    
    if (count($notifications) > 0) {
        echo "<h4>Sample Notification:</h4>";
        $sample = $notifications[0];
        echo "<p>ID: " . $sample['id'] . "</p>";
        echo "<p>Title: " . htmlspecialchars($sample['title']) . "</p>";
        echo "<p>Message: " . htmlspecialchars($sample['message']) . "</p>";
        echo "<p>Type: " . $sample['type'] . "</p>";
        echo "<p>User ID: " . $sample['user_id'] . "</p>";
    }
}

// Test API endpoint directly
echo "<h3>5. API Endpoint Test:</h3>";
if (isset($_SESSION['user_id'])) {
    $url = "get_notifications.php?action=count";
    echo "<p>Testing: " . $url . "</p>";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_COOKIE, "PHPSESSID=" . session_id());
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    echo "<p>HTTP Code: " . $httpCode . "</p>";
    echo "<p>Response: " . htmlspecialchars($response) . "</p>";
    
    // Test list endpoint
    $url = "get_notifications.php?action=list&limit=5";
    echo "<p>Testing: " . $url . "</p>";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_COOKIE, "PHPSESSID=" . session_id());
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    echo "<p>HTTP Code: " . $httpCode . "</p>";
    echo "<p>Response: " . htmlspecialchars($response) . "</p>";
}
?> 