-- Add calculation fields to equipment_audits table
ALTER TABLE `equipment_audits` 
ADD COLUMN `difference` INT NULL COMMENT 'Surplus/Shortage: quantity_onsite - quantity_required' AFTER `requirement_id`,
ADD COLUMN `available` INT NULL COMMENT 'Available for borrowing: quantity_onsite - total_borrowed' AFTER `difference`;

-- Add indexes for better performance on calculation queries
CREATE INDEX `idx_equipment_audits_difference` ON `equipment_audits` (`difference`);
CREATE INDEX `idx_equipment_audits_available` ON `equipment_audits` (`available`); 