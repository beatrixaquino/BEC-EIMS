-- Create audit table for scheduled audit dates
CREATE TABLE IF NOT EXISTS `audit_schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `audit_date` date NOT NULL,
  `audit_time` time NOT NULL,
  `description` text,
  `assigned_to` varchar(100) NOT NULL,
  `status` enum('pending','in_progress','completed','cancelled') DEFAULT 'pending',
  `created_by` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_audit_date` (`audit_date`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert sample audit data
INSERT INTO `audit_schedule` (`title`, `audit_date`, `audit_time`, `description`, `assigned_to`, `status`, `created_by`) VALUES
('Monthly Equipment Audit', '2025-01-15', '09:00:00', 'Monthly audit of all equipment in the inventory', 'admin1', 'pending', 'superadmin'),
('Quarterly Safety Inspection', '2025-01-20', '14:30:00', 'Quarterly safety inspection of borrowed equipment', 'admin2', 'pending', 'superadmin'),
('Annual Inventory Count', '2025-02-01', '08:00:00', 'Annual comprehensive inventory count and verification', 'admin3', 'pending', 'superadmin'); 