-- Add missing fields to borrowers table
ALTER TABLE borrowers 
ADD COLUMN created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN status VARCHAR(20) DEFAULT 'pending';

-- Update existing records to have a default status
UPDATE borrowers SET status = 'pending' WHERE status IS NULL; 