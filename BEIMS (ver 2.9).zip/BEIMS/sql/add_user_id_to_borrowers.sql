-- Add user_id column to borrowers table
ALTER TABLE borrowers ADD COLUMN user_id INT;

-- Add foreign key constraint to link user_id to users table
ALTER TABLE borrowers ADD CONSTRAINT fk_borrowers_user_id 
FOREIGN KEY (user_id) REFERENCES users(id);

-- Show the updated table structure
DESCRIBE borrowers; 