-- Fix date format issues in borrowers table
-- Run this script in phpMyAdmin to fix the date problems

-- Step 1: Check current table structure
DESCRIBE borrowers;

-- Step 2: Check current data to see the problem
SELECT id, firstname, lastname, borrow_date, return_date, status FROM borrowers LIMIT 10;

-- Step 3: Fix the date columns if they are not DATE type
-- First, let's see what type they currently are
SHOW COLUMNS FROM borrowers LIKE 'borrow_date';
SHOW COLUMNS FROM borrowers LIKE 'return_date';

-- Step 4: If the columns are VARCHAR or TEXT, convert them to DATE
-- This will fix the "00-00-0000" issue

-- Add new DATE columns
ALTER TABLE borrowers ADD COLUMN borrow_date_new DATE AFTER borrow_date;
ALTER TABLE borrowers ADD COLUMN return_date_new DATE AFTER return_date;

-- Convert existing data (this handles various date formats)
UPDATE borrowers 
SET borrow_date_new = CASE 
    WHEN borrow_date IS NULL OR borrow_date = '' OR borrow_date = '0000-00-00' THEN NULL
    WHEN borrow_date REGEXP '^[0-9]{4}-[0-9]{2}-[0-9]{2}$' THEN STR_TO_DATE(borrow_date, '%Y-%m-%d')
    WHEN borrow_date REGEXP '^[0-9]{2}/[0-9]{2}/[0-9]{4}$' THEN STR_TO_DATE(borrow_date, '%m/%d/%Y')
    WHEN borrow_date REGEXP '^[0-9]{2}-[0-9]{2}-[0-9]{4}$' THEN STR_TO_DATE(borrow_date, '%m-%d-%Y')
    ELSE NULL
END;

UPDATE borrowers 
SET return_date_new = CASE 
    WHEN return_date IS NULL OR return_date = '' OR return_date = '0000-00-00' THEN NULL
    WHEN return_date REGEXP '^[0-9]{4}-[0-9]{2}-[0-9]{2}$' THEN STR_TO_DATE(return_date, '%Y-%m-%d')
    WHEN return_date REGEXP '^[0-9]{2}/[0-9]{2}/[0-9]{4}$' THEN STR_TO_DATE(return_date, '%m/%d/%Y')
    WHEN return_date REGEXP '^[0-9]{2}-[0-9]{2}-[0-9]{4}$' THEN STR_TO_DATE(return_date, '%m-%d-%Y')
    ELSE NULL
END;

-- Drop old columns and rename new ones
ALTER TABLE borrowers DROP COLUMN borrow_date;
ALTER TABLE borrowers DROP COLUMN return_date;
ALTER TABLE borrowers CHANGE COLUMN borrow_date_new borrow_date DATE;
ALTER TABLE borrowers CHANGE COLUMN return_date_new return_date DATE;

-- Step 5: Ensure status column exists and has proper default
ALTER TABLE borrowers MODIFY COLUMN status VARCHAR(20) DEFAULT 'pending';

-- Step 6: Verify the fix
SELECT id, firstname, lastname, borrow_date, return_date, status FROM borrowers LIMIT 10;

-- Step 7: Show final table structure
DESCRIBE borrowers; 