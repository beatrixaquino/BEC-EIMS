<?php
// Include the database connection
include_once "dbconnect.php";

echo "<h2>Adding user_id column to borrowers table</h2>";

// Add user_id column
$sql1 = "ALTER TABLE borrowers ADD COLUMN user_id INT";
if ($conn->query($sql1)) {
    echo "<p>✅ Successfully added user_id column to borrowers table</p>";
} else {
    echo "<p>❌ Error adding user_id column: " . $conn->error . "</p>";
}

// Add foreign key constraint
$sql2 = "ALTER TABLE borrowers ADD CONSTRAINT fk_borrowers_user_id 
         FOREIGN KEY (user_id) REFERENCES users(id)";
if ($conn->query($sql2)) {
    echo "<p>✅ Successfully added foreign key constraint</p>";
} else {
    echo "<p>❌ Error adding foreign key constraint: " . $conn->error . "</p>";
}

// Show the updated table structure
echo "<h3>Updated borrowers table structure:</h3>";
$sql3 = "DESCRIBE borrowers";
$result = $conn->query($sql3);

if ($result) {
    echo "<table border='1'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['Field'] . "</td>";
        echo "<td>" . $row['Type'] . "</td>";
        echo "<td>" . $row['Null'] . "</td>";
        echo "<td>" . $row['Key'] . "</td>";
        echo "<td>" . $row['Default'] . "</td>";
        echo "<td>" . $row['Extra'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>Error showing table structure: " . $conn->error . "</p>";
}

echo "<h3>✅ Database update completed!</h3>";
echo "<p>Now when users submit borrower forms, their user_id will be automatically included.</p>";

$conn->close();
?> 