-- Add test data to equipment_requirements table
-- Based on the actual table structure provided

INSERT INTO `equipment_requirements` (`item_name`, `requirement_description`, `quantity_required`, `unit`) VALUES
('Menu Folder', 'Required quantity for dining services', 20, 'pcs'),
('Dining Room Chairs', 'Standard chairs for dining area', 50, 'pcs'),
('Service Station', 'Service stations for food service', 5, 'units'),
('Square Table Cloth', 'Table cloths for dining tables', 30, 'pcs'),
('Cotton Hand Towel', 'Hand towels for restrooms', 100, 'pcs'),
('Bread and Butter Plate', 'Plates for bread service', 80, 'pcs'),
('Salad Plates', 'Plates for salad service', 60, 'pcs'),
('Cup and Saucer', 'Cups and saucers for beverage service', 120, 'sets'),
('Dinner Knives', 'Knives for dinner service', 100, 'pcs'),
('Fish Knives', 'Specialized knives for fish dishes', 40, 'pcs'),
('Soup Spoon', 'Spoons for soup service', 80, 'pcs'),
('Teaspoon', 'Teaspoons for beverage service', 150, 'pcs'),
('Dessert Spoon and Fork', 'Utensils for dessert service', 60, 'sets'),
('Water Goblets', 'Glasses for water service', 100, 'pcs'),
('Highball Glass', 'Glasses for tall beverages', 80, 'pcs');

-- Verify the data was inserted
SELECT * FROM equipment_requirements; 