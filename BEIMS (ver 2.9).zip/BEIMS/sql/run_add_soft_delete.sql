<?php
// Include the database connection
include_once "dbconnect.php";

echo "<h2>🔧 Adding Soft Delete Functionality</h2>";

// Add deleted_at column
$sql1 = "ALTER TABLE borrowers ADD COLUMN deleted_at TIMESTAMP NULL DEFAULT NULL";
if ($conn->query($sql1)) {
    echo "<p style='color: green;'>✅ Successfully added deleted_at column to borrowers table</p>";
} else {
    echo "<p style='color: red;'>❌ Error adding deleted_at column: " . $conn->error . "</p>";
}

// Add index for better performance
$sql2 = "ALTER TABLE borrowers ADD INDEX idx_deleted_at (deleted_at)";
if ($conn->query($sql2)) {
    echo "<p style='color: green;'>✅ Successfully added index for deleted_at column</p>";
} else {
    echo "<p style='color: red;'>❌ Error adding index: " . $conn->error . "</p>";
}

// Show the updated table structure
echo "<h3>Updated borrowers table structure:</h3>";
$sql3 = "DESCRIBE borrowers";
$result = $conn->query($sql3);

if ($result) {
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['Field'] . "</td>";
        echo "<td>" . $row['Type'] . "</td>";
        echo "<td>" . $row['Null'] . "</td>";
        echo "<td>" . $row['Key'] . "</td>";
        echo "<td>" . $row['Default'] . "</td>";
        echo "<td>" . $row['Extra'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>Error showing table structure: " . $conn->error . "</p>";
}

echo "<h3>✅ Soft delete functionality added!</h3>";
echo "<p>Now you can use soft delete functions without losing data.</p>";

$conn->close();
?> 