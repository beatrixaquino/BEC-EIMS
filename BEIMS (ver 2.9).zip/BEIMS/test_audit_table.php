<?php
require_once 'dbconnect.php';

echo "<h2>🔍 Equipment Audits Table Check</h2>";

// Check if table exists
$tableCheck = $conn->query("SHOW TABLES LIKE 'equipment_audits'");
if ($tableCheck->num_rows > 0) {
    echo "✅ equipment_audits table exists<br>";
    
    // Check table structure
    $structure = $conn->query("DESCRIBE equipment_audits");
    echo "<h3>Table Structure:</h3>";
    echo "<table border='1' style='border-collapse: collapse;'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    
    while ($row = $structure->fetch_assoc()) {
        echo "<tr>";
        echo "<td>{$row['Field']}</td>";
        echo "<td>{$row['Type']}</td>";
        echo "<td>{$row['Null']}</td>";
        echo "<td>{$row['Key']}</td>";
        echo "<td>{$row['Default']}</td>";
        echo "<td>{$row['Extra']}</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // Check if there are any records
    $count = $conn->query("SELECT COUNT(*) as count FROM equipment_audits");
    $countResult = $count->fetch_assoc();
    echo "<br>📊 Total audit records: {$countResult['count']}<br>";
    
    // Check if required columns exist
    $hasDifference = $conn->query("SHOW COLUMNS FROM equipment_audits LIKE 'difference'")->num_rows > 0;
    $hasAvailable = $conn->query("SHOW COLUMNS FROM equipment_audits LIKE 'available'")->num_rows > 0;
    
    echo "<br><strong>Required Columns Check:</strong><br>";
    echo ($hasDifference ? "✅" : "❌") . " difference column<br>";
    echo ($hasAvailable ? "✅" : "❌") . " available column<br>";
    
    if ($hasDifference && $hasAvailable) {
        echo "<br><strong style='color: green;'>🎉 Table structure is complete and ready for audit functionality!</strong><br>";
    }
    
} else {
    echo "❌ equipment_audits table does not exist<br>";
    echo "<p>You need to run the SQL script: <code>sql/create_equipment_audits_table.sql</code></p>";
    echo "<p>Then run: <code>sql/add_audit_calculation_fields.sql</code></p>";
}

// Test API endpoint
echo "<h3>Test API Endpoint:</h3>";
$apiUrl = "equipment_audit_api_fixed.php?action=get&item_id=1";
echo "<a href='$apiUrl' target='_blank'>Test GET audits for item ID 1</a>";

// Test calculation API
echo "<br><br><h3>Test Calculation API:</h3>";
$calcUrl = "equipment_audit_api_fixed.php?action=calculate&item_id=1&semester=1st%20Semester";
echo "<a href='$calcUrl' target='_blank'>Test calculation for item ID 1, 1st Semester</a>";

// Test data check API
echo "<br><br><h3>Test Data Check API:</h3>";
$dataUrl = "equipment_audit_api_fixed.php?action=check_data";
echo "<a href='$dataUrl' target='_blank'>Check database data</a>";

echo "<br><br><h3>Next Steps:</h3>";
echo "<ol>";
echo "<li>✅ Table structure is complete</li>";
echo "<li>✅ API endpoints are working</li>";
echo "<li>🔄 <a href='equiplist.php'>Go to Equipment List</a> to test adding audit entries</li>";
echo "<li>🔄 <a href='test_audit_calculation.html'>Test Audit Calculation</a> to verify calculations</li>";
echo "</ol>";
?> 