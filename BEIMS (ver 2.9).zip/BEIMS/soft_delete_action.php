<?php
session_start();
header('Content-Type: application/json');

include_once "dbconnect.php";
include_once "soft_delete_helper.php";

// Check if user is logged in and has permission
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['acctype'], ['superadmin', 'admin'])) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized access']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    $borrower_id = intval($_POST['borrower_id'] ?? 0);
    $user_id = $_SESSION['user_id'];
    
    switch ($action) {
        case 'soft_delete':
            if ($borrower_id > 0) {
                if (softDeleteBorrower($borrower_id, $user_id)) {
                    echo json_encode(['success' => true, 'message' => 'Record soft deleted successfully']);
                } else {
                    echo json_encode(['success' => false, 'error' => 'Failed to delete record']);
                }
            } else {
                echo json_encode(['success' => false, 'error' => 'Invalid borrower ID']);
            }
            break;
            
        case 'restore':
            if ($borrower_id > 0) {
                if (restoreBorrower($borrower_id, $user_id)) {
                    echo json_encode(['success' => true, 'message' => 'Record restored successfully']);
                } else {
                    echo json_encode(['success' => false, 'error' => 'Failed to restore record']);
                }
            } else {
                echo json_encode(['success' => false, 'error' => 'Invalid borrower ID']);
            }
            break;
            
        default:
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
            break;
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
}
?> 