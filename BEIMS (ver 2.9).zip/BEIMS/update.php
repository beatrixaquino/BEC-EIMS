<?php
session_start(); // Make sure session_start() is at the top
include_once "dbconnect.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $username = $_POST['username'];
    $acctype = $_POST['acctype'];

    // Prepare the SQL statement to update without changing the password
    $sql = "UPDATE admin_accounts SET username = ?, acctype = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $username, $acctype, $id);

    // Execute and check for success or error
    if ($stmt->execute()) {
        $_SESSION['message'] = "Admin account updated successfully.";
    } else {
        $_SESSION['message'] = "Error updating account: " . $stmt->error;
    }

    // Redirect to admin management page
    header("Location: usermng.php");
    exit();
}
?>
