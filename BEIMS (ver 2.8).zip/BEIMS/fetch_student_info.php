<?php
// Start output buffering to prevent any HTML output
ob_start();

// Force JSON output and handle CORS (optional but recommended)
header('Content-Type: application/json');

// Disable error display in response (recommended for production)
ini_set('display_errors', 0);
error_reporting(0);

// Include the database connection
include_once "dbconnect.php";

// Check if the 'id' is passed via GET
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);  // Sanitize input

    $sql = "SELECT id, idnum, firstname, middleinitial, lastname, department, course, email, cpnnumber, consent, status, borrow_date, return_date 
            FROM borrowers WHERE id = ?";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        echo json_encode(["error" => "Query preparation failed: " . $conn->error]);
        exit;
    }

    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if a matching record was found
    if ($result && $result->num_rows > 0) {
        $data = $result->fetch_assoc();

        // Format dates properly for display
        if (!empty($data['borrow_date']) && $data['borrow_date'] !== '0000-00-00' && $data['borrow_date'] !== null) {
            $data['borrow_date'] = date('Y-m-d', strtotime($data['borrow_date']));
        } else {
            $data['borrow_date'] = '';
        }
        
        if (!empty($data['return_date']) && $data['return_date'] !== '0000-00-00' && $data['return_date'] !== null) {
            $data['return_date'] = date('Y-m-d', strtotime($data['return_date']));
        } else {
            $data['return_date'] = '';
        }

        // Clear any output and return the data as JSON
        ob_end_clean();
        echo json_encode($data);
    } else {
        ob_end_clean();
        echo json_encode(["error" => "No borrower found with that ID."]);
    }

    $stmt->close();
} else {
    ob_end_clean();
    echo json_encode(["error" => "No borrower ID provided."]);
}

$conn->close();
