<?php
// Start output buffering to prevent any HTML output
ob_start();

// Enable error reporting but don't display
ini_set('display_errors', 0);
error_reporting(E_ALL);

// Output JSON
header('Content-Type: application/json');

// Include database connection
include_once "dbconnect.php";

// Check if the borrower form ID is provided
if (isset($_GET['form_id'])) {
    $form_id = intval($_GET['form_id']);  // Sanitize input
    
    // Debug: Log the form_id
    error_log("fetch_borrowed_items.php: form_id = " . $form_id);

    // Query to fetch borrowed items for the given form
    // First, let's check what columns exist in item_list
    $check_columns_sql = "DESCRIBE item_list";
    $columns_result = $conn->query($check_columns_sql);
    $columns = [];
    while ($row = $columns_result->fetch_assoc()) {
        $columns[] = $row['Field'];
    }
    error_log("fetch_borrowed_items.php: Available columns in item_list: " . implode(', ', $columns));
    
    // Use a simple query first
    $sql = "SELECT 
                il.itemname as item_name, 
                ri.quantity, 
                ri.unit 
            FROM requested_items ri 
            JOIN item_list il ON ri.item_id = il.id 
            WHERE ri.borrower_id = ?";
    
    // Debug: Log the SQL query
    error_log("fetch_borrowed_items.php: SQL = " . $sql . " with borrower_id = " . $form_id);
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        ob_end_clean();
        echo json_encode(["error" => "Failed to prepare statement: " . $conn->error]);
        exit();
    }

    $stmt->bind_param("i", $form_id);
    
    if (!$stmt->execute()) {
        ob_end_clean();
        echo json_encode(["error" => "Failed to execute query: " . $stmt->error]);
        exit();
    }
    
    $result = $stmt->get_result();
    
    if (!$result) {
        ob_end_clean();
        echo json_encode(["error" => "Failed to get result: " . $stmt->error]);
        exit();
    }

    $items = [];
    while ($row = $result->fetch_assoc()) {
        $items[] = $row;
    }
    
    // Debug: Log the number of items found
    error_log("fetch_borrowed_items.php: Found " . count($items) . " items for borrower_id " . $form_id);

    // If no items found, try a simpler query to check if the borrower_id exists
    if (empty($items)) {
        error_log("fetch_borrowed_items.php: No items found, checking if borrower_id exists");
        $check_sql = "SELECT COUNT(*) as count FROM requested_items WHERE borrower_id = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("i", $form_id);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        $check_row = $check_result->fetch_assoc();
        error_log("fetch_borrowed_items.php: Found " . $check_row['count'] . " requested_items records for borrower_id " . $form_id);
        $check_stmt->close();
    }

    // Clear any output and return JSON
    ob_end_clean();
    echo json_encode($items);

    $stmt->close();
} else {
    ob_end_clean();
    echo json_encode(["error" => "No form ID provided."]);
}

$conn->close();
