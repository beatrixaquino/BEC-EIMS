-- Create equipment_audits table for dynamic audit logging
CREATE TABLE IF NOT EXISTS `equipment_audits` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `item_id` int(11) NOT NULL,
    `quantity_onsite` int(11) NOT NULL,
    `unit` varchar(20) NOT NULL DEFAULT 'pcs',
    `audit_date` date NOT NULL,
    `semester` varchar(50) NOT NULL,
    `requirement_id` int(11) NULL,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_item_id` (`item_id`),
    KEY `idx_audit_date` (`audit_date`),
    KEY `idx_semester` (`semester`),
    KEY `idx_requirement_id` (`requirement_id`),
    CONSTRAINT `fk_equipment_audits_item_id` FOREIGN KEY (`item_id`) REFERENCES `item_list` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_equipment_audits_requirement_id` FOREIGN KEY (`requirement_id`) REFERENCES `equipment_requirements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Add indexes for better performance
CREATE INDEX `idx_equipment_audits_item_date` ON `equipment_audits` (`item_id`, `audit_date`);
CREATE INDEX `idx_equipment_audits_semester` ON `equipment_audits` (`semester`); 