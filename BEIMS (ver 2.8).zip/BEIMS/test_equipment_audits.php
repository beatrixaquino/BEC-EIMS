<?php
// Test file for Equipment Audits System
require_once 'dbconnect.php';
require_once 'equipment_audit_functions.php';

echo "<h1>Equipment Audits System Test</h1>";

// Test 1: Check if table exists
echo "<h2>Test 1: Check if equipment_audits table exists</h2>";
$result = $conn->query("SHOW TABLES LIKE 'equipment_audits'");
if ($result->num_rows > 0) {
    echo "✅ equipment_audits table exists<br>";
} else {
    echo "❌ equipment_audits table does not exist<br>";
    echo "Please run the SQL script: sql/create_equipment_audits_table.sql<br>";
}

// Test 2: Check table structure
echo "<h2>Test 2: Check table structure</h2>";
$result = $conn->query("DESCRIBE equipment_audits");
if ($result) {
    echo "<table border='1' style='border-collapse: collapse;'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>{$row['Field']}</td>";
        echo "<td>{$row['Type']}</td>";
        echo "<td>{$row['Null']}</td>";
        echo "<td>{$row['Key']}</td>";
        echo "<td>{$row['Default']}</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "❌ Could not describe table<br>";
}

// Test 3: Test semester options function
echo "<h2>Test 3: Semester options</h2>";
$semesterOptions = getSemesterOptions();
echo "Available semesters:<br>";
foreach ($semesterOptions as $semester) {
    echo "- $semester<br>";
}

// Test 4: Check if there are any equipment items to test with
echo "<h2>Test 4: Check available equipment items</h2>";
$result = $conn->query("SELECT id, itemname FROM item_list LIMIT 5");
if ($result && $result->num_rows > 0) {
    echo "Available equipment items for testing:<br>";
    while ($row = $result->fetch_assoc()) {
        echo "- ID: {$row['id']}, Name: {$row['itemname']}<br>";
    }
} else {
    echo "❌ No equipment items found. Please add some items first.<br>";
}

// Test 5: Test API endpoints
echo "<h2>Test 5: API Endpoints</h2>";
echo "<a href='equipment_audit_api.php?action=get&item_id=1' target='_blank'>Test GET audits for item ID 1</a><br>";
echo "<a href='equipment_audit_api.php?action=save' target='_blank'>Test SAVE audits (POST required)</a><br>";
echo "<a href='equipment_audit_api.php?action=delete' target='_blank'>Test DELETE audit (POST required)</a><br>";

echo "<h2>Test 6: Manual API Test</h2>";
echo "<form method='post' action='equipment_audit_api.php?action=save'>";
echo "<input type='hidden' name='item_id' value='1'>";
echo "<input type='hidden' name='audits' value='[{\"semester\":\"1st Sem 2025-2026\",\"quantity_onsite\":5,\"unit\":\"pcs\",\"audit_date\":\"2025-07-20\"}]'>";
echo "<button type='submit'>Test Save Audit</button>";
echo "</form>";

echo "<h2>Instructions</h2>";
echo "<ol>";
echo "<li>First, run the SQL script: <code>sql/create_equipment_audits_table.sql</code></li>";
echo "<li>Add some equipment items in the main system</li>";
echo "<li>Test the dynamic audit system in equiplist.php</li>";
echo "<li>Check the audit history in the view modal</li>";
echo "</ol>";
?> 