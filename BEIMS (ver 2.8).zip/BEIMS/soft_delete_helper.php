<?php
// Soft delete helper functions
include_once "dbconnect.php";

/**
 * Soft delete a borrower record
 */
function softDeleteBorrower($borrower_id, $user_id = null) {
    global $conn;
    
    $sql = "UPDATE borrowers SET deleted_at = NOW() WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $borrower_id);
    
    $result = $stmt->execute();
    
    if ($result) {
        // Create notification for the user who deleted it
        if ($user_id) {
            include_once "notification_helper.php";
            createNotification(
                $user_id,
                "Record Deleted",
                "A borrower record has been soft deleted",
                "record_deleted",
                $borrower_id
            );
        }
    }
    
    return $result;
}

/**
 * Restore a soft deleted borrower record
 */
function restoreBorrower($borrower_id, $user_id = null) {
    global $conn;
    
    $sql = "UPDATE borrowers SET deleted_at = NULL WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $borrower_id);
    
    $result = $stmt->execute();
    
    if ($result && $user_id) {
        include_once "notification_helper.php";
        createNotification(
            $user_id,
            "Record Restored",
            "A borrower record has been restored",
            "record_restored",
            $borrower_id
        );
    }
    
    return $result;
}

/**
 * Hard delete a borrower record (use with caution)
 */
function hardDeleteBorrower($borrower_id) {
    global $conn;
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Delete related requested_items first
        $sql1 = "DELETE FROM requested_items WHERE borrower_id = ?";
        $stmt1 = $conn->prepare($sql1);
        $stmt1->bind_param("i", $borrower_id);
        $stmt1->execute();
        
        // Delete the borrower record
        $sql2 = "DELETE FROM borrowers WHERE id = ?";
        $stmt2 = $conn->prepare($sql2);
        $stmt2->bind_param("i", $borrower_id);
        $stmt2->execute();
        
        // Commit transaction
        $conn->commit();
        return true;
        
    } catch (Exception $e) {
        // Rollback on error
        $conn->rollback();
        return false;
    }
}

/**
 * Get all non-deleted borrowers (for normal display)
 */
function getActiveBorrowers($user_id = null, $status_filter = null) {
    global $conn;
    
    $sql = "SELECT * FROM borrowers WHERE deleted_at IS NULL";
    $params = [];
    $types = "";
    
    if ($user_id) {
        $sql .= " AND user_id = ?";
        $params[] = $user_id;
        $types .= "i";
    }
    
    if ($status_filter) {
        $sql .= " AND status = ?";
        $params[] = $status_filter;
        $types .= "s";
    }
    
    $sql .= " ORDER BY created_at DESC";
    
    $stmt = $conn->prepare($sql);
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    
    return $stmt->get_result();
}

/**
 * Get soft deleted borrowers (for admin recovery)
 */
function getDeletedBorrowers() {
    global $conn;
    
    $sql = "SELECT * FROM borrowers WHERE deleted_at IS NOT NULL ORDER BY deleted_at DESC";
    $result = $conn->query($sql);
    
    return $result;
}

/**
 * Check if a borrower record is soft deleted
 */
function isBorrowerDeleted($borrower_id) {
    global $conn;
    
    $sql = "SELECT deleted_at FROM borrowers WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $borrower_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['deleted_at'] !== null;
    }
    
    return false;
}

/**
 * Get borrower count (active only)
 */
function getActiveBorrowerCount($user_id = null, $status = null) {
    global $conn;
    
    $sql = "SELECT COUNT(*) as count FROM borrowers WHERE deleted_at IS NULL";
    $params = [];
    $types = "";
    
    if ($user_id) {
        $sql .= " AND user_id = ?";
        $params[] = $user_id;
        $types .= "i";
    }
    
    if ($status) {
        $sql .= " AND status = ?";
        $params[] = $status;
        $types .= "s";
    }
    
    $stmt = $conn->prepare($sql);
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    
    return $row['count'];
}
?> 