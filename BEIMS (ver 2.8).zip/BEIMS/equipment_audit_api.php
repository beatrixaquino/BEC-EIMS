<?php
// Equipment Audit API
header('Content-Type: application/json');
require_once 'equipment_audit_functions.php';

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'save':
        handleSaveAudits();
        break;
    case 'get':
        handleGetAudits();
        break;
    case 'delete':
        handleDeleteAudit();
        break;
    default:
        echo json_encode(['success' => false, 'error' => 'Invalid action']);
}

function handleSaveAudits() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['success' => false, 'error' => 'Method not allowed']);
        return;
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['item_id']) || !isset($input['audits'])) {
        echo json_encode(['success' => false, 'error' => 'Missing required fields']);
        return;
    }
    
    $itemId = intval($input['item_id']);
    $audits = $input['audits'];
    
    // Validate audit data
    foreach ($audits as $audit) {
        if (!isset($audit['quantity_onsite']) || !isset($audit['audit_date']) || !isset($audit['semester'])) {
            echo json_encode(['success' => false, 'error' => 'Invalid audit data']);
            return;
        }
    }
    
    $result = saveEquipmentAudits($itemId, $audits);
    echo json_encode($result);
}

function handleGetAudits() {
    if (!isset($_GET['item_id'])) {
        echo json_encode(['success' => false, 'error' => 'Missing item_id']);
        return;
    }
    
    $itemId = intval($_GET['item_id']);
    $result = getEquipmentAudits($itemId);
    echo json_encode($result);
}

function handleDeleteAudit() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['success' => false, 'error' => 'Method not allowed']);
        return;
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['audit_id'])) {
        echo json_encode(['success' => false, 'error' => 'Missing audit_id']);
        return;
    }
    
    $auditId = intval($input['audit_id']);
    $result = deleteEquipmentAudit($auditId);
    echo json_encode($result);
}
?> 