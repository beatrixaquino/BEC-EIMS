<?php
session_start();
include_once "dbconnect.php";

// Get dashboard statistics
$stats = [];

// Count active users
$user_sql = "SELECT COUNT(*) as count FROM users WHERE status = 'active'";
$user_result = $conn->query($user_sql);
$stats['active_users'] = $user_result->fetch_assoc()['count'];

// Count pending requests
$pending_sql = "SELECT COUNT(*) as count FROM borrowers WHERE status = 'pending' AND deleted_at IS NULL";
$pending_result = $conn->query($pending_sql);
$stats['pending_requests'] = $pending_result->fetch_assoc()['count'];

// Count approved forms
$approved_sql = "SELECT COUNT(*) as count FROM borrowers WHERE status = 'approved' AND deleted_at IS NULL";
$approved_result = $conn->query($approved_sql);
$stats['approved_forms'] = $approved_result->fetch_assoc()['count'];

// Count returned items
$returned_sql = "SELECT COUNT(*) as count FROM borrowers WHERE status = 'returned' AND deleted_at IS NULL";
$returned_result = $conn->query($returned_sql);
$stats['returned_items'] = $returned_result->fetch_assoc()['count'];

// Get recent borrower forms for the table
$recent_forms_sql = "SELECT * FROM borrowers WHERE deleted_at IS NULL ORDER BY created_at DESC LIMIT 5";
$recent_forms_result = $conn->query($recent_forms_sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->
	<link rel="stylesheet" href="istyle.css">

	<title>Superadmin Hub</title>
</head>
<body data-page="dashboard_superadmin">


	<!-- SIDEBAR -->
	<section id="sidebar">
		<a href="#" class="brand">
			<i class='bx bxs-package' ></i>
			<span class="text">BEC EIMS</span>
		</a>
		<ul class="side-menu top">
			<li class="active">
				<a href="dashboard_superadmin.php">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Dashboard</span>
				</a>
			</li>
			<li>
				<a href="usermng.php">
					<i class='bx bx-group' ></i>
					<span class="text">User Management</span>
				</a>
			</li>
			<li class="dropdown" id="borrowersDropdown">
				<a href="borrowform.php" class="dropdown-toggle">
					<i class='bx bx-clipboard'></i>
					<span class="text">Borrowers Forms</span>
					<i class='bx bx-chevron-down dropdown-arrow'></i>
				</a>
				<ul class="dropdown-menu" id="borrowersDropdownMenu">
					<li><a href="borrowform.php"><i class='bx bxs-report'></i> All Forms</a></li>
					<li><a href="manage_deleted_records.php"><i class='bx bxs-trash'></i> Deleted Records</a></li>
					<li><a href="borrowform.php?filter=pending"><i class='bx bxs-time'></i> Pending Forms</a></li>
					<li><a href="borrowform.php?filter=approved"><i class='bx bxs-check-circle'></i> Approved Forms</a></li>
					<li><a href="borrowform.php?filter=rejected"><i class='bx bxs-x-circle'></i> Rejected Forms</a></li>
					<li><a href="borrowform.php?filter=returned"><i class='bx bxs-archive'></i> Returned Forms</a></li>
				</ul>
			</li>
			<li>
				<a href="equiplist.php">
                <i class='bx bxs-wrench' ></i>
					<span class="text">Equipment List</span>
				</a>
			</li>
		</ul>
		<ul class="side-menu">
			<li>
				<a href="login.php" class="logout">
					<i class='bx bxs-log-out' ></i>
					<span class="text">Logout</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->



	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu' ></i>
			<a href="#" class="nav-link">Categories</a>
			<form action="#">
				<div class="form-input">
					<input type="search" placeholder="Search...">
					<button type="submit" class="search-btn"><i class='bx bx-search' ></i></button>
				</div>
			</form>
			<input type="checkbox" id="switch-mode" hidden>
			<label for="switch-mode" class="switch-mode"></label>
			<a href="#" class="notification" id="notificationIcon">
				<i class='bx bxs-bell' ></i>
				<span class="num" id="notificationCount">0</span>
			</a>
			<div class="notification-dropdown" id="notificationDropdown" style="display: none;">
				<div class="notification-header">
					<h4>Notifications</h4>
					<button id="markAllRead" class="mark-all-read">Mark all read</button>
				</div>
				<div class="notification-list" id="notificationList">
					<!-- Notifications will be loaded here -->
				</div>
			</div>
			<a href="#" class="profile">
				<img src="img/people.png">
			</a>
		</nav>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
			<div class="head-title">
				<div class="left">
					<h1>Dashboard</h1>
					<ul class="breadcrumb">
						<li>
							<a href="#">Dashboard</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="#">Home</a>
						</li>
					</ul>
				</div>
				<a href="#" class="btn-download">
					<i class='bx bxs-report'></i>
					<span class="text">Generate Report</span>
				</a>
			</div>

			<ul class="box-info">
				<a href="usermng.php" class="box-link">
				<li>
					<i class='bx bxs-user-pin'></i>
					<span class="text">
						<h3><?php echo $stats['active_users']; ?></h3>
						<p>Active Users</p>
					</span>
				</li>
				</a>
				<a href="borrowform.php?filter=pending" class="box-link">
				<li>
					<i class='bx bxs-hourglass' ></i>
					<span class="text">
						<h3><?php echo $stats['pending_requests']; ?></h3>
						<p>Pending Requests</p>
					</span>
				</li>
				</a>
				<a href="borrowform.php?filter=approved" class="box-link">
				<li>
					<i class='bx bx-check'></i>
					<span class="text">
						<h3><?php echo $stats['approved_forms']; ?></h3>
						<p>Approved Forms</p>
					</span>
				</li>
				</a>
				<a href="borrowform.php?filter=returned" class="box-link">
				<li>
					<i class='bx bx-archive-in' ></i>
					<span class="text">
						<h3><?php echo $stats['returned_items']; ?></h3>
						<p>Returned Items</p>
					</span>
				</li>
				</a>
			</ul>


			<div class="table-data">
				<div class="order">
					<div class="head">
						<h3>Submitted Borrowers Forms</h3>
						<i class='bx bx-filter' id="sortFormsBtn" title="Toggle Sort Order"></i>
					</div>
					<table>
						<thead>
							<tr>
								<th>Name</th>
								<th>Department</th>
								<th>Date Submitted</th>
								<th>Status</th>
							</tr>
						</thead>
						<tbody>
							<?php if ($recent_forms_result && $recent_forms_result->num_rows > 0): ?>
								<?php while ($row = $recent_forms_result->fetch_assoc()): ?>
									<tr>
										<td>
											<img src="img/people.png">
											<p><?php echo htmlspecialchars($row['firstname'] . ' ' . $row['lastname']); ?></p>
										</td>
										<td><?php echo htmlspecialchars($row['department']); ?></td>
										<td><?php echo htmlspecialchars(date("M j, Y", strtotime($row['created_at']))); ?></td>
										<td>
											<?php 
											$status_class = '';
											switch($row['status']) {
												case 'pending':
													$status_class = 'pending';
													break;
												case 'approved':
													$status_class = 'approved';
													break;
												case 'rejected':
													$status_class = 'rejected';
													break;
												case 'returned':
													$status_class = 'returned';
													break;
												default:
													$status_class = 'pending';
											}
											?>
											<span class="status <?php echo $status_class; ?>"><?php echo ucfirst($row['status']); ?></span>
										</td>
									</tr>
								<?php endwhile; ?>
							<?php else: ?>
								<tr>
									<td colspan="4" style="text-align: center;">No recent forms submitted</td>
								</tr>
							<?php endif; ?>
						</tbody>
					</table>
				</div>
				<div class="todo">
					<div class="head">
						<h3>Calendar</h3>
						<button id="add-audit-btn" style="background: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer; padding: 8px 12px; font-size: 16px; margin-left: 10px;">
							<i class='bx bx-plus'></i> Add Audit
						</button>
					</div>
						<div class="calendar-controls">
            				<button id="prev-month">&lt; Previous</button>
            				<h2 id="current-month-year">Month Year</h2>
            				<button id="next-month">Next &gt;</button>
        				</div>
        				
        				<div class="calendar-legends">
            				<div class="legend-item">
                				<span class="legend-color green"></span>
                				<span class="legend-text">Pickup Date</span>
            				</div>
            				<div class="legend-item">
                				<span class="legend-color blue"></span>
                				<span class="legend-text">Return Date</span>
            				</div>
            				<div class="legend-item">
                				<span class="legend-color purple"></span>
                				<span class="legend-text">Audit Date</span>
            				</div>
        				</div>

						<div class="calendar-grid" id="calendar-header">
            			<div class="calendar-header">Sun</div>
            			<div class="calendar-header">Mon</div>
            			<div class="calendar-header">Tue</div>
            			<div class="calendar-header">Wed</div>
            			<div class="calendar-header">Thu</div>
            			<div class="calendar-header">Fri</div>
            			<div class="calendar-header">Sat</div>
        			</div>

					<div class="calendar-grid" id="calendar-days"></div>

					<div class="modal" id="event-modal">
        				<div class="modal-content">
            				<div class="modal-header">
                				<h3 id="modal-event-title">Event Title</h3>
                				<button class="close-btn" id="close-modal">&times;</button>
            				</div>
            				<div class="event-meta">
                				<span class="event-type" id="modal-event-type">General</span>
                				<span class="event-time" id="modal-event-time">All day</span>
                				<span class="event-venue" id="modal-event-venue">Online</span>
            				</div>
            				<div class="event-details">
                				<p id="modal-event-description">Event description goes here.</p>
            				</div>
            				<div class="event-actions">
                				<button class="edit-btn">Edit</button>
                				<button class="delete-btn">Delete</button>
            				</div>
        				</div>
					</div>

					<!-- Add Audit Date Modal -->
					<div id="add-audit-modal" class="audit-modal" style="display: none; position: fixed; z-index: 999999; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.5); justify-content: center; align-items: center;">
						<div style="background: white; padding: 0; border-radius: 8px; width: 90%; max-width: 500px; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);">
							<div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px 8px 0 0; display: flex; justify-content: space-between; align-items: center;">
								<h3 style="margin: 0; font-size: 18px; font-weight: 600;">Schedule Audit Date</h3>
								<button onclick="closeAuditModal()" style="background: none; border: none; color: white; font-size: 24px; cursor: pointer; padding: 0; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; border-radius: 50%;">&times;</button>
							</div>
							<div style="padding: 25px;">
								<form id="audit-form">
									<div style="margin-bottom: 20px;">
										<label for="audit-title" style="display: block; margin-bottom: 8px; font-weight: 600; color: #333; font-size: 14px;">Audit Title:</label>
										<input type="text" id="audit-title" name="title" required placeholder="e.g., Monthly Equipment Audit" style="width: 100%; padding: 12px; border: 2px solid #e1e5e9; border-radius: 6px; font-size: 14px; box-sizing: border-box;">
									</div>
									<div style="margin-bottom: 20px;">
										<label for="audit-date" style="display: block; margin-bottom: 8px; font-weight: 600; color: #333; font-size: 14px;">Audit Date:</label>
										<input type="date" id="audit-date" name="date" required style="width: 100%; padding: 12px; border: 2px solid #e1e5e9; border-radius: 6px; font-size: 14px; box-sizing: border-box;">
									</div>
									<div style="margin-bottom: 20px;">
										<label for="audit-time" style="display: block; margin-bottom: 8px; font-weight: 600; color: #333; font-size: 14px;">Audit Time:</label>
										<input type="time" id="audit-time" name="time" required style="width: 100%; padding: 12px; border: 2px solid #e1e5e9; border-radius: 6px; font-size: 14px; box-sizing: border-box;">
									</div>
									<div style="margin-bottom: 20px;">
										<label for="audit-description" style="display: block; margin-bottom: 8px; font-weight: 600; color: #333; font-size: 14px;">Description:</label>
										<textarea id="audit-description" name="description" rows="3" placeholder="Brief description of the audit..." style="width: 100%; padding: 12px; border: 2px solid #e1e5e9; border-radius: 6px; font-size: 14px; box-sizing: border-box; resize: vertical; min-height: 80px;"></textarea>
									</div>
									<div style="margin-bottom: 20px;">
										<label for="audit-assigned-to" style="display: block; margin-bottom: 8px; font-weight: 600; color: #333; font-size: 14px;">Assigned To:</label>
										<select id="audit-assigned-to" name="assigned_to" required style="width: 100%; padding: 12px; border: 2px solid #e1e5e9; border-radius: 6px; font-size: 14px; box-sizing: border-box;">
											<option value="">Select Admin</option>
											<option value="admin1">Admin 1</option>
											<option value="admin2">Admin 2</option>
											<option value="admin3">Admin 3</option>
										</select>
									</div>
									<div style="display: flex; gap: 12px; justify-content: flex-end; margin-top: 25px; padding-top: 20px; border-top: 1px solid #e1e5e9;">
										<button type="button" onclick="closeAuditModal()" style="padding: 12px 24px; border: none; border-radius: 6px; font-size: 14px; font-weight: 600; cursor: pointer; background-color: #f8f9fa; color: #6c757d; border: 2px solid #e1e5e9;">Cancel</button>
										<button type="submit" style="padding: 12px 24px; border: none; border-radius: 6px; font-size: 14px; font-weight: 600; cursor: pointer; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">Schedule Audit</button>
									</div>
								</form>
							</div>
						</div>
					</div>

    			</div>
			</div>
		</main>
		<!-- MAIN -->
	</section>
	<!-- CONTENT -->
	

	<script src="script.js"></script>
	<script src="notification.js"></script>
	
	<script>
	// Close audit modal function
	function closeAuditModal() {
		const modal = document.getElementById('add-audit-modal');
		if (modal) {
			modal.style.display = 'none';
		}
		// Reset form
		const form = document.getElementById('audit-form');
		if (form) {
			form.reset();
		}
	}
	</script>
	
	<script>
	// Form sorting functionality
	document.addEventListener('DOMContentLoaded', function() {
		const sortFormsBtn = document.getElementById('sortFormsBtn');
		const formsTable = document.querySelector('.order table tbody');
		let isAscending = false; // Start with descending (most recent first)
		
		if (sortFormsBtn && formsTable) {
			sortFormsBtn.addEventListener('click', function() {
				const rows = Array.from(formsTable.querySelectorAll('tr'));
				
				// Skip if no data rows (only header row)
				if (rows.length <= 1) return;
				
				// Sort the rows based on date
				rows.sort(function(a, b) {
					const dateA = new Date(a.querySelector('td:nth-child(3)').textContent);
					const dateB = new Date(b.querySelector('td:nth-child(3)').textContent);
					
					if (isAscending) {
						return dateA - dateB; // Oldest first
					} else {
						return dateB - dateA; // Newest first
					}
				});
				
				// Clear the table and add sorted rows
				formsTable.innerHTML = '';
				rows.forEach(row => formsTable.appendChild(row));
				
				// Toggle sort order for next click
				isAscending = !isAscending;
				
				// Update button appearance
				if (isAscending) {
					sortFormsBtn.style.transform = 'rotate(180deg)';
					sortFormsBtn.title = 'Sort: Oldest First';
				} else {
					sortFormsBtn.style.transform = 'rotate(0deg)';
					sortFormsBtn.title = 'Sort: Newest First';
				}
			});
		}
	});
	</script>
</body>
</html>