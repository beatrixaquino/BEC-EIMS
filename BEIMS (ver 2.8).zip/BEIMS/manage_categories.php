<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Output as JSON
header('Content-Type: application/json');

// Include the database connection
include_once "dbconnect.php";

// Handle different operations
$action = $_GET['action'] ?? '';

switch($action) {
    case 'fetch':
        // Fetch all categories
        $sql = "SELECT id, name, created_at FROM categories ORDER BY name ASC";
        $result = $conn->query($sql);
        
        $categories = [];
        while ($row = $result->fetch_assoc()) {
            $categories[] = [
                'id' => $row['id'],
                'name' => ucfirst($row['name']),
                'created_at' => $row['created_at']
            ];
        }
        
        echo json_encode(['success' => true, 'categories' => $categories]);
        break;
        
    case 'edit':
        // Edit a category
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = intval($_POST['id']);
            $name = trim($_POST['name']);
            
            if (empty($name)) {
                echo json_encode(['success' => false, 'error' => 'Category name cannot be empty']);
                exit();
            }
            
            // Check if name already exists (excluding current category)
            $check_sql = "SELECT COUNT(*) as count FROM categories WHERE name = ? AND id != ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bind_param("si", $name, $id);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            $count = $check_result->fetch_assoc()['count'];
            
            if ($count > 0) {
                echo json_encode(['success' => false, 'error' => 'Category name already exists']);
                exit();
            }
            
            // Update the category
            $sql = "UPDATE categories SET name = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("si", $name, $id);
            
            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'message' => 'Category updated successfully']);
            } else {
                echo json_encode(['success' => false, 'error' => 'Failed to update category']);
            }
            
            $stmt->close();
        } else {
            echo json_encode(['success' => false, 'error' => 'Invalid request method']);
        }
        break;
        
    case 'delete':
        // Delete a category
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = intval($_POST['id']);
            
            // Check if category is being used by any items
            $check_sql = "SELECT COUNT(*) as count FROM item_categories WHERE category_id = ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bind_param("i", $id);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            $count = $check_result->fetch_assoc()['count'];
            
            if ($count > 0) {
                echo json_encode(['success' => false, 'error' => 'Cannot delete category: It is being used by ' . $count . ' item(s)']);
                exit();
            }
            
            // Delete the category
            $sql = "DELETE FROM categories WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $id);
            
            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'message' => 'Category deleted successfully']);
            } else {
                echo json_encode(['success' => false, 'error' => 'Failed to delete category']);
            }
            
            $stmt->close();
        } else {
            echo json_encode(['success' => false, 'error' => 'Invalid request method']);
        }
        break;
        
    default:
        echo json_encode(['success' => false, 'error' => 'Invalid action']);
        break;
}

$conn->close();
?> 