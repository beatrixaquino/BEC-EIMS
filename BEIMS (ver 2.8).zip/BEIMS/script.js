console.log("JS file loaded!");
document.addEventListener('DOMContentLoaded', function () {
    // Existing script: Sidebar functionality
    const allSideMenu = document.querySelectorAll('#sidebar .side-menu.top li a');

    // Get the current page from the body 'data-page' attribute
    let currentPage = document.body.getAttribute('data-page');

    // Set up sidebar active class
    allSideMenu.forEach(item => {
        const li = item.parentElement;
        const pageName = item.getAttribute("href").split("/").pop().split(".")[0];
        
        // Handle index.html as dashboard
        if (pageName === 'index' && currentPage === 'index') {
            li.classList.add('active');
        } else if (pageName !== 'index' && pageName === currentPage) {
            li.classList.add('active');
        } else {
            li.classList.remove('active');
        }

        // Add click event to update the active class
        item.addEventListener('click', function () {
            allSideMenu.forEach(i => {
                i.parentElement.classList.remove('active');
            });
            li.classList.add('active');
        });
    });

    // Toggle sidebar functionality
    const menuBar = document.querySelector('#content nav .bx.bx-menu');
    const sidebar = document.getElementById('sidebar');

    if (menuBar) {
        menuBar.addEventListener('click', function () {
            sidebar.classList.toggle('hide');
        });
    } else {
        console.error('Sidebar toggle element (bx bx-menu) not found.');
    }

    // Search functionality
    const searchButton = document.querySelector('#content nav form .form-input button');
    const searchButtonIcon = document.querySelector('#content nav form .form-input button .bx');
    const searchForm = document.querySelector('#content nav form');

    searchButton.addEventListener('click', function (e) {
        if (window.innerWidth < 576) {
            e.preventDefault();
            searchForm.classList.toggle('show');
            if (searchForm.classList.contains('show')) {
                searchButtonIcon.classList.replace('bx-search', 'bx-x');
            } else {
                searchButtonIcon.classList.replace('bx-x', 'bx-search');
            }
        }
    });

    // Responsive behavior on load
    if (window.innerWidth < 768) {
        sidebar.classList.add('hide');
    } else if (window.innerWidth > 576) {
        searchButtonIcon.classList.replace('bx-x', 'bx-search');
        searchForm.classList.remove('show');
    }

    window.addEventListener('resize', function () {
        if (this.innerWidth > 576) {
            searchButtonIcon.classList.replace('bx-x', 'bx-search');
            searchForm.classList.remove('show');
        }
    });

    // Dark mode toggle
    const switchMode = document.getElementById('switch-mode');
    if (switchMode) {
        switchMode.addEventListener('change', function () {
            if (this.checked) {
                document.body.classList.add('dark');
            } else {
                document.body.classList.remove('dark');
            }
        });
    }

    // Log the page loaded and check current page
    console.log("Page loaded. Current page:", currentPage);

    // Define the editAdmin function
    window.editAdmin = function(button) {
        console.log("Edit button clicked.");  // Log to confirm button click

        // Get data attributes from the clicked button
        const id = button.getAttribute('data-id');
        const username = button.getAttribute('data-username');
        const password = button.getAttribute('data-password');
        const acctype = button.getAttribute('data-acctype');

        // Debugging: Log the values to check if they are being captured correctly
        console.log("Admin ID:", id);
        console.log("Username:", username);
        console.log("Password:", password);
        console.log("Account Type:", acctype);

        // Populate the form fields with the clicked admin's details
        document.getElementById('username').value = username;
        document.getElementById('password').value = password; 
        document.getElementById('acctype').value = acctype;

        // Add hidden input field to store the ID of the admin being edited
        let hiddenIdField = document.getElementById('admin-id');
        if (!hiddenIdField) {
            hiddenIdField = document.createElement('input');
            hiddenIdField.type = 'hidden';
            hiddenIdField.id = 'admin-id';
            hiddenIdField.name = 'id';
            document.querySelector('form').appendChild(hiddenIdField);
        }
        hiddenIdField.value = id;

        // Confirm hidden ID field value for debugging
        console.log("Hidden ID Field Value:", hiddenIdField.value);
    };

    // Check if the current page is 'usermng' before setting up editAdmin
    if (currentPage === 'usermng') {
        console.log("Setting up editAdmin for admin management page.");

        // Attach event listeners to each edit button
        document.querySelectorAll('.btn-edit').forEach(button => {
            button.addEventListener('click', function () {
                console.log("Edit button was clicked on item with ID:", button.getAttribute('data-id'));
                editAdmin(button); // Call the editAdmin function
            });
        });
    } else {
        console.log("Current page is not 'usermng', editAdmin not set up.");
    }

   // --- CALENDAR SETUP WITH NAVIGATION ---

// Global month names so it's accessible by multiple functions
const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
];

// Track current displayed month and year
let currentMonth = new Date().getMonth();
let currentYear = new Date().getFullYear();

// Global variable to store calendar events
let calendarEvents = [];
// Global variables for multi-event navigation
let currentDayEvents = [];
let currentEventIndex = 0;

// Function to load calendar events from the server
async function loadCalendarEvents() {
    try {
        const response = await fetch('fetch_calendar_events.php');
        const data = await response.json();
        
        if (data.success) {
            calendarEvents = data.events;
            console.log('Loaded calendar events:', calendarEvents);
        } else {
            console.error('Failed to load calendar events:', data.error);
        }
    } catch (error) {
        console.error('Error loading calendar events:', error);
    }
}

// Function to render the calendar grid with events
function renderCalendar(month, year) {
    const header = document.getElementById('current-month-year');
    const calendarDays = document.getElementById('calendar-days');

    if (!header || !calendarDays) {
        console.error("Missing #current-month-year or #calendar-days");
        return;
    }

    header.textContent = `${monthNames[month]} ${year}`;
    calendarDays.innerHTML = '';

    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    // Empty slots before the first day
    for (let i = 0; i < firstDay; i++) {
        const empty = document.createElement('div');
        empty.classList.add('calendar-day', 'empty');
        calendarDays.appendChild(empty);
    }

    // Real days of the month
    for (let d = 1; d <= daysInMonth; d++) {
        const day = document.createElement('div');
        day.classList.add('calendar-day');
        day.textContent = d;
        
        // Check for events on this day
        const currentDate = new Date(year, month, d);
        const dateString = currentDate.toISOString().split('T')[0]; // YYYY-MM-DD format
        
        const dayEvents = calendarEvents.filter(event => event.date === dateString);
        
        if (dayEvents.length > 0) {
            console.log(`Day ${d} has ${dayEvents.length} events:`, dayEvents);
            day.classList.add('has-events');
            
            // Create event indicators
            dayEvents.forEach(event => {
                const eventIndicator = document.createElement('div');
                eventIndicator.classList.add('event-indicator', `event-${event.type}`);
                eventIndicator.setAttribute('data-event-id', event.id);
                eventIndicator.setAttribute('data-event-type', event.type);
                eventIndicator.setAttribute('data-borrower-name', event.borrower_name);
                eventIndicator.setAttribute('data-description', event.description);
                eventIndicator.title = event.title;
                day.appendChild(eventIndicator);
                console.log(`Created event indicator for ${event.type} event:`, event);
            });
        }
        
        calendarDays.appendChild(day);
    }

    console.log(`Rendered ${daysInMonth} days for ${monthNames[month]} ${year} with ${calendarEvents.length} events`);
}

// Button functionality
const prevButton = document.getElementById('prev-month');
const nextButton = document.getElementById('next-month');

if (prevButton && nextButton) {
    prevButton.addEventListener('click', async () => {
        currentMonth--;
        if (currentMonth < 0) {
            currentMonth = 11;
            currentYear--;
        }
        await loadCalendarEvents();
        renderCalendar(currentMonth, currentYear);
    });

    nextButton.addEventListener('click', async () => {
        currentMonth++;
        if (currentMonth > 11) {
            currentMonth = 0;
            currentYear++;
        }
        await loadCalendarEvents();
        renderCalendar(currentMonth, currentYear);
    });
} else {
    console.warn("Prev/Next buttons not found.");
}

// Load events and render calendar
async function initializeCalendar() {
    await loadCalendarEvents();
    renderCalendar(currentMonth, currentYear);
    
    // Add click handlers for event indicators and calendar days
    document.addEventListener('click', function(e) {
        console.log('Click detected on:', e.target);
        console.log('Element classes:', e.target.classList);
        
        // Check if clicking on event indicator
        if (e.target.classList.contains('event-indicator')) {
            console.log('Event indicator clicked!');
            const eventType = e.target.getAttribute('data-event-type');
            const borrowerName = e.target.getAttribute('data-borrower-name');
            const description = e.target.getAttribute('data-description');
            const eventId = e.target.getAttribute('data-event-id');
            const borrowerId = eventId.split('_')[0];
            
            console.log('Event details:', { eventType, borrowerName, description, eventId, borrowerId });
            
            // Get all events for this day
            const dayElement = e.target.closest('.calendar-day');
            const dayEvents = getDayEvents(dayElement);
            
            // Show detailed modal with navigation
            showEventDetailsWithNavigation(dayEvents, 0);
        }
        // Check if clicking on calendar day with events
        else if (e.target.classList.contains('calendar-day') && e.target.classList.contains('has-events')) {
            console.log('Calendar day with events clicked!');
            
            // Get all events for this day
            const dayEvents = getDayEvents(e.target);
            
            // Show detailed modal with navigation
            showEventDetailsWithNavigation(dayEvents, 0);
        }
    });
}

// Helper function to get all events for a specific day
function getDayEvents(dayElement) {
    const eventIndicators = dayElement.querySelectorAll('.event-indicator');
    const events = [];
    
    eventIndicators.forEach(indicator => {
        events.push({
            eventType: indicator.getAttribute('data-event-type'),
            borrowerName: indicator.getAttribute('data-borrower-name'),
            description: indicator.getAttribute('data-description'),
            eventId: indicator.getAttribute('data-event-id'),
            borrowerId: indicator.getAttribute('data-event-id').split('_')[0]
        });
    });
    
    return events;
}

// Function to show detailed event information with navigation
async function showEventDetailsWithNavigation(dayEvents, startIndex = 0) {
    if (dayEvents.length === 0) return;
    
    // Store current events and index globally
    currentDayEvents = dayEvents;
    currentEventIndex = startIndex;
    
    // Show the first event
    await showEventDetailsWithNav(currentEventIndex);
}

// Function to show detailed event information with navigation controls
async function showEventDetailsWithNav(eventIndex) {
    if (eventIndex < 0 || eventIndex >= currentDayEvents.length) return;
    
    const event = currentDayEvents[eventIndex];
    currentEventIndex = eventIndex;
    
    console.log('showEventDetailsWithNav called with:', event);
    
    try {
        console.log('Fetching borrower details for ID:', event.borrowerId);
        // Fetch detailed borrower information
        const response = await fetch(`fetch_student_info.php?id=${event.borrowerId}`);
        const borrowerData = await response.json();
        
        console.log('Borrower data received:', borrowerData);
        
        if (borrowerData.error) {
            console.error('Error fetching borrower details:', borrowerData.error);
            return;
        }
        
        // Create modal content with navigation
        const modal = document.createElement('div');
        modal.className = 'event-details-modal';
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background-color: rgba(0,0,0,0.4);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 2000;
        `;
        
        // Navigation buttons
        const prevButton = eventIndex > 0 ? 
            `<button class="nav-btn prev-btn" style="position:absolute; left:20px; top:50%; transform:translateY(-50%); background:#007bff; color:white; border:none; width:50px; height:50px; border-radius:50%; cursor:pointer; font-size:24px; display:flex; align-items:center; justify-content:center; box-shadow:0 4px 12px rgba(0,123,255,0.3);">‹</button>` : '';
        const nextButton = eventIndex < currentDayEvents.length - 1 ? 
            `<button class="nav-btn next-btn" style="position:absolute; right:20px; top:50%; transform:translateY(-50%); background:#007bff; color:white; border:none; width:50px; height:50px; border-radius:50%; cursor:pointer; font-size:24px; display:flex; align-items:center; justify-content:center; box-shadow:0 4px 12px rgba(0,123,255,0.3);">›</button>` : '';
        
        // Event counter
        const eventCounter = currentDayEvents.length > 1 ? 
            `<div style="position:absolute; top:15px; left:20px; background:rgba(0,0,0,0.7); color:white; padding:5px 10px; border-radius:15px; font-size:12px;">Event ${eventIndex + 1} of ${currentDayEvents.length}</div>` : '';
        
        modal.innerHTML = `
            <div class="modal-content" style="background:#fff; padding:25px; border-radius:12px; max-width:600px; width:90%; margin:auto; position:relative;">
                ${eventCounter}
                <span class="close-event-modal" style="position:absolute; top:15px; right:20px; cursor:pointer; font-size:24px; color:#666;">&times;</span>
                ${prevButton}
                ${nextButton}
                <div id="eventDetailsContent">
                    <!-- Content will be loaded here -->
                </div>
            </div>
        `;
        
        // Add modal to page
        console.log('Adding modal to page');
        document.body.appendChild(modal);
        console.log('Modal added successfully');
        
        // Show loading state
        const content = document.getElementById('eventDetailsContent');
        content.innerHTML = '<div style="text-align: center; padding: 20px;"><i class="bx bx-loader-alt bx-spin" style="font-size: 2rem;"></i><p>Loading borrower details...</p></div>';
        
        // Fetch borrowed items
        const itemsResponse = await fetch(`fetch_borrowed_items.php?form_id=${event.borrowerId}`);
        const items = await itemsResponse.json();
        
        let itemsHtml = '';
        if (items && items.length > 0) {
            items.forEach(item => {
                itemsHtml += `
                    <div style="background: #f8f9fa; padding: 10px; border-radius: 6px; margin: 5px 0;">
                        <strong>${item.item_name}</strong> - ${item.quantity} ${item.unit}
                    </div>
                `;
            });
        } else {
            itemsHtml = '<div style="color: #666; font-style: italic;">No borrowed items found</div>';
        }
        
        // Update content with the better layout
        content.innerHTML = `
            <div style="margin-bottom: 20px;">
                <h2 style="margin: 0 0 15px 0; color: #333;">Borrower Details</h2>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div>
                        <strong>Name:</strong><br>
                        <span>${borrowerData.firstname} ${borrowerData.middleinitial || ''} ${borrowerData.lastname}</span>
                    </div>
                    <div>
                        <strong>ID Number:</strong><br>
                        <span>${borrowerData.idnum}</span>
                    </div>
                    <div>
                        <strong>Department:</strong><br>
                        <span>${borrowerData.department}</span>
                    </div>
                    <div>
                        <strong>Course:</strong><br>
                        <span>${borrowerData.course}</span>
                    </div>
                    <div>
                        <strong>Email:</strong><br>
                        <span>${borrowerData.email}</span>
                    </div>
                    <div>
                        <strong>Contact:</strong><br>
                        <span>${borrowerData.cpnnumber}</span>
                    </div>
                </div>
            </div>
            
            <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                <h3 style="margin: 0 0 10px 0; color: #495057;">Borrowing Information</h3>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                    <div>
                        <strong>Borrow Date:</strong><br>
                        <span>${formatDate(borrowerData.borrow_date)}</span>
                    </div>
                    <div>
                        <strong>Return Date:</strong><br>
                        <span>${formatDate(borrowerData.return_date)}</span>
                    </div>
                    <div>
                        <strong>Status:</strong><br>
                        <span style="padding: 4px 8px; border-radius: 4px; background: ${getStatusColor(borrowerData.status)}; color: white; font-size: 0.8rem;">${borrowerData.status}</span>
                    </div>
                    <div>
                        <strong>Consent:</strong><br>
                        <span>${borrowerData.consent == 1 ? 'Yes' : 'No'}</span>
                    </div>
                </div>
            </div>
            
            <div style="background: #f8f9fa; padding: 15px; border-radius: 8px;">
                <h3 style="margin: 0 0 10px 0; color: #495057;">Borrowed Items</h3>
                ${itemsHtml}
            </div>
            
            <div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid #dee2e6;">
                <small style="color: #6c757d;">Borrower ID: ${borrowerData.id} | Created: ${borrowerData.created_at || 'Unknown'}</small>
            </div>
            
            <div style="margin-top: 20px; text-align: center;">
                <button class="btn-view-form" onclick="window.open('borrowform.php?id=${event.borrowerId}', '_blank')" style="background: #007bff; color: white; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; font-size: 14px;">
                    📋 View Details in Form
                </button>
            </div>
        `;
        
        // Add event listeners
        modal.querySelector('.close-event-modal').addEventListener('click', () => {
            modal.remove();
        });
        
        // Navigation button listeners
        const prevBtn = modal.querySelector('.prev-btn');
        const nextBtn = modal.querySelector('.next-btn');
        
        if (prevBtn) {
            prevBtn.addEventListener('click', async () => {
                modal.remove();
                await showEventDetailsWithNav(currentEventIndex - 1);
            });
        }
        
        if (nextBtn) {
            nextBtn.addEventListener('click', async () => {
                modal.remove();
                await showEventDetailsWithNav(currentEventIndex + 1);
            });
        }
        
        // Close modal when clicking outside
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });
        
        // Keyboard navigation
        const handleKeyPress = async (e) => {
            if (e.key === 'ArrowLeft' && eventIndex > 0) {
                modal.remove();
                await showEventDetailsWithNav(currentEventIndex - 1);
            } else if (e.key === 'ArrowRight' && eventIndex < currentDayEvents.length - 1) {
                modal.remove();
                await showEventDetailsWithNav(currentEventIndex + 1);
            } else if (e.key === 'Escape') {
                modal.remove();
            }
        };
        
        document.addEventListener('keydown', handleKeyPress);
        
        // Clean up event listener when modal is closed
        modal.addEventListener('remove', () => {
            document.removeEventListener('keydown', handleKeyPress);
        });
        
    } catch (error) {
        console.error('Error showing event details:', error);
        
        // Show more specific error message
        let errorMessage = 'Error loading event details. Please try again.';
        if (error.message) {
            errorMessage += '\n\nDetails: ' + error.message;
        }
        alert(errorMessage);
    }
}

// Function to show detailed event information (original function - kept for compatibility)
async function showEventDetails(eventType, borrowerName, description, borrowerId) {
    console.log('showEventDetails called with:', { eventType, borrowerName, description, borrowerId });
    
    try {
        console.log('Fetching borrower details for ID:', borrowerId);
        // Fetch detailed borrower information
        const response = await fetch(`fetch_student_info.php?id=${borrowerId}`);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const borrowerData = await response.json();
        
        console.log('Borrower data received:', borrowerData);
        
        if (borrowerData.error) {
            console.error('Error fetching borrower details:', borrowerData.error);
            return;
        }
        
        // Create modal content with the better layout
        const modal = document.createElement('div');
        modal.className = 'event-details-modal';
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background-color: rgba(0,0,0,0.4);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 2000;
        `;
        
        modal.innerHTML = `
            <div class="modal-content" style="background:#fff; padding:25px; border-radius:12px; max-width:600px; width:90%; margin:auto; position:relative;">
                <span class="close-event-modal" style="position:absolute; top:15px; right:20px; cursor:pointer; font-size:24px; color:#666;">&times;</span>
                <div id="eventDetailsContent">
                    <!-- Content will be loaded here -->
                </div>
            </div>
        `;
        
        // Add modal to page
        console.log('Adding modal to page');
        document.body.appendChild(modal);
        console.log('Modal added successfully');
        
        // Show loading state
        const content = document.getElementById('eventDetailsContent');
        content.innerHTML = '<div style="text-align: center; padding: 20px;"><i class="bx bx-loader-alt bx-spin" style="font-size: 2rem;"></i><p>Loading borrower details...</p></div>';
        
        // Fetch borrowed items
        const itemsResponse = await fetch(`fetch_borrowed_items.php?form_id=${borrowerId}`);
        const items = await itemsResponse.json();
        
        let itemsHtml = '';
        if (items && items.length > 0) {
            items.forEach(item => {
                itemsHtml += `
                    <div style="background: #f8f9fa; padding: 10px; border-radius: 6px; margin: 5px 0;">
                        <strong>${item.item_name}</strong> - ${item.quantity} ${item.unit}
                    </div>
                `;
            });
        } else {
            itemsHtml = '<div style="color: #666; font-style: italic;">No borrowed items found</div>';
        }
        
        // Update content with the better layout
        content.innerHTML = `
            <div style="margin-bottom: 20px;">
                <h2 style="margin: 0 0 15px 0; color: #333;">Borrower Details</h2>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div>
                        <strong>Name:</strong><br>
                        <span>${borrowerData.firstname} ${borrowerData.middleinitial || ''} ${borrowerData.lastname}</span>
                    </div>
                    <div>
                        <strong>ID Number:</strong><br>
                        <span>${borrowerData.idnum}</span>
                    </div>
                    <div>
                        <strong>Department:</strong><br>
                        <span>${borrowerData.department}</span>
                    </div>
                    <div>
                        <strong>Course:</strong><br>
                        <span>${borrowerData.course}</span>
                    </div>
                    <div>
                        <strong>Email:</strong><br>
                        <span>${borrowerData.email}</span>
                    </div>
                    <div>
                        <strong>Contact:</strong><br>
                        <span>${borrowerData.cpnnumber}</span>
                    </div>
                </div>
            </div>
            
            <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                <h3 style="margin: 0 0 10px 0; color: #495057;">Borrowing Information</h3>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                    <div>
                        <strong>Borrow Date:</strong><br>
                        <span>${formatDate(borrowerData.borrow_date)}</span>
                    </div>
                    <div>
                        <strong>Return Date:</strong><br>
                        <span>${formatDate(borrowerData.return_date)}</span>
                    </div>
                    <div>
                        <strong>Status:</strong><br>
                        <span style="padding: 4px 8px; border-radius: 4px; background: ${getStatusColor(borrowerData.status)}; color: white; font-size: 0.8rem;">${borrowerData.status}</span>
                    </div>
                    <div>
                        <strong>Consent:</strong><br>
                        <span>${borrowerData.consent == 1 ? 'Yes' : 'No'}</span>
                    </div>
                </div>
            </div>
            
            <div style="background: #f8f9fa; padding: 15px; border-radius: 8px;">
                <h3 style="margin: 0 0 10px 0; color: #495057;">Borrowed Items</h3>
                ${itemsHtml}
            </div>
            
            <div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid #dee2e6;">
                <small style="color: #6c757d;">Borrower ID: ${borrowerData.id} | Created: ${borrowerData.created_at || 'Unknown'}</small>
            </div>
            
            <div style="margin-top: 20px; text-align: center;">
                <button class="btn-view-form" onclick="window.open('borrowform.php?id=${borrowerId}', '_blank')" style="background: #007bff; color: white; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; font-size: 14px;">
                    📋 View Details in Form
                </button>
            </div>
        `;
        
        // Add event listeners
        modal.querySelector('.close-event-modal').addEventListener('click', () => {
            modal.remove();
        });
        
        // Close modal when clicking outside
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });
        
    } catch (error) {
        console.error('Error showing event details:', error);
        alert('Error loading event details. Please try again.');
    }
}

// Function to format date
function formatDate(dateString) {
    if (!dateString || dateString === '0000-00-00') return 'Not set';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

// Function to load borrowed items
async function loadBorrowedItems(borrowerId, containerId) {
    try {
        const response = await fetch(`fetch_borrowed_items.php?form_id=${borrowerId}`);
        const items = await response.json();
        
        const container = document.getElementById(containerId);
        
        if (items && items.length > 0) {
            let html = '<div class="items-grid">';
            items.forEach(item => {
                html += `
                    <div class="item-card">
                        <div class="item-name">${item.item_name}</div>
                        <div class="item-quantity">${item.quantity} ${item.unit}</div>
                    </div>
                `;
            });
            html += '</div>';
            container.innerHTML = html;
        } else {
            container.innerHTML = '<div class="no-items">No borrowed items found</div>';
        }
    } catch (error) {
        console.error('Error loading borrowed items:', error);
        document.getElementById(containerId).innerHTML = '<div class="error">Error loading items</div>';
    }
}

// Function to view borrower details in a modal (similar to equipment view)
window.viewBorrowerDetails = function(borrowerId) {
    console.log('viewBorrowerDetails called with borrowerId:', borrowerId);
    
    // Create modal if it doesn't exist
    let borrowerModal = document.getElementById('borrowerDetailsModal');
    if (!borrowerModal) {
        console.log('Creating new borrower modal');
        borrowerModal = document.createElement('div');
        borrowerModal.id = 'borrowerDetailsModal';
        borrowerModal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background-color: rgba(0,0,0,0.4);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 2000;
        `;
        
        borrowerModal.innerHTML = `
            <div class="modal-content" style="background:#fff; padding:25px; border-radius:12px; max-width:600px; width:90%; margin:auto; position:relative;">
                <span id="closeBorrowerModal" style="position:absolute; top:15px; right:20px; cursor:pointer; font-size:24px; color:#666;">&times;</span>
                <div id="borrowerDetailsContent">
                    <!-- Content will be loaded here -->
                </div>
            </div>
        `;
        
        document.body.appendChild(borrowerModal);
        console.log('Modal added to DOM');
        
        // Add close functionality
        const closeBtn = borrowerModal.querySelector('#closeBorrowerModal');
        closeBtn.addEventListener('click', () => {
            borrowerModal.style.display = 'none';
        });
        
        borrowerModal.addEventListener('click', (e) => {
            if (e.target === borrowerModal) {
                borrowerModal.style.display = 'none';
            }
        });
    }
    
    // Show loading state
    const content = document.getElementById('borrowerDetailsContent');
    content.innerHTML = '<div style="text-align: center; padding: 20px;"><i class="bx bx-loader-alt bx-spin" style="font-size: 2rem;"></i><p>Loading borrower details...</p></div>';
    borrowerModal.style.display = 'flex';
    console.log('Modal should be visible now');
    
    // Fetch borrower details
    console.log('Fetching borrower details for ID:', borrowerId);
    fetch(`fetch_student_info.php?id=${borrowerId}`)
        .then(response => response.json())
        .then(data => {
            console.log('Borrower data received:', data);
            if (data.error) {
                content.innerHTML = `<div style="text-align: center; padding: 20px; color: red;"><p>Error: ${data.error}</p></div>`;
            } else {
                // Fetch borrowed items
                fetch(`fetch_borrowed_items.php?form_id=${borrowerId}`)
                    .then(response => response.json())
                    .then(items => {
                        let itemsHtml = '';
                        if (items && items.length > 0) {
                            items.forEach(item => {
                                itemsHtml += `
                                    <div style="background: #f8f9fa; padding: 10px; border-radius: 6px; margin: 5px 0;">
                                        <strong>${item.item_name}</strong> - ${item.quantity} ${item.unit}
                                    </div>
                                `;
                            });
                        } else {
                            itemsHtml = '<div style="color: #666; font-style: italic;">No borrowed items found</div>';
                        }
                        
                        content.innerHTML = `
                            <div style="margin-bottom: 20px;">
                                <h2 style="margin: 0 0 15px 0; color: #333;">Borrower Details</h2>
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                                    <div>
                                        <strong>Name:</strong><br>
                                        <span>${data.firstname} ${data.middleinitial} ${data.lastname}</span>
                                    </div>
                                    <div>
                                        <strong>ID Number:</strong><br>
                                        <span>${data.idnum}</span>
                                    </div>
                                    <div>
                                        <strong>Department:</strong><br>
                                        <span>${data.department}</span>
                                    </div>
                                    <div>
                                        <strong>Course:</strong><br>
                                        <span>${data.course}</span>
                                    </div>
                                    <div>
                                        <strong>Email:</strong><br>
                                        <span>${data.email}</span>
                                    </div>
                                    <div>
                                        <strong>Contact:</strong><br>
                                        <span>${data.cpnnumber}</span>
                                    </div>
                                </div>
                            </div>
                            
                            <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                                <h3 style="margin: 0 0 10px 0; color: #495057;">Borrowing Information</h3>
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                                    <div>
                                        <strong>Borrow Date:</strong><br>
                                        <span>${formatDate(data.borrow_date)}</span>
                                    </div>
                                    <div>
                                        <strong>Return Date:</strong><br>
                                        <span>${formatDate(data.return_date)}</span>
                                    </div>
                                    <div>
                                        <strong>Status:</strong><br>
                                        <span style="padding: 4px 8px; border-radius: 4px; background: ${getStatusColor(data.status)}; color: white; font-size: 0.8rem;">${data.status}</span>
                                    </div>
                                    <div>
                                        <strong>Consent:</strong><br>
                                        <span>${data.consent == 1 ? 'Yes' : 'No'}</span>
                                    </div>
                                </div>
                            </div>
                            
                            <div style="background: #f8f9fa; padding: 15px; border-radius: 8px;">
                                <h3 style="margin: 0 0 10px 0; color: #495057;">Borrowed Items</h3>
                                ${itemsHtml}
                            </div>
                            
                            <div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid #dee2e6;">
                                <small style="color: #6c757d;">Borrower ID: ${data.id} | Created: ${data.created_at || 'Unknown'}</small>
                            </div>
                        `;
                    })
                    .catch(error => {
                        content.innerHTML = `<div style="text-align: center; padding: 20px; color: red;"><p>Error loading borrowed items: ${error.message}</p></div>`;
                    });
            }
        })
        .catch(error => {
            content.innerHTML = `<div style="text-align: center; padding: 20px; color: red;"><p>Error loading borrower details: ${error.message}</p></div>`;
        });
}

// Function to get status color
function getStatusColor(status) {
    switch(status) {
        case 'pending': return '#ffc107';
        case 'approved': return '#28a745';
        case 'rejected': return '#dc3545';
        case 'returned': return '#17a2b8';
        default: return '#6c757d';
    }
}

// Initialize calendar
initializeCalendar();

// Dropdown functionality for Borrowers Forms
function initializeDropdown() {
    const dropdown = document.getElementById('borrowersDropdown');
    const dropdownMenu = document.getElementById('borrowersDropdownMenu');
    
    if (dropdown && dropdownMenu) {
        // Handle dropdown toggle - only when clicking the arrow
        const dropdownArrow = dropdown.querySelector('.dropdown-arrow');
        if (dropdownArrow) {
            dropdownArrow.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                dropdown.classList.toggle('active');
                dropdownMenu.classList.toggle('show');
            });
        }
        
        // Close dropdown when clicking outside
        document.addEventListener('click', function(e) {
            if (!dropdown.contains(e.target)) {
                dropdown.classList.remove('active');
                dropdownMenu.classList.remove('show');
            }
        });
    }
}

// Initialize dropdown when DOM is loaded
initializeDropdown();

// --- ADD AUDIT BUTTON FUNCTIONALITY (WORKING VERSION) ---
function setupAuditModal() {
    const addAuditBtn = document.getElementById('add-audit-btn');
    const auditModal = document.getElementById('add-audit-modal');
    const auditForm = document.getElementById('audit-form');
    
    console.log('Audit elements found:', {
        button: !!addAuditBtn,
        modal: !!auditModal,
        form: !!auditForm
    });
    
    if (addAuditBtn) {
        console.log('Button found, adding click listener...');
    }
    
    // Open audit modal
    if (addAuditBtn && auditModal) {
        console.log('Adding click listener to audit button...');
        addAuditBtn.addEventListener('click', function(e) {
            console.log('Add audit button clicked! (before preventDefault)');
            e.preventDefault();
            e.stopPropagation(); // Prevent global click handler from interfering
            console.log('Add audit button clicked! (after preventDefault)');
            auditModal.style.display = 'flex';
            
            // Set default date to today
            const dateInput = document.getElementById('audit-date');
            if (dateInput) {
                const today = new Date().toISOString().split('T')[0];
                dateInput.value = today;
            }
        });
        console.log('Click listener added successfully!');
    } else {
        console.error('Missing audit button or modal:', { button: !!addAuditBtn, modal: !!auditModal });
    }
    
    // Close modal when clicking outside
    if (auditModal) {
        auditModal.addEventListener('click', function(e) {
            if (e.target === auditModal) {
                auditModal.style.display = 'none';
                if (auditForm) {
                    auditForm.reset();
                }
            }
        });
    }
    
    // Handle form submission
    if (auditForm) {
        auditForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(auditForm);
            
            // Show loading state
            const submitBtn = auditForm.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            submitBtn.textContent = 'Saving...';
            submitBtn.disabled = true;
            
            // Send data to backend
            fetch('save_audit.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Audit scheduled successfully!');
                    auditModal.style.display = 'none';
                    auditForm.reset();
                    
                    // Refresh calendar to show the new audit event
                    if (typeof loadCalendarEvents === 'function') {
                        loadCalendarEvents();
                    }
                } else {
                    alert('Error: ' + (data.error || 'Failed to save audit'));
                }
            })
            .catch(error => {
                console.error('Error saving audit:', error);
                alert('Error saving audit. Please try again.');
            })
            .finally(() => {
                // Reset button state
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
            });
        });
    }
}

// Set up audit modal
setupAuditModal();

// ===== EQUIPMENT AUDIT SYSTEM =====

// Global variables for equipment audit system
let equipmentAuditEntries = [];
let equipmentAuditEntryCounter = 0;

// Initialize equipment audit system immediately
initializeEquipmentAuditSystem();

function initializeEquipmentAuditSystem() {
    console.log('Initializing equipment audit system...');
    const addAuditBtn = document.getElementById('addAuditEntry');
    console.log('Add audit button element:', addAuditBtn);
    
    if (addAuditBtn) {
        console.log('Equipment audit button found, adding listener...');
        addAuditBtn.addEventListener('click', function(e) {
            console.log('Equipment audit button clicked!');
            e.preventDefault();
            e.stopPropagation();
            addEquipmentAuditEntry();
        });
        console.log('Equipment audit listener added successfully!');
    } else {
        console.log('Equipment audit button not found - will retry on DOMContentLoaded');
        // Retry when DOM is fully loaded
        document.addEventListener('DOMContentLoaded', function() {
            const retryBtn = document.getElementById('addAuditEntry');
            if (retryBtn) {
                console.log('Equipment audit button found on retry, adding listener...');
                retryBtn.addEventListener('click', function(e) {
                    console.log('Equipment audit button clicked!');
                    e.preventDefault();
                    e.stopPropagation();
                    addEquipmentAuditEntry();
                });
            }
        });
    }
}

function addEquipmentAuditEntry() {
    console.log('Adding equipment audit entry...');
    equipmentAuditEntryCounter++;
    const entryId = `audit-entry-${equipmentAuditEntryCounter}`;
    
    const entryHtml = `
        <div id="${entryId}" class="audit-entry">
            <div class="audit-entry-header">
                <h4 class="audit-entry-title">Audit Entry #${equipmentAuditEntryCounter}</h4>
                <button type="button" onclick="removeEquipmentAuditEntry('${entryId}')" class="btn-remove-audit">
                    <i class='bx bx-trash'></i> Remove
                </button>
            </div>
            
            <div class="audit-entry-grid">
                <div class="audit-field">
                    <label>Semester</label>
                    <select name="audit_semester[]" required>
                        <option value="">Select Semester</option>
                        <option value="1st Sem">1st Sem</option>
                        <option value="2nd Sem">2nd Sem</option>
                    </select>
                </div>
                
                <div class="audit-field">
                    <label>Quantity On Site</label>
                    <input type="number" name="audit_quantity[]" placeholder="0" min="0" required>
                </div>
                
                <div class="audit-field">
                    <label>Unit</label>
                    <select name="audit_unit[]" required>
                        <option value="pcs" selected>pcs</option>
                        <option value="sets">sets</option>
                        <option value="units">units</option>
                        <option value="box">box</option>
                        <option value="others">others</option>
                    </select>
                </div>
                
                <div class="audit-field">
                    <label>Audit Date</label>
                    <input type="date" name="audit_date[]" required>
                </div>
            </div>
        </div>
    `;
    
    const container = document.getElementById('auditEntriesContainer');
    if (container) {
        container.insertAdjacentHTML('beforeend', entryHtml);
        
        // Set default date to today
        const dateInput = document.querySelector(`#${entryId} input[type="date"]`);
        if (dateInput) {
            dateInput.value = new Date().toISOString().split('T')[0];
        }
        
        // Store entry reference
        equipmentAuditEntries.push(entryId);
        console.log('Equipment audit entry added successfully');
    } else {
        console.error('auditEntriesContainer not found');
    }
}

function removeEquipmentAuditEntry(entryId) {
    const entry = document.getElementById(entryId);
    if (entry) {
        entry.remove();
        equipmentAuditEntries = equipmentAuditEntries.filter(id => id !== entryId);
        console.log('Equipment audit entry removed');
    }
}

// Function to collect equipment audit data from form
function collectEquipmentAuditData() {
    const auditData = [];
    const entries = document.querySelectorAll('.audit-entry');
    
    entries.forEach(entry => {
        const semester = entry.querySelector('select[name="audit_semester[]"]').value;
        const quantity = entry.querySelector('input[name="audit_quantity[]"]').value;
        const unit = entry.querySelector('select[name="audit_unit[]"]').value;
        const date = entry.querySelector('input[name="audit_date[]"]').value;
        
        if (semester && quantity && date) {
            auditData.push({
                semester: semester,
                quantity_onsite: parseInt(quantity),
                unit: unit,
                audit_date: date
            });
        }
    });
    
    return auditData;
}

// Function to save equipment audits via API
function saveEquipmentAudits(itemId, audits) {
    return fetch('equipment_audit_api.php?action=save', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            item_id: itemId,
            audits: audits
        })
    })
    .then(response => response.json());
}

// Function to load equipment audits for an item
function loadEquipmentAudits(itemId) {
    return fetch(`equipment_audit_api.php?action=get&item_id=${itemId}`)
        .then(response => response.json());
}

// Function to display equipment audits in table
function displayEquipmentAuditsTable(audits) {
    const tableBody = document.getElementById('auditTableBody');
    const tableContainer = document.getElementById('auditEntriesTable');
    
    if (!tableBody || !tableContainer) {
        console.error('Audit table elements not found');
        return;
    }
    
    if (!audits || audits.length === 0) {
        tableContainer.style.display = 'none';
        return;
    }
    
    tableBody.innerHTML = '';
    audits.forEach(audit => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td style="padding: 12px; border-bottom: 1px solid #dee2e6;">${audit.semester}</td>
            <td style="padding: 12px; text-align: center; border-bottom: 1px solid #dee2e6;">${audit.quantity_onsite}</td>
            <td style="padding: 12px; text-align: center; border-bottom: 1px solid #dee2e6;">${audit.unit}</td>
            <td style="padding: 12px; text-align: center; border-bottom: 1px solid #dee2e6;">${formatDate(audit.audit_date)}</td>
            <td style="padding: 12px; text-align: center; border-bottom: 1px solid #dee2e6;">
                <button onclick="deleteEquipmentAuditEntry(${audit.id})" style="background: #dc3545; color: white; border: none; padding: 4px 8px; border-radius: 4px; cursor: pointer; font-size: 12px;">
                    <i class='bx bx-trash'></i>
                </button>
            </td>
        `;
        tableBody.appendChild(row);
    });
    
    tableContainer.style.display = 'block';
}

function deleteEquipmentAuditEntry(auditId) {
    if (!confirm('Are you sure you want to delete this audit entry?')) {
        return;
    }
    
    fetch('equipment_audit_api.php?action=delete', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            audit_id: auditId
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Audit entry deleted successfully!');
            // Reload audits for current item
            const currentItemId = document.getElementById('id');
            if (currentItemId && currentItemId.value) {
                loadEquipmentAudits(currentItemId.value).then(result => {
                    if (result.success) {
                        displayEquipmentAuditsTable(result.audits);
                    }
                });
            }
        } else {
            alert('Error: ' + data.error);
        }
    })
    .catch(error => {
        alert('Error deleting audit entry: ' + error.message);
    });
}

// Function to load and display equipment audit history in view modal
function loadEquipmentAuditHistory(itemId) {
    const auditContent = document.getElementById('auditHistoryContent');
    if (!auditContent) return;
    
    loadEquipmentAudits(itemId).then(result => {
        if (result.success && result.audits && result.audits.length > 0) {
            let auditHtml = '<div style="max-height: 200px; overflow-y: auto;">';
            auditHtml += '<table style="width: 100%; border-collapse: collapse; font-size: 0.9rem;">';
            auditHtml += '<thead><tr style="background: #e9ecef;">';
            auditHtml += '<th style="padding: 8px; text-align: left; border-bottom: 1px solid #dee2e6;">Semester</th>';
            auditHtml += '<th style="padding: 8px; text-align: center; border-bottom: 1px solid #dee2e6;">Quantity</th>';
            auditHtml += '<th style="padding: 8px; text-align: center; border-bottom: 1px solid #dee2e6;">Unit</th>';
            auditHtml += '<th style="padding: 8px; text-align: center; border-bottom: 1px solid #dee2e6;">Date</th>';
            auditHtml += '</tr></thead><tbody>';
            
            result.audits.forEach(audit => {
                auditHtml += '<tr>';
                auditHtml += `<td style="padding: 8px; border-bottom: 1px solid #dee2e6;">${audit.semester}</td>`;
                auditHtml += `<td style="padding: 8px; text-align: center; border-bottom: 1px solid #dee2e6;">${audit.quantity_onsite}</td>`;
                auditHtml += `<td style="padding: 8px; text-align: center; border-bottom: 1px solid #dee2e6;">${audit.unit}</td>`;
                auditHtml += `<td style="padding: 8px; text-align: center; border-bottom: 1px solid #dee2e6;">${formatDate(audit.audit_date)}</td>`;
                auditHtml += '</tr>';
            });
            
            auditHtml += '</tbody></table></div>';
            auditContent.innerHTML = auditHtml;
        } else {
            auditContent.innerHTML = '<div style="text-align: center; padding: 20px; color: #6c757d;"><p>No audit history found</p></div>';
        }
    }).catch(error => {
        auditContent.innerHTML = '<div style="text-align: center; padding: 20px; color: #dc3545;"><p>Error loading audit history</p></div>';
    });
}

// Make functions globally available
window.addEquipmentAuditEntry = addEquipmentAuditEntry;
window.removeEquipmentAuditEntry = removeEquipmentAuditEntry;
window.deleteEquipmentAuditEntry = deleteEquipmentAuditEntry;
window.loadEquipmentAuditHistory = loadEquipmentAuditHistory;
window.collectEquipmentAuditData = collectEquipmentAuditData;
window.saveEquipmentAudits = saveEquipmentAudits;
window.displayEquipmentAuditsTable = displayEquipmentAuditsTable;
});