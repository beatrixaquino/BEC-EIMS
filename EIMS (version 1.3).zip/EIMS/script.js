document.addEventListener('DOMContentLoaded', function () {
    // Existing script: Sidebar functionality
    const allSideMenu = document.querySelectorAll('#sidebar .side-menu.top li a');

    // Get the current page from the body 'data-page' attribute
    let currentPage = document.body.getAttribute('data-page');

    // Handle index.html as the dashboard page
    if (currentPage === 'index' || currentPage === 'dashboard') {
        currentPage = 'index';  // Treat dashboard as 'index'
    }

    // Set up sidebar active class
    allSideMenu.forEach(item => {
        const li = item.parentElement;
        const pageName = item.getAttribute("href").split("/").pop().split(".")[0];
        
        // Handle index.html as dashboard
        if (pageName === 'index' && currentPage === 'index') {
            li.classList.add('active');
        } else if (pageName !== 'index' && pageName === currentPage) {
            li.classList.add('active');
        } else {
            li.classList.remove('active');
        }

        // Add click event to update the active class
        item.addEventListener('click', function () {
            allSideMenu.forEach(i => {
                i.parentElement.classList.remove('active');
            });
            li.classList.add('active');
        });
    });

    // Toggle sidebar functionality
    const menuBar = document.querySelector('#content nav .bx.bx-menu');
    const sidebar = document.getElementById('sidebar');

    if (menuBar) {
        menuBar.addEventListener('click', function () {
            sidebar.classList.toggle('hide');
        });
    } else {
        console.error('Sidebar toggle element (bx bx-menu) not found.');
    }

    // Search functionality
    const searchButton = document.querySelector('#content nav form .form-input button');
    const searchButtonIcon = document.querySelector('#content nav form .form-input button .bx');
    const searchForm = document.querySelector('#content nav form');

    searchButton.addEventListener('click', function (e) {
        if (window.innerWidth < 576) {
            e.preventDefault();
            searchForm.classList.toggle('show');
            if (searchForm.classList.contains('show')) {
                searchButtonIcon.classList.replace('bx-search', 'bx-x');
            } else {
                searchButtonIcon.classList.replace('bx-x', 'bx-search');
            }
        }
    });

    // Responsive behavior on load
    if (window.innerWidth < 768) {
        sidebar.classList.add('hide');
    } else if (window.innerWidth > 576) {
        searchButtonIcon.classList.replace('bx-x', 'bx-search');
        searchForm.classList.remove('show');
    }

    window.addEventListener('resize', function () {
        if (this.innerWidth > 576) {
            searchButtonIcon.classList.replace('bx-x', 'bx-search');
            searchForm.classList.remove('show');
        }
    });

    // Dark mode toggle
    const switchMode = document.getElementById('switch-mode');
    if (switchMode) {
        switchMode.addEventListener('change', function () {
            if (this.checked) {
                document.body.classList.add('dark');
            } else {
                document.body.classList.remove('dark');
            }
        });
    }

    // Log the page loaded and check current page
    console.log("Page loaded. Current page:", currentPage);

    // Define the editAdmin function
    window.editAdmin = function(button) {
        console.log("Edit button clicked.");  // Log to confirm button click

        // Get data attributes from the clicked button
        const id = button.getAttribute('data-id');
        const username = button.getAttribute('data-username');
        const password = button.getAttribute('data-password');
        const acctype = button.getAttribute('data-acctype');

        // Debugging: Log the values to check if they are being captured correctly
        console.log("Admin ID:", id);
        console.log("Username:", username);
        console.log("Password:", password);
        console.log("Account Type:", acctype);

        // Populate the form fields with the clicked admin's details
        document.getElementById('username').value = username;
        document.getElementById('password').value = password; 
        document.getElementById('acctype').value = acctype;

        // Add hidden input field to store the ID of the admin being edited
        let hiddenIdField = document.getElementById('admin-id');
        if (!hiddenIdField) {
            hiddenIdField = document.createElement('input');
            hiddenIdField.type = 'hidden';
            hiddenIdField.id = 'admin-id';
            hiddenIdField.name = 'id';
            document.querySelector('form').appendChild(hiddenIdField);
        }
        hiddenIdField.value = id;

        // Confirm hidden ID field value for debugging
        console.log("Hidden ID Field Value:", hiddenIdField.value);
    };

    // Check if the current page is 'usermng' before setting up editAdmin
    if (currentPage === 'usermng') {
        console.log("Setting up editAdmin for admin management page.");

        // Attach event listeners to each edit button
        document.querySelectorAll('.btn-edit').forEach(button => {
            button.addEventListener('click', function () {
                console.log("Edit button was clicked on item with ID:", button.getAttribute('data-id'));
                editAdmin(button); // Call the editAdmin function
            });
        });
    } else {
        console.log("Current page is not 'usermng', editAdmin not set up.");
    }

    //Calendar 

    // Sample event data
        const events = {
        '2023-11-15': [
            {
                id: 1,
                title: 'Team Meeting',
                type: 'work',
                time: '10:00 AM - 11:30 AM',
                venue: 'Conference Room A',
                description: 'Weekly team sync to discuss project progress and roadblocks.'
            },
            {
                id: 2,
                title: 'Lunch with Client',
                type: 'work',
                time: '12:30 PM - 2:00 PM',
                venue: 'Downtown Bistro',
                description: 'Discuss potential partnership opportunities with new client.'
            }
        ],
        '2023-11-20': [
            {
                id: 3,
                title: 'Doctor Appointment',
                type: 'personal',
                time: '3:00 PM - 3:30 PM',
                venue: 'Family Health Clinic',
                description: 'Annual physical examination and health checkup.'
            }
        ],
        '2023-11-25': [
            {
                id: 4,
                title: 'Anniversary Dinner',
                type: 'special',
                time: '7:00 PM - 9:00 PM',
                venue: 'The French Laundry',
                description: 'Celebrating 5 years of marriage with a special dinner.'
            }
        ],
        '2023-12-05': [
            {
                id: 5,
                title: 'Project Deadline',
                type: 'work',
                time: 'All day',
                venue: 'Home Office',
                description: 'Final submission for the quarterly project report.'
            }
        ]
    };

    let currentMonth = new Date().getMonth();
    let currentYear = new Date().getFullYear();

    document.addEventListener('DOMContentLoaded', function () {
        console.log("DOM loaded. Initializing calendar...");
        renderCalendar(currentMonth, currentYear);

        document.getElementById('prev-month').addEventListener('click', function () {
            currentMonth--;
            if (currentMonth < 0) {
                currentMonth = 11;
                currentYear--;
            }
            renderCalendar(currentMonth, currentYear);
        });

        document.getElementById('next-month').addEventListener('click', function () {
            currentMonth++;
            if (currentMonth > 11) {
                currentMonth = 0;
                currentYear++;
            }
            renderCalendar(currentMonth, currentYear);
        });

        document.getElementById('close-modal').addEventListener('click', function () {
            document.getElementById('event-modal').classList.remove('active');
        });
    });

    function renderCalendar(month, year) {
        console.log(`Rendering calendar for ${month + 1}/${year}`);
        const monthNames = ["January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"];

        const calendarDays = document.getElementById('calendar-days');
        if (!calendarDays) {
            console.error("Element with ID 'calendar-days' not found in DOM.");
            return;
        }

        document.getElementById('current-month-year').textContent = `${monthNames[month]} ${year}`;

        const firstDay = new Date(year, month, 1);
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        const startingDay = firstDay.getDay();

        calendarDays.innerHTML = '';

        // Empty placeholders for days before the 1st
        for (let i = 0; i < startingDay; i++) {
            const emptyDay = document.createElement('div');
            emptyDay.classList.add('calendar-day', 'empty');
            calendarDays.appendChild(emptyDay);
        }

        // Actual days of the month
        for (let day = 1; day <= daysInMonth; day++) {
            const date = new Date(year, month, day);
            const dateString = formatDate(date);

            const dayElement = document.createElement('div');
            dayElement.classList.add('calendar-day');

            const dateNumber = document.createElement('div');
            dateNumber.classList.add('date-number');
            dateNumber.textContent = day;
            dayElement.appendChild(dateNumber);

            if (events[dateString]) {
                events[dateString].forEach(event => {
                    const eventElement = document.createElement('div');
                    eventElement.classList.add('event-preview', event.type);
                    eventElement.textContent = event.title;
                    dayElement.appendChild(eventElement);
                });
            }

            dayElement.addEventListener('click', function () {
                showEventDetails(date);
            });

            calendarDays.appendChild(dayElement);
        }

        console.log(`Calendar rendered: ${daysInMonth} days + ${startingDay} empty`);
    }

    function showEventDetails(date) {
        const dateString = formatDate(date);
        const modal = document.getElementById('event-modal');

        if (events[dateString] && events[dateString].length > 0) {
            const event = events[dateString][0];
            document.getElementById('modal-event-title').textContent = event.title;
            document.getElementById('modal-event-type').textContent = event.type.charAt(0).toUpperCase() + event.type.slice(1);
            document.getElementById('modal-event-time').textContent = event.time;
            document.getElementById('modal-event-venue').textContent = event.venue;
            document.getElementById('modal-event-description').textContent = event.description;

            modal.classList.add('active');
        }
    }

    function formatDate(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }


});