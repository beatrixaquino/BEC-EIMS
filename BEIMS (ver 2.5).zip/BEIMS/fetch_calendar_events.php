<?php
// Start session and include DB connection
session_start();
include_once 'dbconnect.php';

// Set content type to JSON
header('Content-Type: application/json');

try {
    // Fetch approved borrower forms with borrow and return dates
    $sql = "SELECT id, firstname, lastname, borrow_date, return_date, status 
            FROM borrowers 
            WHERE status = 'approved' 
            AND borrow_date IS NOT NULL 
            AND return_date IS NOT NULL 
            ORDER BY borrow_date ASC";
    
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $events = [];
    
    while ($row = $result->fetch_assoc()) {
        // Create events for both borrow and return dates
        $borrowerName = $row['firstname'] . ' ' . $row['lastname'];
        
        // Borrow event
        $events[] = [
            'id' => $row['id'] . '_borrow',
            'title' => 'Borrow: ' . $borrowerName,
            'date' => $row['borrow_date'],
            'type' => 'borrow',
            'borrower_id' => $row['id'],
            'borrower_name' => $borrowerName,
            'description' => 'Equipment borrowed by ' . $borrowerName
        ];
        
        // Return event
        $events[] = [
            'id' => $row['id'] . '_return',
            'title' => 'Return: ' . $borrowerName,
            'date' => $row['return_date'],
            'type' => 'return',
            'borrower_id' => $row['id'],
            'borrower_name' => $borrowerName,
            'description' => 'Equipment returned by ' . $borrowerName
        ];
    }
    
    echo json_encode([
        'success' => true,
        'events' => $events
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage()
    ]);
}

$stmt->close();
$conn->close();
?> 