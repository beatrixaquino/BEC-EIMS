<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Link Working</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="istyle.css">
</head>
<body>
    <div id="sidebar">
        <div class="side-menu top">
            <ul>
                <li class="dropdown" id="borrowersDropdown">
                    <div class="dropdown-toggle">
                        <a href="borrowform.php">
                            <i class='bx bxs-report'></i>
                            <span class="text">Borrowers Forms</span>
                        </a>
                        <i class='bx bx-chevron-down dropdown-arrow'></i>
                    </div>
                    <ul class="dropdown-menu" id="borrowersDropdownMenu">
                        <li><a href="borrowform.php"><i class='bx bxs-report'></i> All Forms</a></li>
                        <li><a href="manage_deleted_records.php"><i class='bx bxs-trash'></i> Deleted Records</a></li>
                        <li><a href="borrowform.php?filter=pending"><i class='bx bxs-time'></i> Pending Forms</a></li>
                        <li><a href="borrowform.php?filter=approved"><i class='bx bxs-check-circle'></i> Approved Forms</a></li>
                        <li><a href="borrowform.php?filter=rejected"><i class='bx bxs-x-circle'></i> Rejected Forms</a></li>
                        <li><a href="borrowform.php?filter=returned"><i class='bx bxs-archive'></i> Returned Forms</a></li>
                    </ul>
                </li>
                <li>
                    <a href="equiplist.php">
                        <i class='bx bxs-grid-alt'></i>
                        <span class="text">Equipment List</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <div id="content">
        <h1>Test Link Working</h1>
        <p>This page tests that the "Borrowers Forms" link works properly.</p>
        
        <div style="margin-top: 20px; padding: 20px; background: #f8f9fa; border-radius: 8px;">
            <h3>Test Instructions:</h3>
            <ol>
                <li><strong>Click on "Borrowers Forms" text</strong> - Should navigate to borrowform.php</li>
                <li><strong>Click on the dropdown arrow</strong> - Should show dropdown menu</li>
                <li><strong>Click on dropdown items</strong> - Should navigate to respective pages</li>
            </ol>
        </div>
        
        <div style="margin-top: 20px; padding: 20px; background: #e9ecef; border-radius: 8px;">
            <h3>Expected Behavior:</h3>
            <ul>
                <li>✅ Link text should be clickable and navigate to borrowform.php</li>
                <li>✅ Dropdown arrow should toggle the menu</li>
                <li>✅ Dropdown items should be clickable</li>
                <li>✅ Clicking outside should close dropdown</li>
            </ul>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html> 