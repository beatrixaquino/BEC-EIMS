<?php
session_start();
include_once "dbconnect.php";

// Check if user is logged in and is superadmin
if (!isset($_SESSION['user_id']) || $_SESSION['acctype'] !== 'superadmin') {
    echo "<h2>❌ Access Denied</h2>";
    echo "<p>This page is only for superadmin users.</p>";
    echo "<p><a href='login.php'>Login as Superadmin</a></p>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="istyle.css">
    <title>Dropdown Debug Test</title>
    <style>
        /* Force show dropdown for debugging */
        #sidebar .side-menu .dropdown-menu {
            opacity: 1 !important;
            visibility: visible !important;
            transform: translateX(0) !important;
            display: block !important;
            background: red !important;
            border: 2px solid blue !important;
        }
        
        /* Make sure dropdown is visible */
        #sidebar .side-menu .dropdown {
            position: relative !important;
        }
        
        #sidebar .side-menu .dropdown-menu {
            position: absolute !important;
            left: 100% !important;
            top: 0 !important;
            z-index: 9999 !important;
        }
    </style>
</head>
<body data-page="test">

<!-- SIDEBAR -->
<section id="sidebar">
    <a href="#" class="brand">
        <i class='bx bxs-package'></i>
        <span class="text">BEC EIMS</span>
    </a>
    <ul class="side-menu top">
        <li>
            <a href="dashboard_superadmin.php">
                <i class='bx bxs-dashboard'></i>
                <span class="text">Dashboard</span>
            </a>
        </li>
        <li>
            <a href="usermng.php">
                <i class='bx bx-group'></i>
                <span class="text">User Management</span>
            </a>
        </li>
        <li class="dropdown active">
            <a href="borrowform.php" class="dropdown-toggle">
                <i class='bx bxs-report'></i>
                <span class="text">Borrowers Forms</span>
                <i class='bx bx-chevron-down dropdown-arrow'></i>
            </a>
            <ul class="dropdown-menu">
                <li><a href="borrowform.php"><i class='bx bxs-report'></i> All Forms</a></li>
                <li><a href="manage_deleted_records.php"><i class='bx bxs-trash'></i> Deleted Records</a></li>
                <li><a href="borrowform.php?filter=pending"><i class='bx bxs-time'></i> Pending Forms</a></li>
                <li><a href="borrowform.php?filter=approved"><i class='bx bxs-check-circle'></i> Approved Forms</a></li>
                <li><a href="borrowform.php?filter=rejected"><i class='bx bxs-x-circle'></i> Rejected Forms</a></li>
                <li><a href="borrowform.php?filter=returned"><i class='bx bxs-archive'></i> Returned Forms</a></li>
            </ul>
        </li>
        <li>
            <a href="equiplist.php">
                <i class='bx bxs-wrench'></i>
                <span class="text">Equipment List</span>
            </a>
        </li>
    </ul>
    <ul class="side-menu">
        <li>
            <a href="login.php" class="logout">
                <i class='bx bxs-log-out'></i>
                <span class="text">Logout</span>
            </a>
        </li>
    </ul>
</section>

<!-- CONTENT -->
<section id="content">
    <nav>
        <i class='bx bx-menu'></i>
        <a href="#" class="nav-link">Dropdown Debug</a>
        <form id="globalSearchForm" action="#" autocomplete="off">
            <div class="form-input">
                <input type="search" id="globalSearchInput" placeholder="Search...">
                <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
            </div>
        </form>
        <input type="checkbox" id="switch-mode" hidden>
        <label for="switch-mode" class="switch-mode"></label>
        <a href="#" class="notification" id="notificationIcon">
            <i class='bx bxs-bell'></i>
            <span class="num" id="notificationCount">0</span>
        </a>
        <div class="notification-dropdown" id="notificationDropdown" style="display: none;">
            <div class="notification-header">
                <h4>Notifications</h4>
                <button id="markAllRead" class="mark-all-read">Mark all read</button>
            </div>
            <div class="notification-list" id="notificationList">
                <!-- Notifications will be loaded here -->
            </div>
        </div>
        <a href="#" class="profile">
            <img src="img/people.png">
        </a>
    </nav>

    <main>
        <div class="head-title">
            <div class="left">
                <h1>Dropdown Debug Test</h1>
                <ul class="breadcrumb">
                    <li>
                        <a href="#">Debug</a>
                    </li>
                    <li><i class='bx bx-chevron-right'></i></li>
                    <li>
                        <a class="active" href="#">Dropdown</a>
                    </li>
                </ul>
            </div>
        </div>

        <div class="table-data">
            <div class="order">
                <div class="head">
                    <h3>Dropdown Debug Test</h3>
                </div>
                
                <div style="padding: 20px;">
                    <h4>🔍 Debug Information:</h4>
                    <ul style="margin: 20px 0; padding-left: 20px;">
                        <li>🎯 <strong>Forced Visibility</strong> - Dropdown should be visible with red background and blue border</li>
                        <li>📍 <strong>Position</strong> - Should appear to the right of "Borrowers Forms"</li>
                        <li>🔧 <strong>Debug Styles</strong> - Using !important to override any conflicts</li>
                        <li>📱 <strong>Z-index</strong> - Set to 9999 to ensure it's on top</li>
                    </ul>
                    
                    <h4>✅ Expected Result:</h4>
                    <p>You should see a red dropdown menu with blue border next to "Borrowers Forms" in the sidebar.</p>
                    
                    <h4>❌ If Not Working:</h4>
                    <ul style="margin: 20px 0; padding-left: 20px;">
                        <li>Check if the CSS file is loading properly</li>
                        <li>Check browser console for errors</li>
                        <li>Try refreshing the page</li>
                        <li>Check if there are conflicting CSS rules</li>
                    </ul>
                    
                    <h4>🔧 Next Steps:</h4>
                    <p>If you can see the red dropdown, we know the HTML structure is correct and we just need to fix the CSS positioning.</p>
                </div>
            </div>
        </div>
    </main>
</section>

<script src="script.js"></script>
</body>
</html> 