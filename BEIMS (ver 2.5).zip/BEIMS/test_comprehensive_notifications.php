<?php
session_start();
include_once "dbconnect.php";
include_once "notification_system.php";

echo "<h2>🧪 Comprehensive Notification System Test</h2>";

// Check current session
echo "<h3>📋 Current Session:</h3>";
if (isset($_SESSION['user_id'])) {
    echo "<p style='color: green;'>✅ Logged in as User ID: " . $_SESSION['user_id'] . "</p>";
    echo "<p>Username: " . ($_SESSION['username'] ?? 'Not set') . "</p>";
    echo "<p>Account Type: " . ($_SESSION['acctype'] ?? 'Not set') . "</p>";
} else {
    echo "<p style='color: red;'>❌ Not logged in</p>";
    echo "<p><a href='login.php'>Login First</a></p>";
    exit();
}

$notificationSystem = getNotificationSystem();
$notificationEvents = getNotificationEvents();
$user_role = $notificationSystem->getUserRole();

echo "<h3>🎭 User Role: " . $user_role . "</h3>";

// Test all notification types
echo "<h3>🧪 Testing All Notification Types:</h3>";

$test_results = [];

// Test borrower notifications
if ($user_role === 'borrower' || $user_role === 'student' || $user_role === 'teacher') {
    echo "<h4>📝 Borrower Notifications:</h4>";
    
    // Test form submission
    $result = $notificationEvents->onFormSubmitted(999, $_SESSION['user_id'], "Test User", "Test Department");
    $test_results['form_submitted'] = $result;
    echo "<p>" . ($result ? "✅" : "❌") . " Form Submitted</p>";
    
    // Test form status changes
    $result = $notificationEvents->onFormStatusChanged(999, $_SESSION['user_id'], "Test User", "approved");
    $test_results['form_approved'] = $result;
    echo "<p>" . ($result ? "✅" : "❌") . " Form Approved</p>";
    
    $result = $notificationEvents->onFormStatusChanged(999, $_SESSION['user_id'], "Test User", "rejected");
    $test_results['form_rejected'] = $result;
    echo "<p>" . ($result ? "✅" : "❌") . " Form Rejected</p>";
    
    // Test due date notifications
    $result = $notificationEvents->onDueSoon($_SESSION['user_id'], "Test Item", "2024-01-15");
    $test_results['due_soon'] = $result;
    echo "<p>" . ($result ? "✅" : "❌") . " Due Soon</p>";
    
    $result = $notificationEvents->onOverdueItem($_SESSION['user_id'], "Test Item");
    $test_results['overdue_item'] = $result;
    echo "<p>" . ($result ? "✅" : "❌") . " Overdue Item</p>";
    
    // Test return confirmation
    $result = $notificationEvents->onReturnConfirmed($_SESSION['user_id'], "Test Item", "Admin User");
    $test_results['return_received'] = $result;
    echo "<p>" . ($result ? "✅" : "❌") . " Return Confirmed</p>";
    
    // Test item unavailable
    $result = $notificationEvents->onItemUnavailable($_SESSION['user_id'], "Test Item");
    $test_results['item_unavailable'] = $result;
    echo "<p>" . ($result ? "✅" : "❌") . " Item Unavailable</p>";
    
    // Test form failure
    $result = $notificationEvents->onFormFailed($_SESSION['user_id'], "Test failure reason");
    $test_results['form_failed'] = $result;
    echo "<p>" . ($result ? "✅" : "❌") . " Form Failed</p>";
}

// Test admin notifications
if ($user_role === 'admin' || $user_role === 'superadmin') {
    echo "<h4>👨‍💼 Admin Notifications:</h4>";
    
    // Test equipment management
    $result = $notificationEvents->onEquipmentAdded("Test Equipment", $_SESSION['user_id']);
    $test_results['equipment_added'] = $result;
    echo "<p>" . ($result ? "✅" : "❌") . " Equipment Added</p>";
    
    $result = $notificationEvents->onEquipmentEdited("Test Equipment", $_SESSION['user_id']);
    $test_results['equipment_edited'] = $result;
    echo "<p>" . ($result ? "✅" : "❌") . " Equipment Edited</p>";
    
    $result = $notificationEvents->onEquipmentDeleted("Test Equipment", $_SESSION['user_id']);
    $test_results['equipment_deleted'] = $result;
    echo "<p>" . ($result ? "✅" : "❌") . " Equipment Deleted</p>";
    
    // Test category management
    $result = $notificationEvents->onCategoryAdded("Test Category", $_SESSION['user_id']);
    $test_results['category_added'] = $result;
    echo "<p>" . ($result ? "✅" : "❌") . " Category Added</p>";
    
    $result = $notificationEvents->onCategoryEdited("Test Category", $_SESSION['user_id']);
    $test_results['category_edited'] = $result;
    echo "<p>" . ($result ? "✅" : "❌") . " Category Edited</p>";
    
    $result = $notificationEvents->onCategoryDeleted("Test Category", $_SESSION['user_id']);
    $test_results['category_deleted'] = $result;
    echo "<p>" . ($result ? "✅" : "❌") . " Category Deleted</p>";
    
    // Test account management
    $result = $notificationEvents->onAccountAdded("testuser", "student", $_SESSION['user_id']);
    $test_results['account_added'] = $result;
    echo "<p>" . ($result ? "✅" : "❌") . " Account Added</p>";
    
    $result = $notificationEvents->onAccountEdited("testuser", "student", $_SESSION['user_id']);
    $test_results['account_edited'] = $result;
    echo "<p>" . ($result ? "✅" : "❌") . " Account Edited</p>";
    
    $result = $notificationEvents->onAccountDeactivated("testuser", "student", $_SESSION['user_id']);
    $test_results['account_deactivated'] = $result;
    echo "<p>" . ($result ? "✅" : "❌") . " Account Deactivated</p>";
    
    $result = $notificationEvents->onAccountReactivated("testuser", "student", $_SESSION['user_id']);
    $test_results['account_reactivated'] = $result;
    echo "<p>" . ($result ? "✅" : "❌") . " Account Reactivated</p>";
    
    // Test inventory alerts
    $result = $notificationEvents->onItemRunningLow("Test Item", 3, 5);
    $test_results['item_running_low'] = $result;
    echo "<p>" . ($result ? "✅" : "❌") . " Item Running Low</p>";
}

// Check notification count
echo "<h3>📊 Notification Count:</h3>";
$count = getUnreadNotificationsCount($_SESSION['user_id'], $user_role);
echo "<p>Unread notifications for current user: <strong>" . $count . "</strong></p>";

// Show recent notifications
echo "<h3>📋 Recent Notifications for Current User:</h3>";
$notifications = getNotifications($_SESSION['user_id'], 10, 0, $user_role);

if (count($notifications) > 0) {
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>ID</th><th>User ID</th><th>Title</th><th>Type</th><th>Read</th><th>Created</th></tr>";
    foreach ($notifications as $notif) {
        $read_status = $notif['is_read'] ? '✅ Read' : '❌ Unread';
        $row_color = $notif['user_id'] == $_SESSION['user_id'] ? 'background-color: #e8f5e8;' : 'background-color: #ffe8e8;';
        echo "<tr style='$row_color'>";
        echo "<td>" . $notif['id'] . "</td>";
        echo "<td>" . $notif['user_id'] . "</td>";
        echo "<td>" . htmlspecialchars($notif['title']) . "</td>";
        echo "<td>" . $notif['type'] . "</td>";
        echo "<td>" . $read_status . "</td>";
        echo "<td>" . $notif['created_at'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No notifications found for current user.</p>";
}

// Show all notifications in database
echo "<h3>🗄️ All Notifications in Database:</h3>";
$sql = "SELECT * FROM notifications ORDER BY created_at DESC LIMIT 15";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>ID</th><th>User ID</th><th>Title</th><th>Type</th><th>Read</th><th>Created</th></tr>";
    while ($row = $result->fetch_assoc()) {
        $read_status = $row['is_read'] ? '✅ Read' : '❌ Unread';
        $row_color = $row['user_id'] == $_SESSION['user_id'] ? 'background-color: #e8f5e8;' : 'background-color: #ffe8e8;';
        echo "<tr style='$row_color'>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['user_id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['title']) . "</td>";
        echo "<td>" . $row['type'] . "</td>";
        echo "<td>" . $read_status . "</td>";
        echo "<td>" . $row['created_at'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No notifications found in database.</p>";
}

echo "<h3>🎯 Summary:</h3>";
echo "<p>✅ <strong>New Notification System:</strong> Modular, role-based notification system implemented</p>";
echo "<p>✅ <strong>Current User ID:</strong> " . $_SESSION['user_id'] . "</p>";
echo "<p>✅ <strong>User Role:</strong> " . $user_role . "</p>";
echo "<p>✅ <strong>Unread Count:</strong> " . $count . "</p>";
echo "<p>✅ <strong>Test Results:</strong> " . count(array_filter($test_results)) . "/" . count($test_results) . " successful</p>";

echo "<p><a href='dashboard_stutea.php'>Go to Dashboard</a> | <a href='borrowform_stutea.php'>Test Form Submission</a> | <a href='equiplist.php'>Test Equipment Management</a></p>";

$conn->close();
?> 