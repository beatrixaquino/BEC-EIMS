<?php
session_start();
include_once "dbconnect.php";

// Check if user is logged in and is superadmin
if (!isset($_SESSION['user_id']) || $_SESSION['acctype'] !== 'superadmin') {
    echo "<h2>❌ Access Denied</h2>";
    echo "<p>This page is only for superadmin users.</p>";
    echo "<p><a href='login.php'>Login as Superadmin</a></p>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="istyle.css">
    <title>JavaScript Dropdown Test</title>
    <style>
        /* Simple dropdown styles */
        .dropdown-menu {
            position: absolute;
            left: 100%;
            top: 0;
            background: white;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            min-width: 200px;
            display: none;
            z-index: 1000;
            padding: 8px 0;
        }
        
        .dropdown-menu.show {
            display: block;
        }
        
        .dropdown-menu li {
            list-style: none;
            margin: 0;
            padding: 0;
        }
        
        .dropdown-menu li a {
            display: block;
            padding: 8px 16px;
            color: #333;
            text-decoration: none;
            font-size: 14px;
        }
        
        .dropdown-menu li a:hover {
            background: #f0f0f0;
        }
        
        .dropdown-menu li a i {
            margin-right: 8px;
            width: 16px;
        }
        
        .dropdown {
            position: relative;
        }
        
        .dropdown-arrow {
            margin-left: 8px;
            transition: transform 0.3s ease;
        }
        
        .dropdown.active .dropdown-arrow {
            transform: rotate(180deg);
        }
    </style>
</head>
<body data-page="test">

<!-- SIDEBAR -->
<section id="sidebar">
    <a href="#" class="brand">
        <i class='bx bxs-package'></i>
        <span class="text">BEC EIMS</span>
    </a>
    <ul class="side-menu top">
        <li>
            <a href="dashboard_superadmin.php">
                <i class='bx bxs-dashboard'></i>
                <span class="text">Dashboard</span>
            </a>
        </li>
        <li>
            <a href="usermng.php">
                <i class='bx bx-group'></i>
                <span class="text">User Management</span>
            </a>
        </li>
        <li class="dropdown" id="borrowersDropdown">
            <a href="borrowform.php" class="dropdown-toggle">
                <i class='bx bxs-report'></i>
                <span class="text">Borrowers Forms</span>
                <i class='bx bx-chevron-down dropdown-arrow'></i>
            </a>
            <ul class="dropdown-menu" id="borrowersDropdownMenu">
                <li><a href="borrowform.php"><i class='bx bxs-report'></i> All Forms</a></li>
                <li><a href="manage_deleted_records.php"><i class='bx bxs-trash'></i> Deleted Records</a></li>
                <li><a href="borrowform.php?filter=pending"><i class='bx bxs-time'></i> Pending Forms</a></li>
                <li><a href="borrowform.php?filter=approved"><i class='bx bxs-check-circle'></i> Approved Forms</a></li>
                <li><a href="borrowform.php?filter=rejected"><i class='bx bxs-x-circle'></i> Rejected Forms</a></li>
                <li><a href="borrowform.php?filter=returned"><i class='bx bxs-archive'></i> Returned Forms</a></li>
            </ul>
        </li>
        <li>
            <a href="equiplist.php">
                <i class='bx bxs-wrench'></i>
                <span class="text">Equipment List</span>
            </a>
        </li>
    </ul>
    <ul class="side-menu">
        <li>
            <a href="login.php" class="logout">
                <i class='bx bxs-log-out'></i>
                <span class="text">Logout</span>
            </a>
        </li>
    </ul>
</section>

<!-- CONTENT -->
<section id="content">
    <nav>
        <i class='bx bx-menu'></i>
        <a href="#" class="nav-link">JS Dropdown Test</a>
        <form id="globalSearchForm" action="#" autocomplete="off">
            <div class="form-input">
                <input type="search" id="globalSearchInput" placeholder="Search...">
                <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
            </div>
        </form>
        <input type="checkbox" id="switch-mode" hidden>
        <label for="switch-mode" class="switch-mode"></label>
        <a href="#" class="notification" id="notificationIcon">
            <i class='bx bxs-bell'></i>
            <span class="num" id="notificationCount">0</span>
        </a>
        <div class="notification-dropdown" id="notificationDropdown" style="display: none;">
            <div class="notification-header">
                <h4>Notifications</h4>
                <button id="markAllRead" class="mark-all-read">Mark all read</button>
            </div>
            <div class="notification-list" id="notificationList">
                <!-- Notifications will be loaded here -->
            </div>
        </div>
        <a href="#" class="profile">
            <img src="img/people.png">
        </a>
    </nav>

    <main>
        <div class="head-title">
            <div class="left">
                <h1>JavaScript Dropdown Test</h1>
                <ul class="breadcrumb">
                    <li>
                        <a href="#">Test</a>
                    </li>
                    <li><i class='bx bx-chevron-right'></i></li>
                    <li>
                        <a class="active" href="#">JS Dropdown</a>
                    </li>
                </ul>
            </div>
        </div>

        <div class="table-data">
            <div class="order">
                <div class="head">
                    <h3>JavaScript Dropdown Test</h3>
                </div>
                
                <div style="padding: 20px;">
                    <h4>🧪 JavaScript Dropdown Test:</h4>
                    <ul style="margin: 20px 0; padding-left: 20px;">
                        <li>🎯 <strong>Click to toggle</strong> - Click on "Borrowers Forms" to show/hide dropdown</li>
                        <li>🔧 <strong>JavaScript controlled</strong> - Uses JavaScript instead of CSS hover</li>
                        <li>📱 <strong>Simple styling</strong> - Basic white background with border</li>
                        <li>⚡ <strong>Immediate feedback</strong> - Should work immediately</li>
                    </ul>
                    
                    <h4>✅ Test Instructions:</h4>
                    <ol style="margin: 20px 0; padding-left: 20px;">
                        <li>Click on "Borrowers Forms" in the sidebar</li>
                        <li>Watch the dropdown appear/disappear</li>
                        <li>Notice the arrow rotates</li>
                        <li>Click again to hide the dropdown</li>
                        <li>Click on any dropdown item to test navigation</li>
                    </ol>
                    
                    <h4>🔧 Debug Info:</h4>
                    <p>This version uses JavaScript instead of CSS hover, which should be more reliable.</p>
                </div>
            </div>
        </div>
    </main>
</section>

<script>
// JavaScript dropdown functionality
document.addEventListener('DOMContentLoaded', function() {
    const dropdown = document.getElementById('borrowersDropdown');
    const dropdownMenu = document.getElementById('borrowersDropdownMenu');
    
    if (dropdown && dropdownMenu) {
        dropdown.addEventListener('click', function(e) {
            e.preventDefault();
            dropdown.classList.toggle('active');
            dropdownMenu.classList.toggle('show');
        });
        
        // Close dropdown when clicking outside
        document.addEventListener('click', function(e) {
            if (!dropdown.contains(e.target)) {
                dropdown.classList.remove('active');
                dropdownMenu.classList.remove('show');
            }
        });
    }
});
</script>

<script src="script.js"></script>
</body>
</html> 