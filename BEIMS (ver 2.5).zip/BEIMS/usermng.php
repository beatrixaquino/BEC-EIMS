<?php
// Start session to store messages
session_start();

// Include the database connection file
include_once "dbconnect.php";

// Handle account status toggle if the toggle parameter is set
if (isset($_GET['toggle']) && isset($_GET['id'])) {
    $idToToggle = intval($_GET['id']);
    $action = $_GET['toggle'];
    
    if (in_array($action, ['deactivate', 'reactivate'])) {
        $new_status = ($action === 'deactivate') ? 'inactive' : 'active';
        
        $sql = "UPDATE users SET status = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $new_status, $idToToggle);
        $stmt->execute();
        
        $_SESSION['message'] = "User account " . $action . "d successfully.";
    }
    
    // Redirect back to the main page
    header("Location: usermng.php");
    exit();
}

// Insert or Update admin account into the database
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = isset($_POST['id']) && is_numeric($_POST['id']) && intval($_POST['id']) > 0 ? intval($_POST['id']) : null;
    $username = $_POST['username'];
    $password = $_POST['password'];
    $acctype = $_POST['acctype'];

    if ($id) {
        // Update an existing admin account
        $sql = "UPDATE users SET username=?, password=?, acctype=? WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssi", $username, $password, $acctype, $id);
        $_SESSION['message'] = "Admin account updated successfully.";
    } else {
        // Insert a new admin account
        $sql = "INSERT INTO users (username, password, acctype, created_at) VALUES (?, ?, ?, NOW())";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $username, $password, $acctype);
        $_SESSION['message'] = "New admin account created successfully.";
    }
    $stmt->execute();

    header("Location: usermng.php");
    exit();
}

// Fetch all user accounts (including status)
$sql = "SELECT * FROM users ORDER BY created_at DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Boxicons -->
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <!-- My CSS -->
    <link rel="stylesheet" href="istyle.css">
    <title>UserHub</title>
</head>
<body data-page="usermng">
    <!-- SIDEBAR -->
    <section id="sidebar">
        <a href="#" class="brand">
        <i class='bx bxs-package'></i>
            <span class="text">BEC EIMS</span>
        </a>
        <ul class="side-menu top">
            <li class="active">
                <a href="dashboard_superadmin.php">
                    <i class='bx bxs-dashboard'></i>
                    <span class="text">Dashboard</span>
                </a>
            </li>
            <li>
                <a href="usermng.php">
                    <i class='bx bx-group'></i>
                    <span class="text">User Management</span>
                </a>
            </li>
            <li class="dropdown" id="borrowersDropdown">
                <a href="borrowform.php" class="dropdown-toggle">
                    <i class='bx bx-clipboard'></i>
                    <span class="text">Borrowers Forms</span>
                    <i class='bx bx-chevron-down dropdown-arrow'></i>
                </a>
                <ul class="dropdown-menu" id="borrowersDropdownMenu">
                    <li><a href="borrowform.php"><i class='bx bxs-report'></i> All Forms</a></li>
                    <li><a href="manage_deleted_records.php"><i class='bx bxs-trash'></i> Deleted Records</a></li>
                    <li><a href="borrowform.php?filter=pending"><i class='bx bxs-time'></i> Pending Forms</a></li>
                    <li><a href="borrowform.php?filter=approved"><i class='bx bxs-check-circle'></i> Approved Forms</a></li>
                    <li><a href="borrowform.php?filter=rejected"><i class='bx bxs-x-circle'></i> Rejected Forms</a></li>
                    <li><a href="borrowform.php?filter=returned"><i class='bx bxs-archive'></i> Returned Forms</a></li>
                </ul>
            </li>
            <li>
                <a href="equiplist.php">
                    <i class='bx bxs-wrench' ></i>
                    <span class="text">Equipment List</span>
                </a>
            </li>
        </ul>
        <ul class="side-menu">
            <li>
                <a href="login.php" class="logout">
                    <i class='bx bxs-log-out'></i>
                    <span class="text">Logout</span>
                </a>
            </li>
        </ul>
    </section>
    <!-- SIDEBAR -->

    <!-- CONTENT -->
    <section id="content">
        <!-- NAVBAR -->
        <nav>
            <i class='bx bx-menu'></i>
            <a href="#" class="nav-link">Categories</a>
            <form id="globalSearchForm" action="#" autocomplete="off">
                <div class="form-input">
                    <input type="search" id="globalSearchInput" placeholder="Search...">
                    <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
                </div>
            </form>
            <input type="checkbox" id="switch-mode" hidden>
            <label for="switch-mode" class="switch-mode"></label>
            <a href="#" class="notification" id="notificationIcon">
                <i class='bx bxs-bell'></i>
                <span class="num" id="notificationCount">0</span>
            </a>
            <div class="notification-dropdown" id="notificationDropdown" style="display: none;">
                <div class="notification-header">
                    <h4>Notifications</h4>
                    <button id="markAllRead" class="mark-all-read">Mark all read</button>
                </div>
                <div class="notification-list" id="notificationList">
                    <!-- Notifications will be loaded here -->
                </div>
            </div>
            <a href="#" class="profile">
                <img src="img/people.png">
            </a>
        </nav>
        <!-- NAVBAR -->

        <!-- MAIN -->
        <main>
            <div class="head-title">
                <div class="left">
                    <h1>User Management</h1>
                    <ul class="breadcrumb">
                        <li><a href="#">User Management</a></li>
                        <li><i class='bx bx-chevron-right'></i></li>
                        <li><a class="active" href="#">Home</a></li>
                    </ul>
                </div>
            </div>

            <!-- Admin account table and form -->
            <div class="table-data">
                <div class="order">
                    <div class="head">
                        <h3>User Accounts</h3>
                        <i class='bx bx-filter' id="accountFilterBtn"></i>
                    </div>

                    <div class="filter-group hide" id="accountFilterGroup">
                        <button class="filter-option" data-type="all">All</button>
                        <button class="filter-option" data-type="superadmin">Superadmin</button>
                        <button class="filter-option" data-type="admin">Admin</button>
                        <button class="filter-option" data-type="teacher">Teacher</button>
                        <button class="filter-option" data-type="student">Student</button>
                    </div>

                    <!-- Table code -->
                    <table>
                        <thead>
                            <tr>
                                <th>Account Username</th>
                                <th>Account Type</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = $result->fetch_assoc()): ?>
                            <tr class="user-row" data-type="<?php echo htmlspecialchars($row['acctype']); ?>" data-status="<?php echo htmlspecialchars($row['status']); ?>">
                                <td>
                                    <p><?php echo $row['username']; ?></p>
                                </td>
                                <td><?php echo $row['acctype']; ?></td>
                                <td>
                                    <span class="status-badge status-<?php echo $row['status']; ?>">
                                        <?php echo ucfirst($row['status']); ?>
                                    </span>
                                </td>
                                <td>
                                <div class="admin-table">
                                <button 
                                    type="button"
                                    class="btn-edit admin-action-btn" 
                                    data-id="<?php echo $row['id']; ?>"
                                    data-username="<?php echo $row['username']; ?>" 
                                    data-password="<?php echo $row['password']; ?>" 
                                    data-acctype="<?php echo $row['acctype']; ?>">
                                    Edit
                                </button>
                                <?php if ($row['status'] === 'active'): ?>
                                    <button 
                                        type="button"
                                        class="btn-deactivate admin-action-btn" 
                                        data-id="<?php echo $row['id']; ?>"
                                        onclick="toggleUserStatus(<?php echo $row['id']; ?>, 'deactivate')">
                                        Deactivate
                                    </button>
                                <?php else: ?>
                                    <button 
                                        type="button"
                                        class="btn-reactivate admin-action-btn" 
                                        data-id="<?php echo $row['id']; ?>"
                                        onclick="toggleUserStatus(<?php echo $row['id']; ?>, 'reactivate')">
                                        Reactivate
                                    </button>
                                <?php endif; ?>
                                </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Form for adding/editing admin accounts -->
                <div class="todo">
                    <div class="head">
                        <h3>User Account Form</h3>
                    </div>
                    <form action="usermng.php" method="POST">
                        <input type="hidden" id="admin-id" name="id">
                        
                        <div class="form-group">
                            <label for="username">Username</label>
                            <div class="input-group">
                                <input type="text" id="username" name="username" placeholder="Username" required>
                                <i class='bx bx-user'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="password">Password</label>
                            <div class="input-group">
                                <input type="text" id="password" name="password" placeholder="Your password" required>
                                <i class='bx bx-lock-alt'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="acctype">Account Type</label>
                            <div class="input-group">
                                <select id="acctype" name="acctype" required>
                                    <option value="" disabled selected>Select Account Type</option>
                                    <option value="superadmin">superadmin</option>
                                    <option value="admin">admin</option>
                                    <option value="teacher">teacher</option>
                                    <option value="student">student</option>
                                </select>
                                <i class='bx bx-chevron-down'></i>
                            </div>
                        </div>

                        <button type="submit" class="btn-submit">Submit</button>
                        <button type="button" class="btn-submit btn-cancel" onclick="clearForm()">Cancel</button>
                    </form>
                    

                </div>
            </div>
        </main>
        <!-- MAIN -->
    </section>
    <!-- CONTENT -->

    <script src="script.js"></script>

    <script>
    // Display alert if there is a session message
    window.onload = function() {
        <?php if (isset($_SESSION['message'])): ?>
            alert("<?php echo $_SESSION['message']; ?>");
            <?php unset($_SESSION['message']); ?> // Clear message after displaying
        <?php endif; ?>
    };

    function clearForm() {
    document.getElementById('admin-id').value = '';
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';
    document.getElementById('acctype').selectedIndex = 0;
    
    // Reset submit button text
    const submitButton = document.querySelector('.btn-submit');
    submitButton.textContent = 'Submit';
}

// Add event listeners for edit buttons
document.addEventListener('DOMContentLoaded', function() {
    const editButtons = document.querySelectorAll('.btn-edit');
    
    editButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Get data from the button's data attributes
            const id = this.getAttribute('data-id');
            const username = this.getAttribute('data-username');
            const password = this.getAttribute('data-password');
            const acctype = this.getAttribute('data-acctype');
            
            // Populate the form fields
            document.getElementById('admin-id').value = id;
            document.getElementById('username').value = username;
            document.getElementById('password').value = password;
            
            // Set the account type dropdown
            const acctypeSelect = document.getElementById('acctype');
            for (let i = 0; i < acctypeSelect.options.length; i++) {
                if (acctypeSelect.options[i].value === acctype) {
                    acctypeSelect.selectedIndex = i;
                    break;
                }
            }
            
            // Change submit button text to indicate editing
            const submitButton = document.querySelector('.btn-submit');
            submitButton.textContent = 'Update Account';
        });
    });
});

function toggleUserStatus(userId, action) {
    const confirmMessage = action === 'deactivate' 
        ? 'Are you sure you want to deactivate this user?' 
        : 'Are you sure you want to reactivate this user?';
    
    if (confirm(confirmMessage)) {
        const formData = new FormData();
        formData.append('user_id', userId);
        formData.append('action', action);
        
        fetch('toggle_user_status.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert(data.message);
                location.reload(); // Refresh the page to show updated status
            } else {
                alert('Error: ' + data.error);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while updating user status');
        });
    }
}

const accountFilterOptions = document.querySelectorAll("#accountFilterGroup .filter-option");
const userCards = document.querySelectorAll(".user-row"); // or ".user-row" for table

accountFilterOptions.forEach(btn => {
    btn.addEventListener("click", function() {
        // Remove active class from all
        accountFilterOptions.forEach(b => b.classList.remove("active"));
        this.classList.add("active");

        const type = this.getAttribute("data-type");
        userCards.forEach(card => {
            if (type === "all" || card.getAttribute("data-type") === type) {
                card.style.display = "";
            } else {
                card.style.display = "none";
            }
        });
    });
});

const accountFilterBtn = document.getElementById("accountFilterBtn");
const accountFilterGroup = document.getElementById("accountFilterGroup");

accountFilterBtn.addEventListener("click", function(e) {
    e.stopPropagation();
    accountFilterGroup.classList.toggle("hide");
});

// Hide filter group when clicking outside
document.addEventListener("click", function(e) {
    if (!accountFilterGroup.contains(e.target) && e.target !== accountFilterBtn) {
        accountFilterGroup.classList.add("hide");
    }
});

// Universal search for user rows
const globalSearchForm = document.getElementById("globalSearchForm");
const globalSearchInput = document.getElementById("globalSearchInput");

if (globalSearchForm && globalSearchInput) {
    globalSearchForm.addEventListener("submit", function(e) {
        e.preventDefault();
        const query = globalSearchInput.value.trim().toLowerCase();
        const userRows = document.querySelectorAll(".user-row");
        if (userRows.length > 0) {
            userRows.forEach(row => {
                // Search in all table cells for this row
                const rowText = row.textContent.toLowerCase();
                if (rowText.includes(query)) {
                    row.style.display = "";
                } else {
                    row.style.display = "none";
                }
            });
        }
    });

    // Optional: Live search as you type
    globalSearchInput.addEventListener("input", function() {
        const query = globalSearchInput.value.trim().toLowerCase();
        const userRows = document.querySelectorAll(".user-row");
        if (userRows.length > 0) {
            userRows.forEach(row => {
                const rowText = row.textContent.toLowerCase();
                if (rowText.includes(query)) {
                    row.style.display = "";
                } else {
                    row.style.display = "none";
                }
            });
        }
    });
}

document.addEventListener("DOMContentLoaded", () => {
    // Notification functionality
    const notificationIcon = document.getElementById('notificationIcon');
    const notificationDropdown = document.getElementById('notificationDropdown');
    const notificationCount = document.getElementById('notificationCount');
    const notificationList = document.getElementById('notificationList');
    const markAllReadBtn = document.getElementById('markAllRead');

    // Load notification count
    function loadNotificationCount() {
        fetch('get_notifications.php?action=count')
            .then(response => response.json())
            .then(data => {
                if (data.count > 0) {
                    notificationCount.textContent = data.count;
                    notificationCount.style.display = 'block';
                } else {
                    notificationCount.style.display = 'none';
                }
            })
            .catch(error => console.error('Error loading notification count:', error));
    }

    // Load notifications
    function loadNotifications() {
        fetch('get_notifications.php?action=list&limit=10')
            .then(response => response.json())
            .then(data => {
                if (data.notifications && data.notifications.length > 0) {
                    let html = '';
                    data.notifications.forEach(notification => {
                        const isRead = notification.is_read ? 'read' : 'unread';
                        const timeAgo = getTimeAgo(notification.created_at);
                        html += `
                            <div class="notification-item ${isRead}" data-id="${notification.id}">
                                <div class="notification-content">
                                    <h5>${notification.title}</h5>
                                    <p>${notification.message}</p>
                                    <small>${timeAgo}</small>
                                </div>
                                ${!notification.is_read ? '<div class="unread-indicator"></div>' : ''}
                            </div>
                        `;
                    });
                    notificationList.innerHTML = html;
                } else {
                    notificationList.innerHTML = '<div class="no-notifications">No notifications</div>';
                }
            })
            .catch(error => console.error('Error loading notifications:', error));
    }

    // Get time ago
    function getTimeAgo(timestamp) {
        const now = new Date();
        const created = new Date(timestamp);
        const diffInSeconds = Math.floor((now - created) / 1000);
        
        if (diffInSeconds < 60) return 'Just now';
        if (diffInSeconds < 3600) return Math.floor(diffInSeconds / 60) + 'm ago';
        if (diffInSeconds < 86400) return Math.floor(diffInSeconds / 3600) + 'h ago';
        return Math.floor(diffInSeconds / 86400) + 'd ago';
    }

    // Toggle notification dropdown
    notificationIcon.addEventListener('click', function(e) {
        e.preventDefault();
        notificationDropdown.style.display = notificationDropdown.style.display === 'none' ? 'block' : 'none';
        if (notificationDropdown.style.display === 'block') {
            loadNotifications();
        }
    });

    // Mark all as read
    markAllReadBtn.addEventListener('click', function() {
        fetch('get_notifications.php?action=mark_all_read', {
            method: 'POST'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                loadNotificationCount();
                loadNotifications();
            }
        })
        .catch(error => console.error('Error marking all as read:', error));
    });

    // Mark individual notification as read
    notificationList.addEventListener('click', function(e) {
        const notificationItem = e.target.closest('.notification-item');
        if (notificationItem && !notificationItem.classList.contains('read')) {
            const notificationId = notificationItem.getAttribute('data-id');
            fetch('get_notifications.php?action=mark_read', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'notification_id=' + notificationId
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    notificationItem.classList.remove('unread');
                    notificationItem.classList.add('read');
                    notificationItem.querySelector('.unread-indicator')?.remove();
                    loadNotificationCount();
                }
            })
            .catch(error => console.error('Error marking notification as read:', error));
        }
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
        if (!notificationIcon.contains(e.target) && !notificationDropdown.contains(e.target)) {
            notificationDropdown.style.display = 'none';
        }
    });

    // Load notification count on page load
    loadNotificationCount();

    // Refresh notification count every 30 seconds
    setInterval(loadNotificationCount, 30000);
});
</script>
</body>
</html>
