<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Dropdown Test</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="istyle.css">
</head>
<body>
    <!-- SIDEBAR -->
    <section id="sidebar">
        <a href="#" class="brand">
            <i class='bx bxs-package' ></i>
            <span class="text">BEC EIMS</span>
        </a>
        <ul class="side-menu top">
            <li class="active">
                <a href="dashboard_superadmin.php">
                    <i class='bx bxs-dashboard' ></i>
                    <span class="text">Dashboard</span>
                </a>
            </li>
            <li>
                <a href="usermng.php">
                    <i class='bx bx-group' ></i>
                    <span class="text">User Management</span>
                </a>
            </li>
            <li class="dropdown" id="borrowersDropdown">
                <a href="borrowform.php" class="dropdown-toggle">
                    <i class='bx bx-clipboard'></i>
                    <span class="text">Borrowers Forms</span>
                    <i class='bx bx-chevron-down dropdown-arrow'></i>
                </a>
                <ul class="dropdown-menu" id="borrowersDropdownMenu">
                    <li><a href="borrowform.php"><i class='bx bxs-report'></i> All Forms</a></li>
                    <li><a href="manage_deleted_records.php"><i class='bx bxs-trash'></i> Deleted Records</a></li>
                    <li><a href="borrowform.php?filter=pending"><i class='bx bxs-time'></i> Pending Forms</a></li>
                    <li><a href="borrowform.php?filter=approved"><i class='bx bxs-check-circle'></i> Approved Forms</a></li>
                    <li><a href="borrowform.php?filter=rejected"><i class='bx bxs-x-circle'></i> Rejected Forms</a></li>
                    <li><a href="borrowform.php?filter=returned"><i class='bx bxs-archive'></i> Returned Forms</a></li>
                </ul>
            </li>
            <li>
                <a href="equiplist.php">
                    <i class='bx bxs-wrench' ></i>
                    <span class="text">Equipment List</span>
                </a>
            </li>
        </ul>
        <ul class="side-menu">
            <li>
                <a href="login.php" class="logout">
                    <i class='bx bxs-log-out' ></i>
                    <span class="text">Logout</span>
                </a>
            </li>
        </ul>
    </section>
    <!-- SIDEBAR -->

    <!-- CONTENT -->
    <section id="content">
        <!-- NAVBAR -->
        <nav>
            <i class='bx bx-menu' ></i>
            <a href="#" class="nav-link">Categories</a>
            <form action="#">
                <div class="form-input">
                    <input type="search" placeholder="Search...">
                    <button type="submit" class="search-btn"><i class='bx bx-search' ></i></button>
                </div>
            </form>
            <input type="checkbox" id="switch-mode" hidden>
            <label for="switch-mode" class="switch-mode"></label>
            <a href="#" class="notification">
                <i class='bx bxs-bell' ></i>
                <span class="num">0</span>
            </a>
            <a href="#" class="profile">
                <img src="img/people.png">
            </a>
        </nav>
        <!-- NAVBAR -->

        <!-- MAIN -->
        <main>
            <div class="head-title">
                <div class="left">
                    <h1>Dashboard Dropdown Test</h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="#">Dashboard</a>
                        </li>
                        <li><i class='bx bx-chevron-right' ></i></li>
                        <li>
                            <a class="active" href="#">Test</a>
                        </li>
                    </ul>
                </div>
            </div>

            <div style="margin-top: 20px; padding: 20px; background: #f8f9fa; border-radius: 8px;">
                <h3>Test Instructions:</h3>
                <ol>
                    <li><strong>Click "Borrowers Forms" text</strong> → Should navigate to borrowform.php</li>
                    <li><strong>Click the dropdown arrow (▼)</strong> → Should show dropdown menu below and push Equipment List down</li>
                    <li><strong>Click dropdown items</strong> → Should navigate to respective pages</li>
                    <li><strong>Click arrow again</strong> → Should hide dropdown and Equipment List moves back up</li>
                </ol>
            </div>
            
            <div style="margin-top: 20px; padding: 20px; background: #e9ecef; border-radius: 8px;">
                <h3>Expected Behavior:</h3>
                <ul>
                    <li>✅ Dropdown appears <strong>below</strong> Borrowers Forms</li>
                    <li>✅ Equipment List gets pushed <strong>down</strong></li>
                    <li>✅ Smooth animation when opening/closing</li>
                    <li>✅ Link text still works for navigation</li>
                </ul>
            </div>
        </main>
        <!-- MAIN -->
    </section>
    <!-- CONTENT -->

    <script src="script.js"></script>
</body>
</html> 