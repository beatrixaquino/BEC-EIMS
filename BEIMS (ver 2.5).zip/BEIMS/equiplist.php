<?php
session_start();
ob_start();
include_once "dbconnect.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = isset($_POST['id']) && !empty($_POST['id']) ? intval($_POST['id']) : null;

    $itemname = $_POST['itemname'];
    $specification = $_POST['specification'];
    $quantityreq = intval($_POST['quantityreq']);
    $unit_req = isset($_POST['unit_req']) && trim($_POST['unit_req']) !== '' ? $_POST['unit_req'] : 'pcs';
    $quantityon = isset($_POST['quantityon']) && $_POST['quantityon'] !== '' ? intval($_POST['quantityon']) : 0;
    $unit_on = isset($_POST['unit_on']) && trim($_POST['unit_on']) !== '' ? $_POST['unit_on'] : 'pcs';

    $difference = !empty($_POST['difference']) ? $_POST['difference'] : null;
    $remarks = !empty($_POST['remarks']) ? $_POST['remarks'] : null;
    $itemdescription = !empty($_POST['itemdescription']) ? $_POST['itemdescription'] : null;

    $complianceauditone = isset($_POST['complianceauditone']) && $_POST['complianceauditone'] !== '' ? intval($_POST['complianceauditone']) : null;
    $unit1 = isset($_POST['unit1']) && trim($_POST['unit1']) !== '' ? $_POST['unit1'] : 'pcs';
    $valid_units = ['pcs', 'sets', 'units', 'box', 'others'];
    if (!in_array($unit1, $valid_units)) {
        $unit1 = 'pcs';
    }

    $complianceaudittwo = isset($_POST['complianceaudittwo']) && $_POST['complianceaudittwo'] !== '' ? intval($_POST['complianceaudittwo']) : null;
    $unit2 = isset($_POST['unit2']) && trim($_POST['unit2']) !== '' ? $_POST['unit2'] : 'pcs';
    if (!in_array($unit2, $valid_units)) {
        $unit2 = 'pcs';
    }

    // File upload
    $eqpphoto = null;
    if (isset($_FILES['eqpphoto']) && $_FILES['eqpphoto']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = 'uploads/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        $fileName = time() . "_" . basename($_FILES['eqpphoto']['name']);
        $targetFilePath = $uploadDir . $fileName;

        if (move_uploaded_file($_FILES['eqpphoto']['tmp_name'], $targetFilePath)) {
            $eqpphoto = $fileName;
        }
    }

    // UPDATE
    if ($id) {
        $sql = "UPDATE item_list SET 
            itemname=?, specification=?, quantityreq=?, unit_req=?, quantityon=?, unit_on=?, 
            difference=?, remarks=?, itemdescription=?, complianceauditone=?, unit1=?, complianceaudittwo=?, unit2=?";

        if ($eqpphoto) {
            $sql .= ", eqpphoto=?";
        }

        $sql .= " WHERE id=?";

        $stmt = $conn->prepare($sql);

        if (!$stmt) {
            $_SESSION['message'] = "Prepare failed: " . $conn->error;
            header("Location: equiplist.php");
            exit();
        }

        if ($eqpphoto) {
            $stmt->bind_param(
                "ssisssssssssis",
                $itemname,        // s
                $specification,   // s
                $quantityreq,     // i
                $unit_req,        // s
                $quantityon,      // i
                $unit_on,         // s
                $difference,      // s
                $remarks,         // s
                $itemdescription, // s
                $complianceauditone, // i
                $unit1,           // s
                $complianceaudittwo, // i
                $unit2,           // s
                $eqpphoto,        // s
                $id               // i
            );
        } else {
            $stmt->bind_param(
                "ssissssssssssi",
                $itemname,
                $specification,
                $quantityreq,
                $unit_req,
                $quantityon,
                $unit_on,         // s
                $difference,
                $remarks,
                $itemdescription,
                $complianceauditone,
                $unit1,
                $complianceaudittwo,
                $unit2,           // s
                $id
            );
        }

        // Execute the main update FIRST
        if ($stmt->execute()) {
            // THEN handle categories
            if (isset($_POST['itemcategory']) && is_array($_POST['itemcategory'])) {
                $item_id = $id;
                $conn->query("DELETE FROM item_categories WHERE item_id = $item_id");
                $cat_stmt = $conn->prepare("INSERT INTO item_categories (item_id, category_id) VALUES (?, ?)");
                foreach ($_POST['itemcategory'] as $cat_id) {
                    $cat_stmt->bind_param("ii", $item_id, $cat_id);
                    $cat_stmt->execute();
                }
                $cat_stmt->close();
            }
            
            $_SESSION['message'] = "Item updated successfully!";
        } else {
            $_SESSION['message'] = "Database operation failed: " . $stmt->error;
        }
        
        $stmt->close();
        header("Location: equiplist.php");
        exit();
    }


    // INSERT
    else {
        $sql = "INSERT INTO item_list (
        itemname, specification, quantityreq, unit_req, quantityon, unit_on, 
        difference, remarks, itemdescription, complianceauditone, unit1, complianceaudittwo, unit2, eqpphoto
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);

        if (!$stmt) {
            file_put_contents("debug_log.txt", "ERROR: Prepare failed - " . $conn->error . "\n", FILE_APPEND);
            $_SESSION['message'] = "Prepare failed: " . $conn->error;
            header("Location: equiplist.php");
            exit();
        }

        $stmt->bind_param(
            "ssisssssssssss",
            $itemname,
            $specification,
            $quantityreq,
            $unit_req,
            $quantityon,
            $unit_on,         // s
            $difference,
            $remarks,
            $itemdescription,
            $complianceauditone,
            $unit1,
            $complianceaudittwo,
            $unit2,           // s
            $eqpphoto
        );

        if ($stmt->execute()) {
            file_put_contents("debug_log.txt", "Data inserted/updated successfully\n", FILE_APPEND);
            $_SESSION['message'] = $id ? "Item updated successfully!" : "Item added successfully!";
            
            // Get the insert ID immediately after successful insert
            $item_id = $conn->insert_id;
            
            // Create notification for new equipment
            if (!$id) { // Only for new items, not updates
                include_once "notification_system.php";
                $notificationEvents = getNotificationEvents();
                $notificationEvents->onEquipmentAdded($itemname, $_SESSION['user_id'] ?? 1);
            }
            
            // Insert into item_categories for insert (AFTER main insert is successful)
            if (isset($_POST['itemcategory']) && is_array($_POST['itemcategory']) && $item_id) {
                file_put_contents("debug_log.txt", "Inserting categories for item_id: $item_id\n", FILE_APPEND);
                $cat_stmt = $conn->prepare("INSERT INTO item_categories (item_id, category_id) VALUES (?, ?)");
                if ($cat_stmt) {
                    foreach ($_POST['itemcategory'] as $cat_id) {
                        file_put_contents("debug_log.txt", "Inserting category_id: $cat_id for item_id: $item_id\n", FILE_APPEND);
                        $cat_stmt->bind_param("ii", $item_id, $cat_id);
                        if (!$cat_stmt->execute()) {
                            file_put_contents("debug_log.txt", "ERROR inserting category: " . $cat_stmt->error . "\n", FILE_APPEND);
                        }
                    }
                    $cat_stmt->close();
                } else {
                    file_put_contents("debug_log.txt", "ERROR preparing category statement: " . $conn->error . "\n", FILE_APPEND);
                }
            } else {
                file_put_contents("debug_log.txt", "No categories to insert or no item_id. item_id: $item_id\n", FILE_APPEND);
            }
        } else {
            file_put_contents("debug_log.txt", "ERROR: " . $stmt->error . "\n", FILE_APPEND);
            $_SESSION['message'] = "Database operation failed: " . $stmt->error;
        }
        
        $stmt->close();
        header("Location: equiplist.php");
        exit();
    }
}

// DELETE item
if (isset($_GET['delete'])) {
    $deleteId = intval($_GET['delete']);
    $delQuery = "DELETE FROM item_list WHERE id=?";
    $stmt = $conn->prepare($delQuery);
    $stmt->bind_param("i", $deleteId);
    $stmt->execute();
    $stmt->close();
    $_SESSION['message'] = "Item deleted successfully.";
    header("Location: equiplist.php");
    exit();
}

// Fetch items
$sql = "SELECT * FROM item_list ORDER BY created_at DESC";
$result = $conn->query($sql);

ob_end_flush();
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="istyle.css">
    <title>AdminHub</title>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
</head>

<body data-page="equiplist">

    <!-- SIDEBAR -->
    <section id="sidebar">
        <a href="#" class="brand">
            <i class='bx bxs-package'></i>
            <span class="text">BEC EIMS</span>
        </a>
        <ul class="side-menu top">
            <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'dashboard_superadmin.php' ? 'active' : ''; ?>">
                <a href="dashboard_superadmin.php">
                    <i class='bx bxs-dashboard'></i>
                    <span class="text">Dashboard</span>
                </a>
            </li>
            <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'usermng.php' ? 'active' : ''; ?>">
                <a href="usermng.php">
                    <i class='bx bx-group'></i>
                    <span class="text">User Management</span>
                </a>
            </li>
            			<li class="dropdown <?php echo basename($_SERVER['PHP_SELF']) == 'borrowform.php' ? 'active' : ''; ?>" id="borrowersDropdown">
				<a href="borrowform.php" class="dropdown-toggle">
					<i class='bx bx-clipboard'></i>
					<span class="text">Borrowers Forms</span>
					<i class='bx bx-chevron-down dropdown-arrow'></i>
				</a>
				<ul class="dropdown-menu" id="borrowersDropdownMenu">
					<li><a href="borrowform.php"><i class='bx bxs-report'></i> All Forms</a></li>
					<li><a href="manage_deleted_records.php"><i class='bx bxs-trash'></i> Deleted Records</a></li>
					<li><a href="borrowform.php?filter=pending"><i class='bx bxs-time'></i> Pending Forms</a></li>
					<li><a href="borrowform.php?filter=approved"><i class='bx bxs-check-circle'></i> Approved Forms</a></li>
					<li><a href="borrowform.php?filter=rejected"><i class='bx bxs-x-circle'></i> Rejected Forms</a></li>
					<li><a href="borrowform.php?filter=returned"><i class='bx bxs-archive'></i> Returned Forms</a></li>
				</ul>
			</li>
            <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'equiplist.php' ? 'active' : ''; ?>">
                <a href="equiplist.php">
                <i class='bx bxs-wrench' ></i>
                    <span class="text">Equipment List</span>
                </a>
            </li>
        </ul>
        <ul class="side-menu">
            <li>
                <a href="login.php" class="logout">
                    <i class='bx bxs-log-out'></i>
                    <span class="text">Logout</span>
                </a>
            </li>
        </ul>
    </section>
    <!-- SIDEBAR -->


    <!-- CONTENT -->
    <section id="content">
        <nav>
            <i class='bx bx-menu'></i>
            <a href="#" class="nav-link" id="categoriesNavLink">Categories</a>
            <form id="globalSearchForm" action="#" autocomplete="off">
                <div class="form-input">
                    <input type="search" id="globalSearchInput" placeholder="Search...">
                    <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
                </div>
            </form>
            <input type="checkbox" id="switch-mode" hidden>
            <label for="switch-mode" class="switch-mode"></label>
            <a href="#" class="notification" id="notificationIcon">
                <i class='bx bxs-bell'></i>
                <span class="num" id="notificationCount">0</span>
            </a>
            <div class="notification-dropdown" id="notificationDropdown" style="display: none;">
                <div class="notification-header">
                    <h4>Notifications</h4>
                    <button id="markAllRead" class="mark-all-read">Mark all read</button>
                </div>
                <div class="notification-list" id="notificationList">
                    <!-- Notifications will be loaded here -->
                </div>
            </div>
            <a href="#" class="profile">
                <img src="img/people.png">
            </a>
        </nav>

        <main>
            <div class="head-title">
                <div class="left">
                    <h1>Equipment List</h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="">Equipment List</a>
                        </li>
                        <li><i class='bx bx-chevron-right'></i></li>
                        <li>
                            <a class="active" href="+">Form</a>
                        </li>
                    </ul>
                </div>
                <a href="#" class="btn-download" onclick="">
                    <i class='bx bxs-report'></i>
                    <span class="text">Generate Report</span>
                </a>
            </div>

            <div class="table-data">
                <div class="order">
                    <div class="head">
                        <h3>List of Equipment</h3>
                        <i class='bx bx-filter' id="filterBtn"></i>
                        <i class='bx bx-folder-plus' id="addCategoryBtn" style="cursor:pointer;"></i>
                        <!-- Place filter buttons here -->
                    </div>

                    <div class="filter-group" id="filterGroup">
                        <button class="filter-option" data-category="all">All</button>
                        <?php
                        $catResult = $conn->query("SELECT name FROM categories ORDER BY name ASC");
                        while ($catRow = $catResult->fetch_assoc()) {
                            $catName = $catRow['name'];
                            echo '<button class="filter-option" data-category="' . htmlspecialchars($catName) . '">' . htmlspecialchars(ucfirst($catName)) . '</button>';
                        }
                        ?>
                    </div>

                    <div class="equipment-grid">
                        <?php if ($result->num_rows > 0): ?>
                            <?php while ($row = $result->fetch_assoc()): ?>
                                <?php
                                $item_id = $row['id'];
                                $catNames = [];
                                $catRes = $conn->query("SELECT c.name FROM item_categories ic JOIN categories c ON ic.category_id = c.id WHERE ic.item_id = $item_id");
                                while ($catRow = $catRes->fetch_assoc()) {
                                    $catNames[] = $catRow['name'];
                                }
                                $dataCategory = htmlspecialchars(implode(',', $catNames));
                                ?>
                                <div class="equipment-card" data-category="<?php echo $dataCategory; ?>">
                                    <img src="uploads/<?php echo htmlspecialchars($row['eqpphoto'] ?? 'placeholder.png'); ?>" alt="Equipment Image" class="equipment-img">
                                    <h4><?php echo htmlspecialchars($row['itemname']); ?></h4>
                                    <p><strong>Category:</strong> <?php 
                                    $item_id = $row['id'];
                                    $catNames = [];
                                    $catRes = $conn->query("SELECT c.name FROM item_categories ic JOIN categories c ON ic.category_id = c.id WHERE ic.item_id = $item_id");
                                    while ($catRow = $catRes->fetch_assoc()) {
                                        $catNames[] = ucfirst($catRow['name']);
                                    }
                                    echo implode(', ', $catNames);
                                    ?></p>
                                    <p><strong>Available:</strong> <?php echo htmlspecialchars($row['quantityon']); ?> <?php echo htmlspecialchars($row['unit_on']); ?></p>
                                    <div class="card-actions">
                                        <button class="btn-view-card" data-id="<?php echo $row['id']; ?>">View</button>
                                        <button class="btn-edit-card" data-id="<?php echo $row['id']; ?>">Edit</button>
                                        <button class="btn-delete-card" data-id="<?php echo $row['id']; ?>">Delete</button>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <p>No equipment available.</p>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="todo">
                    <div class="head">
                        <h3>Add New Equipment</h3>
                    </div>

                    <form id="itemDetailsForm" action="equiplist.php" method="POST" enctype="multipart/form-data">
                        <input type="hidden" id="equiplist" name="id">

                        <div class="form-group">
                            <label for="itemname">Item Name</label>
                            <div class="input-group">
                                <input type="text" id="itemname" name="itemname" placeholder="Item Name">
                                <i class='bx bxs-label'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="specification">Item Specification</label>
                            <div class="input-group">
                                <input type="text" id="specification" name="specification" placeholder="Item Specification">
                                <i class='bx bx-detail'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="itemcategory">Item Categorization</label>
                            <div class="input-group" style="display: flex; align-items: center;">
                                <select id="itemcategory" name="itemcategory[]" multiple required>
                                    <?php
                                    $catResult = $conn->query("SELECT id, name FROM categories ORDER BY name ASC");
                                    while ($catRow = $catResult->fetch_assoc()) {
                                        echo '<option value="' . htmlspecialchars($catRow['id']) . '">' . htmlspecialchars(ucfirst($catRow['name'])) . '</option>';
                                    }
                                    ?>
                                </select>
                                <i class='bx bx-folder-plus' id="addCategoryBtn" style="margin-left:8px; cursor:pointer; font-size:1.3rem;" title="Add Category"></i>
                                <i class='bx bx-chevron-down'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="quantityreq">Quantity Required</label>
                            <div class="quantity-wrapper">
                                <input type="number" id="quantityreq" name="quantityreq" placeholder="0" min="1">
                                <select id="unit_req" name="unit_req">
                                    <option value="pcs" selected>pcs</option>
                                    <option value="sets">sets</option>
                                    <option value="units">units</option>
                                    <option value="box">box</option>
                                    <option value="others">others</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="quantityon">Quantity on Site</label>
                            <div class="quantity-wrapper">
                                <input type="number" id="quantityon" name="quantityon" placeholder="0" min="1">
                                <select id="unit_on" name="unit_on">
                                    <option value="pcs" selected>pcs</option>
                                    <option value="sets">sets</option>
                                    <option value="units">units</option>
                                    <option value="box">box</option>
                                    <option value="others">others</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="difference">Difference</label>
                            <div class="input-group">
                                <input type="text" id="difference" name="difference" placeholder="Difference">
                                <i class='bx bxs-calculator'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="remarks">Inspectors Remarks</label>
                            <div class="input-group">
                                <input type="text" id="remarks" name="remarks" placeholder="Inspector Remarks">
                                <i class='bx bx-comment-detail'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="itemdescription">Item Description</label>
                            <div class="input-group">
                                <input type="text" id="itemdescription" name="itemdescription" placeholder="Item Description">
                                <i class='bx bx-file-blank'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="complianceauditone">Quantity onsite during Compliance Audit Year 1</label>
                            <div class="quantity-wrapper">
                                <input type="number" id="complianceauditone" name="complianceauditone" placeholder="0" min="1">
                                <select id="unit1" name="unit1">
                                    <option value="pcs" selected>pcs</option>
                                    <option value="sets">sets</option>
                                    <option value="units">units</option>
                                    <option value="box">box</option>
                                    <option value="others">others</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="complianceaudittwo">Quantity onsite during Compliance Audit Year 2</label>
                            <div class="quantity-wrapper">
                                <input type="number" id="complianceaudittwo" name="complianceaudittwo" placeholder="0" min="1">
                                <select id="unit2" name="unit2">
                                    <option value="pcs" selected>pcs</option>
                                    <option value="sets">sets</option>
                                    <option value="units">units</option>
                                    <option value="box">box</option>
                                    <option value="others">others</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="eqpphoto">Equipment Image</label>
                            <div class="upload-container">
                                <div class="upload-preview">
                                    <img id="eqpphoto-preview" src="#" alt="Equipment Photo" style="display:none;">
                                </div>
                                <label for="eqpphoto" class="upload-box">
                                    <div class="upload-icon">
                                        <i class='bx bx-cloud-upload'></i>
                                        <p>Upload Image</p>
                                        <p class="file-size-note">Image size must be less than 2MB</p>
                                    </div>
                                </label>
                                <input type="file" id="eqpphoto" name="eqpphoto" style="display: none;" onchange="previewImage(event, 'eqpphoto-preview')">
                            </div>
                        </div>

                        <button type="submit" class="btn-submit">Submit</button>
                        <button type="button" class="btn-cancel" onclick="clearEquipmentForm()">Cancel</button>
                    </form>

                </div>
            </div>
        </main>
    </section>

    <!-- Add Category Modal -->
    <div id="addCategoryModal" class="modal" style="display:none;">
        <div class="modal-content" style="background:#fff; padding:20px; border-radius:8px; max-width:400px; margin:auto; position:relative;">
            <span id="closeCategoryModal" style="position:absolute; top:10px; right:15px; cursor:pointer; font-size:20px;">&times;</span>
            <h3>Add New Category</h3>
            <form id="addCategoryForm">
                <input type="text" id="newCategoryName" placeholder="Category Name" required style="width:100%; padding:8px; margin-bottom:10px;">
                <button type="submit" style="padding:8px 16px;">Add Category</button>
            </form>
            <div id="addCategoryMsg" style="color:green; margin-top:10px;"></div>
        </div>
    </div>

    <!-- View Item Details Modal -->
    <div id="viewItemModal" style="display:none;">
        <div class="modal-content" style="background:#fff; padding:25px; border-radius:12px; max-width:600px; width:90%; margin:auto; position:relative;">
            <span id="closeViewModal" style="position:absolute; top:15px; right:20px; cursor:pointer; font-size:24px; color:#666;">&times;</span>
            <div id="itemDetailsContent">
                <!-- Content will be loaded here -->
            </div>
        </div>
    </div>

    <!-- Categories Management Modal -->
    <div id="categoriesModal" style="display:none;">
        <div class="modal-content" style="background:#fff; padding:25px; border-radius:12px; max-width:800px; width:90%; margin:auto; position:relative;">
            <span id="closeCategoriesModal" style="position:absolute; top:15px; right:20px; cursor:pointer; font-size:24px; color:#666;">&times;</span>
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2 style="margin: 0; color: #333;">Categories Management</h2>
                <button id="addNewCategoryBtn" style="background: #6c63ff; color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer;">
                    <i class='bx bx-plus'></i> Add New Category
                </button>
            </div>
            <div id="categoriesContent">
                <!-- Categories will be loaded here -->
            </div>
        </div>
    </div>

    <!-- jQuery (must be first) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Select2 (after jQuery) -->
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <!-- Your custom JS (after both) -->
    <script>
        function previewImage(event, previewId) {
            const input = event.target;
            const preview = document.getElementById(previewId);

            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.style.display = "block";
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        function clearEquipmentForm() {
            // Clear all form fields
            document.getElementById("equiplist").value = "";
            document.getElementById("itemname").value = "";
            document.getElementById("specification").value = "";
            document.getElementById("quantityreq").value = "";
            document.getElementById("unit_req").value = "pcs";
            document.getElementById("quantityon").value = "";
            document.getElementById("unit_on").value = "pcs";
            document.getElementById("difference").value = "";
            document.getElementById("remarks").value = "";
            document.getElementById("itemdescription").value = "";
            document.getElementById("complianceauditone").value = "";
            document.getElementById("unit1").value = "pcs";
            document.getElementById("complianceaudittwo").value = "";
            document.getElementById("unit2").value = "pcs";
            
            // Clear Select2 categories
            $('#itemcategory').val(null).trigger('change');
            
            // Clear image preview
            const preview = document.getElementById("eqpphoto-preview");
            preview.src = "#";
            preview.style.display = "none";
            
            // Clear file input
            document.getElementById("eqpphoto").value = "";
        }

        document.addEventListener("DOMContentLoaded", () => {
            // Handle EDIT button
            document.querySelectorAll(".btn-edit-card").forEach(btn => {
                btn.addEventListener("click", function(e) {
                    e.stopPropagation(); // Prevent row click
                    const itemId = this.getAttribute("data-id");

                    fetch(`fetch_equipment_info.php?id=${itemId}`)
                        .then(response => response.json())
                        .then(data => {
                            if (data.error) {
                                alert(data.error);
                            } else {
                                // Fill the form with the fetched data
                                document.getElementById("equiplist").value = data.id;
                                document.getElementById("itemname").value = data.itemname;
                                document.getElementById("specification").value = data.specification;
                                // Set Select2 value as array for editing
                                $('#itemcategory').val(data.itemcategory).trigger('change');
                                document.getElementById("quantityreq").value = data.quantityreq;
                                document.getElementById("unit_req").value = data.unit_req;
                                document.getElementById("quantityon").value = data.quantityon;
                                document.getElementById("unit_on").value = data.unit_on;
                                document.getElementById("difference").value = data.difference;
                                document.getElementById("remarks").value = data.remarks;
                                document.getElementById("itemdescription").value = data.itemdescription;
                                document.getElementById("complianceauditone").value = data.complianceauditone;
                                document.getElementById("unit1").value = data.unit1 || "pcs";
                                document.getElementById("complianceaudittwo").value = data.complianceaudittwo;
                                document.getElementById("unit2").value = data.unit2 || "pcs";

                                if (data.eqpphoto) {
                                    const preview = document.getElementById("eqpphoto-preview");
                                    preview.src = `uploads/${data.eqpphoto}`;
                                    preview.style.display = "block";
                                }
                            }
                        });
                });
            });

            // Handle VIEW button
            document.querySelectorAll(".btn-view-card").forEach(btn => {
                btn.addEventListener("click", function(e) {
                    e.stopPropagation(); // Prevent row click
                    const itemId = this.getAttribute("data-id");
                    
                    console.log("View button clicked for item ID:", itemId);

                    // Show loading state
                    const modal = document.getElementById("viewItemModal");
                    const content = document.getElementById("itemDetailsContent");
                    
                    console.log("Modal element:", modal);
                    console.log("Content element:", content);
                    
                    content.innerHTML = '<div style="text-align: center; padding: 20px;"><i class="bx bx-loader-alt bx-spin" style="font-size: 2rem;"></i><p>Loading item details...</p></div>';
                    modal.style.display = "block";
                    modal.style.position = "fixed";
                    modal.style.zIndex = "1000";
                    modal.style.left = "0";
                    modal.style.top = "0";
                    modal.style.width = "100vw";
                    modal.style.height = "100vh";
                    modal.style.backgroundColor = "rgba(0,0,0,0.4)";
                    modal.style.display = "flex";
                    modal.style.justifyContent = "center";
                    modal.style.alignItems = "center";
                    
                    console.log("Modal display set to:", modal.style.display);

                    fetch(`fetch_equipment_info.php?id=${itemId}`)
                        .then(response => response.json())
                        .then(data => {
                            if (data.error) {
                                content.innerHTML = `<div style="text-align: center; padding: 20px; color: red;"><p>Error: ${data.error}</p></div>`;
                            } else {
                                // Fetch categories for this item
                                fetch(`fetch_item_categories.php?item_id=${itemId}`)
                                    .then(response => response.json())
                                    .then(categories => {
                                        const categoryNames = categories.map(cat => cat.name).join(', ');
                                        
                                        content.innerHTML = `
                                            <div style="display: flex; gap: 20px; margin-bottom: 20px;">
                                                <div style="flex: 1;">
                                                    <img src="uploads/${data.eqpphoto || 'placeholder.png'}" alt="Equipment Image" style="width: 100%; max-width: 300px; height: auto; border-radius: 8px; object-fit: cover;">
                                                </div>
                                                <div style="flex: 2;">
                                                    <h2 style="margin: 0 0 15px 0; color: #333;">${data.itemname}</h2>
                                                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                                                        <div>
                                                            <strong>Specification:</strong><br>
                                                            <span>${data.specification || 'Not specified'}</span>
                                                        </div>
                                                        <div>
                                                            <strong>Categories:</strong><br>
                                                            <span>${categoryNames || 'No categories'}</span>
                                                        </div>
                                                        <div>
                                                            <strong>Description:</strong><br>
                                                            <span>${data.itemdescription || 'No description'}</span>
                                                        </div>
                                                        <div>
                                                            <strong>Remarks:</strong><br>
                                                            <span>${data.remarks || 'No remarks'}</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-top: 20px;">
                                                <div style="background: #f8f9fa; padding: 15px; border-radius: 8px;">
                                                    <h3 style="margin: 0 0 10px 0; color: #495057;">Quantity Information</h3>
                                                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                                                        <div>
                                                            <strong>Required:</strong><br>
                                                            <span>${data.quantityreq || 0} ${data.unit_req || 'pcs'}</span>
                                                        </div>
                                                        <div>
                                                            <strong>Available:</strong><br>
                                                            <span>${data.quantityon || 0} ${data.unit_on || 'pcs'}</span>
                                                        </div>
                                                        <div>
                                                            <strong>Difference:</strong><br>
                                                            <span>${data.difference || 'Not calculated'}</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div style="background: #f8f9fa; padding: 15px; border-radius: 8px;">
                                                    <h3 style="margin: 0 0 10px 0; color: #495057;">Compliance Audit</h3>
                                                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                                                        <div>
                                                            <strong>Year 1:</strong><br>
                                                            <span>${data.complianceauditone || 0} ${data.unit1 || 'pcs'}</span>
                                                        </div>
                                                        <div>
                                                            <strong>Year 2:</strong><br>
                                                            <span>${data.complianceaudittwo || 0} ${data.unit2 || 'pcs'}</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid #dee2e6;">
                                                <small style="color: #6c757d;">Item ID: ${data.id} | Created: ${data.created_at || 'Unknown'}</small>
                                            </div>
                                        `;
                                    })
                                    .catch(error => {
                                        content.innerHTML = `<div style="text-align: center; padding: 20px; color: red;"><p>Error loading categories: ${error.message}</p></div>`;
                                    });
                            }
                        })
                        .catch(error => {
                            content.innerHTML = `<div style="text-align: center; padding: 20px; color: red;"><p>Error loading item details: ${error.message}</p></div>`;
                        });
                });
            });

            // Handle DELETE button
            document.querySelectorAll(".btn-delete-card").forEach(btn => {
                btn.addEventListener("click", function(e) {
                    e.stopPropagation(); // Prevent row click
                    const itemId = this.getAttribute("data-id");

                    if (confirm("Are you sure you want to delete this equipment?")) {
                        fetch(`delete_equipment.php?id=${itemId}`, {
                                method: "POST"
                            })
                            .then(response => response.json())
                            .then(data => {
                                if (data.success) {
                                    alert("Item deleted successfully!");
                                    location.reload(); // Refresh the table
                                } else {
                                    alert("Error deleting item: " + data.error);
                                }
                            });
                    }
                });
            });

            // Filter button logic
            const filterOptions = document.querySelectorAll(".filter-option");
            const equipmentCards = document.querySelectorAll(".equipment-card");

            filterOptions.forEach(btn => {
                btn.addEventListener("click", function() {
                    // Remove active class from all
                    filterOptions.forEach(b => b.classList.remove("active"));
                    this.classList.add("active");

                    const category = this.getAttribute("data-category");
                    equipmentCards.forEach(card => {
                        if (category === "all" || card.getAttribute("data-category") === category) {
                            card.style.display = "";
                        } else {
                            card.style.display = "none";
                        }
                    });
                });
            });

            const filterBtn = document.getElementById("filterBtn");
            const filterGroup = document.getElementById("filterGroup");

            // Start hidden
            filterGroup.classList.add("hide");

            filterBtn.addEventListener("click", function(e) {
                e.stopPropagation();
                filterGroup.classList.toggle("hide");
            });

            // Hide filter group when clicking outside
            document.addEventListener("click", function(e) {
                if (!filterGroup.contains(e.target) && e.target !== filterBtn) {
                    filterGroup.classList.add("hide");
                }
            });

            // Universal search for equipment cards
            const globalSearchForm = document.getElementById("globalSearchForm");
            const globalSearchInput = document.getElementById("globalSearchInput");

            if (globalSearchForm && globalSearchInput) {
                globalSearchForm.addEventListener("submit", function(e) {
                    e.preventDefault();
                    const query = globalSearchInput.value.trim().toLowerCase();
                    const equipmentCards = document.querySelectorAll(".equipment-card");
                    if (equipmentCards.length > 0) {
                        equipmentCards.forEach(card => {
                            const name = card.querySelector("h4").textContent.toLowerCase();
                            const category = card.getAttribute("data-category").toLowerCase();
                            const spec = card.querySelector("p") ? card.querySelector("p").textContent.toLowerCase() : "";
                            if (name.includes(query) || category.includes(query) || spec.includes(query)) {
                                card.style.display = "";
                            } else {
                                card.style.display = "none";
                            }
                        });
                    }
                });

                // Optional: Live search as you type
                globalSearchInput.addEventListener("input", function() {
                    const query = globalSearchInput.value.trim().toLowerCase();
                    const equipmentCards = document.querySelectorAll(".equipment-card");
                    if (equipmentCards.length > 0) {
                        equipmentCards.forEach(card => {
                            const name = card.querySelector("h4").textContent.toLowerCase();
                            const category = card.getAttribute("data-category").toLowerCase();
                            const spec = card.querySelector("p") ? card.querySelector("p").textContent.toLowerCase() : "";
                            if (name.includes(query) || category.includes(query) || spec.includes(query)) {
                                card.style.display = "";
                            } else {
                                card.style.display = "none";
                            }
                        });
                    }
                });
            }

            // Modal logic
            const addCategoryBtn = document.getElementById("addCategoryBtn");
            const addCategoryModal = document.getElementById("addCategoryModal");
            const closeCategoryModal = document.getElementById("closeCategoryModal");
            const addCategoryForm = document.getElementById("addCategoryForm");
            const newCategoryName = document.getElementById("newCategoryName");
            const addCategoryMsg = document.getElementById("addCategoryMsg");
            const itemCategorySelect = document.getElementById("itemcategory");

            addCategoryBtn.addEventListener("click", function(e) {
                e.preventDefault(); // Prevent form submission
                e.stopPropagation(); // Prevent bubbling
                addCategoryModal.style.display = "block";
                addCategoryMsg.textContent = "";
                newCategoryName.value = "";
                newCategoryName.focus();
            });

            closeCategoryModal.addEventListener("click", function() {
                addCategoryModal.style.display = "none";
            });

            window.addEventListener("click", function(event) {
                if (event.target == addCategoryModal) {
                    addCategoryModal.style.display = "none";
                }
            });

            // View modal close functionality
            const closeViewModal = document.getElementById("closeViewModal");
            const viewItemModal = document.getElementById("viewItemModal");

            closeViewModal.addEventListener("click", function() {
                viewItemModal.style.display = "none";
            });

            window.addEventListener("click", function(event) {
                if (event.target == viewItemModal) {
                    viewItemModal.style.display = "none";
                }
            });

            // Categories modal functionality
            const categoriesNavLink = document.getElementById("categoriesNavLink");
            const categoriesModal = document.getElementById("categoriesModal");
            const closeCategoriesModal = document.getElementById("closeCategoriesModal");
            const categoriesContent = document.getElementById("categoriesContent");
            const addNewCategoryBtn = document.getElementById("addNewCategoryBtn");

            // Open categories modal
            categoriesNavLink.addEventListener("click", function(e) {
                e.preventDefault();
                loadCategories();
                categoriesModal.style.display = "block";
                categoriesModal.style.position = "fixed";
                categoriesModal.style.zIndex = "1000";
                categoriesModal.style.left = "0";
                categoriesModal.style.top = "0";
                categoriesModal.style.width = "100vw";
                categoriesModal.style.height = "100vh";
                categoriesModal.style.backgroundColor = "rgba(0,0,0,0.4)";
                categoriesModal.style.display = "flex";
                categoriesModal.style.justifyContent = "center";
                categoriesModal.style.alignItems = "center";
            });

            // Close categories modal
            closeCategoriesModal.addEventListener("click", function() {
                categoriesModal.style.display = "none";
            });

            window.addEventListener("click", function(event) {
                if (event.target == categoriesModal) {
                    categoriesModal.style.display = "none";
                }
            });

            // Load categories function
            function loadCategories() {
                categoriesContent.innerHTML = '<div style="text-align: center; padding: 20px;"><i class="bx bx-loader-alt bx-spin" style="font-size: 2rem;"></i><p>Loading categories...</p></div>';
                
                fetch('manage_categories.php?action=fetch')
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            displayCategories(data.categories);
                        } else {
                            categoriesContent.innerHTML = `<div style="text-align: center; padding: 20px; color: red;"><p>Error: ${data.error}</p></div>`;
                        }
                    })
                    .catch(error => {
                        categoriesContent.innerHTML = `<div style="text-align: center; padding: 20px; color: red;"><p>Error loading categories: ${error.message}</p></div>`;
                    });
            }

            // Display categories function
            function displayCategories(categories) {
                if (categories.length === 0) {
                    categoriesContent.innerHTML = `
                        <div style="text-align: center; padding: 40px;">
                            <i class='bx bx-folder-open' style="font-size: 3rem; color: #ccc; margin-bottom: 10px;"></i>
                            <p style="color: #666;">No categories found. Click "Add New Category" to create one.</p>
                        </div>
                    `;
                    return;
                }

                let html = `
                    <div style="max-height: 400px; overflow-y: auto;">
                        <table style="width: 100%; border-collapse: collapse;">
                            <thead>
                                <tr style="background: #f8f9fa; border-bottom: 2px solid #dee2e6;">
                                    <th style="padding: 12px; text-align: left; font-weight: 600;">Category Name</th>
                                    <th style="padding: 12px; text-align: left; font-weight: 600;">Created Date</th>
                                    <th style="padding: 12px; text-align: center; font-weight: 600;">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                `;

                categories.forEach(category => {
                    html += `
                        <tr style="border-bottom: 1px solid #eee;">
                            <td style="padding: 12px;">
                                <span class="category-name" data-id="${category.id}">${category.name}</span>
                            </td>
                            <td style="padding: 12px; color: #666;">
                                ${category.created_at ? new Date(category.created_at).toLocaleDateString() : 'N/A'}
                            </td>
                            <td style="padding: 12px; text-align: center;">
                                <button class="edit-category-btn" data-id="${category.id}" data-name="${category.name}" style="background: #f0ad4e; color: white; border: none; padding: 4px 8px; border-radius: 4px; cursor: pointer; margin-right: 5px;">
                                    <i class='bx bx-edit-alt'></i> Edit
                                </button>
                                <button class="delete-category-btn" data-id="${category.id}" data-name="${category.name}" style="background: #d9534f; color: white; border: none; padding: 4px 8px; border-radius: 4px; cursor: pointer;">
                                    <i class='bx bx-trash'></i> Delete
                                </button>
                            </td>
                        </tr>
                    `;
                });

                html += `
                            </tbody>
                        </table>
                    </div>
                `;

                categoriesContent.innerHTML = html;

                // Add event listeners for edit and delete buttons
                document.querySelectorAll('.edit-category-btn').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const id = this.getAttribute('data-id');
                        const name = this.getAttribute('data-name');
                        editCategory(id, name);
                    });
                });

                document.querySelectorAll('.delete-category-btn').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const id = this.getAttribute('data-id');
                        const name = this.getAttribute('data-name');
                        deleteCategory(id, name);
                    });
                });
            }

            // Edit category function
            function editCategory(id, currentName) {
                const newName = prompt('Edit category name:', currentName);
                if (newName === null || newName.trim() === '') return;

                const formData = new FormData();
                formData.append('id', id);
                formData.append('name', newName.trim());

                fetch('manage_categories.php?action=edit', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Category updated successfully!');
                        loadCategories(); // Reload the list
                    } else {
                        alert('Error: ' + data.error);
                    }
                })
                .catch(error => {
                    alert('Error updating category: ' + error.message);
                });
            }

            // Delete category function
            function deleteCategory(id, name) {
                if (!confirm(`Are you sure you want to delete the category "${name}"?`)) return;

                const formData = new FormData();
                formData.append('id', id);

                fetch('manage_categories.php?action=delete', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Category deleted successfully!');
                        loadCategories(); // Reload the list
                    } else {
                        alert('Error: ' + data.error);
                    }
                })
                .catch(error => {
                    alert('Error deleting category: ' + error.message);
                });
            }

            // Add new category functionality
            addNewCategoryBtn.addEventListener('click', function() {
                const categoryName = prompt('Enter new category name:');
                if (categoryName === null || categoryName.trim() === '') return;

                const formData = new FormData();
                formData.append('category', categoryName.trim());

                fetch('add_category.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Category added successfully!');
                        loadCategories(); // Reload the list
                    } else {
                        alert('Error: ' + data.error);
                    }
                })
                .catch(error => {
                    alert('Error adding category: ' + error.message);
                });
            });

            // AJAX to add category
            addCategoryForm.addEventListener("submit", function(e) {
                e.preventDefault(); // Prevents any form submission
                const category = newCategoryName.value.trim();
                if (!category) return;

                fetch('add_category.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'category=' + encodeURIComponent(category)
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        addCategoryMsg.textContent = "Category added!";
                        // Add new option to select
                        const option = document.createElement("option");
                        option.value = category;
                        option.textContent = category.charAt(0).toUpperCase() + category.slice(1);
                        itemCategorySelect.appendChild(option);
                        itemCategorySelect.value = category;
                        setTimeout(() => {
                            addCategoryModal.style.display = "none";
                        }, 800);

                        // Add new filter button
                        const filterGroup = document.getElementById("filterGroup");
                        const newBtn = document.createElement("button");
                        newBtn.className = "filter-option";
                        newBtn.setAttribute("data-category", category);
                        newBtn.textContent = category.charAt(0).toUpperCase() + category.slice(1);
                        filterGroup.appendChild(newBtn);

                        // Add event listener for filtering
                        newBtn.addEventListener("click", function() {
                            // Remove active class from all
                            document.querySelectorAll("#filterGroup .filter-option").forEach(b => b.classList.remove("active"));
                            this.classList.add("active");
                            const category = this.getAttribute("data-category");
                            document.querySelectorAll(".equipment-card").forEach(card => {
                                if (category === "all" || card.getAttribute("data-category") === category) {
                                    card.style.display = "";
                                } else {
                                    card.style.display = "none";
                                }
                            });
                        });
                    } else {
                        addCategoryMsg.textContent = data.error || "Error adding category.";
                        addCategoryMsg.style.color = "red";
                    }
                })
                .catch(() => {
                    addCategoryMsg.textContent = "Error connecting to server.";
                    addCategoryMsg.style.color = "red";
                });
            });

            // Initialize Select2 for itemcategory
            $(document).ready(function() {
                $('#itemcategory').select2({
                    placeholder: "Select categories",
                    width: '100%',
                    allowClear: true
                });
                
                // Clear any pre-selected values on page load
                $('#itemcategory').val(null).trigger('change');
            });

            const menuBar = document.querySelector('#content nav .bx.bx-menu');
            const sidebar = document.getElementById('sidebar');

            if (menuBar) {
                menuBar.addEventListener('click', function () {
                    sidebar.classList.toggle('hide');
                });
            }

            // Notification functionality
            const notificationIcon = document.getElementById('notificationIcon');
            const notificationDropdown = document.getElementById('notificationDropdown');
            const notificationCount = document.getElementById('notificationCount');
            const notificationList = document.getElementById('notificationList');
            const markAllReadBtn = document.getElementById('markAllRead');

            // Load notification count
            function loadNotificationCount() {
                fetch('get_notifications.php?action=count')
                    .then(response => response.json())
                    .then(data => {
                        if (data.count > 0) {
                            notificationCount.textContent = data.count;
                            notificationCount.style.display = 'block';
                        } else {
                            notificationCount.style.display = 'none';
                        }
                    })
                    .catch(error => console.error('Error loading notification count:', error));
            }

            // Load notifications
            function loadNotifications() {
                fetch('get_notifications.php?action=list&limit=10')
                    .then(response => response.json())
                    .then(data => {
                        if (data.notifications && data.notifications.length > 0) {
                            let html = '';
                            data.notifications.forEach(notification => {
                                const isRead = notification.is_read ? 'read' : 'unread';
                                const timeAgo = getTimeAgo(notification.created_at);
                                html += `
                                    <div class="notification-item ${isRead}" data-id="${notification.id}">
                                        <div class="notification-content">
                                            <h5>${notification.title}</h5>
                                            <p>${notification.message}</p>
                                            <small>${timeAgo}</small>
                                        </div>
                                        ${!notification.is_read ? '<div class="unread-indicator"></div>' : ''}
                                    </div>
                                `;
                            });
                            notificationList.innerHTML = html;
                        } else {
                            notificationList.innerHTML = '<div class="no-notifications">No notifications</div>';
                        }
                    })
                    .catch(error => console.error('Error loading notifications:', error));
            }

            // Get time ago
            function getTimeAgo(timestamp) {
                const now = new Date();
                const created = new Date(timestamp);
                const diffInSeconds = Math.floor((now - created) / 1000);
                
                if (diffInSeconds < 60) return 'Just now';
                if (diffInSeconds < 3600) return Math.floor(diffInSeconds / 60) + 'm ago';
                if (diffInSeconds < 86400) return Math.floor(diffInSeconds / 3600) + 'h ago';
                return Math.floor(diffInSeconds / 86400) + 'd ago';
            }

            // Toggle notification dropdown
            notificationIcon.addEventListener('click', function(e) {
                e.preventDefault();
                notificationDropdown.style.display = notificationDropdown.style.display === 'none' ? 'block' : 'none';
                if (notificationDropdown.style.display === 'block') {
                    loadNotifications();
                }
            });

            // Mark all as read
            markAllReadBtn.addEventListener('click', function() {
                fetch('get_notifications.php?action=mark_all_read', {
                    method: 'POST'
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        loadNotificationCount();
                        loadNotifications();
                    }
                })
                .catch(error => console.error('Error marking all as read:', error));
            });

            // Mark individual notification as read
            notificationList.addEventListener('click', function(e) {
                const notificationItem = e.target.closest('.notification-item');
                if (notificationItem && !notificationItem.classList.contains('read')) {
                    const notificationId = notificationItem.getAttribute('data-id');
                    fetch('get_notifications.php?action=mark_read', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: 'notification_id=' + notificationId
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            notificationItem.classList.remove('unread');
                            notificationItem.classList.add('read');
                            notificationItem.querySelector('.unread-indicator')?.remove();
                            loadNotificationCount();
                        }
                    })
                    .catch(error => console.error('Error marking notification as read:', error));
                }
            });

            // Close dropdown when clicking outside
            document.addEventListener('click', function(e) {
                if (!notificationIcon.contains(e.target) && !notificationDropdown.contains(e.target)) {
                    notificationDropdown.style.display = 'none';
                }
            });

            // Load notification count on page load
            loadNotificationCount();

            // Refresh notification count every 30 seconds
            setInterval(loadNotificationCount, 30000);
        });
    </script>
    <script src="script.js"></script>
</body>

</html>
