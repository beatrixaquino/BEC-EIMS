<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple Dropdown Debug</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background: #f5f5f5;
        }
        
        .sidebar {
            width: 250px;
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .dropdown {
            position: relative;
            margin-bottom: 10px;
        }
        
        .dropdown-toggle {
            display: flex;
            align-items: center;
            padding: 10px;
            background: #f8f9fa;
            border-radius: 5px;
            text-decoration: none;
            color: #333;
            position: relative;
        }
        
        .dropdown-arrow {
            position: absolute;
            right: 10px;
            transition: transform 0.3s ease;
        }
        
        .dropdown.active .dropdown-arrow {
            transform: rotate(180deg);
        }
        
        .dropdown-menu {
            position: absolute;
            left: 100%;
            top: 0;
            background: white;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            min-width: 200px;
            opacity: 0;
            visibility: hidden;
            transform: translateX(-10px);
            transition: all 0.3s ease;
            z-index: 1000;
            padding: 5px 0;
            display: none;
        }
        
        .dropdown-menu.show {
            opacity: 1;
            visibility: visible;
            transform: translateX(0);
            display: block;
        }
        
        .dropdown-menu li {
            list-style: none;
            margin: 0;
            padding: 0;
        }
        
        .dropdown-menu li a {
            display: flex;
            align-items: center;
            padding: 8px 15px;
            text-decoration: none;
            color: #333;
            font-size: 14px;
        }
        
        .dropdown-menu li a:hover {
            background: #f8f9fa;
        }
        
        .dropdown-menu li a i {
            margin-right: 8px;
            width: 16px;
        }
        
        .debug-info {
            margin-top: 20px;
            padding: 15px;
            background: #e9ecef;
            border-radius: 5px;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="dropdown" id="borrowersDropdown">
            <a href="#" class="dropdown-toggle">
                <i class='bx bxs-report'></i>
                <span>Borrowers Forms</span>
                <i class='bx bx-chevron-down dropdown-arrow'></i>
            </a>
            <ul class="dropdown-menu" id="borrowersDropdownMenu">
                <li><a href="#"><i class='bx bxs-report'></i> All Forms</a></li>
                <li><a href="#"><i class='bx bxs-trash'></i> Deleted Records</a></li>
                <li><a href="#"><i class='bx bxs-time'></i> Pending Forms</a></li>
                <li><a href="#"><i class='bx bxs-check-circle'></i> Approved Forms</a></li>
                <li><a href="#"><i class='bx bxs-x-circle'></i> Rejected Forms</a></li>
                <li><a href="#"><i class='bx bxs-archive'></i> Returned Forms</a></li>
            </ul>
        </div>
    </div>

    <div class="debug-info">
        <h3>Debug Information:</h3>
        <p><strong>Click Status:</strong> <span id="clickStatus">Not clicked</span></p>
        <p><strong>Dropdown Classes:</strong> <span id="dropdownClasses">None</span></p>
        <p><strong>Menu Classes:</strong> <span id="menuClasses">None</span></p>
        <p><strong>Menu Display:</strong> <span id="menuDisplay">None</span></p>
        <p><strong>Menu Opacity:</strong> <span id="menuOpacity">None</span></p>
        <p><strong>Menu Visibility:</strong> <span id="menuVisibility">None</span></p>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const dropdown = document.getElementById('borrowersDropdown');
            const dropdownMenu = document.getElementById('borrowersDropdownMenu');
            
            // Debug elements
            const clickStatus = document.getElementById('clickStatus');
            const dropdownClasses = document.getElementById('dropdownClasses');
            const menuClasses = document.getElementById('menuClasses');
            const menuDisplay = document.getElementById('menuDisplay');
            const menuOpacity = document.getElementById('menuOpacity');
            const menuVisibility = document.getElementById('menuVisibility');
            
            function updateDebugInfo() {
                clickStatus.textContent = 'Clicked';
                dropdownClasses.textContent = dropdown.className;
                menuClasses.textContent = dropdownMenu.className;
                menuDisplay.textContent = window.getComputedStyle(dropdownMenu).display;
                menuOpacity.textContent = window.getComputedStyle(dropdownMenu).opacity;
                menuVisibility.textContent = window.getComputedStyle(dropdownMenu).visibility;
            }
            
            if (dropdown && dropdownMenu) {
                dropdown.addEventListener('click', function(e) {
                    e.preventDefault();
                    console.log('Dropdown clicked!');
                    console.log('Before toggle - Menu classes:', dropdownMenu.className);
                    console.log('Before toggle - Menu display:', window.getComputedStyle(dropdownMenu).display);
                    
                    dropdown.classList.toggle('active');
                    dropdownMenu.classList.toggle('show');
                    
                    console.log('After toggle - Menu classes:', dropdownMenu.className);
                    console.log('After toggle - Menu display:', window.getComputedStyle(dropdownMenu).display);
                    
                    updateDebugInfo();
                });
                
                // Close dropdown when clicking outside
                document.addEventListener('click', function(e) {
                    if (!dropdown.contains(e.target)) {
                        dropdown.classList.remove('active');
                        dropdownMenu.classList.remove('show');
                        updateDebugInfo();
                    }
                });
            }
        });
    </script>
</body>
</html> 