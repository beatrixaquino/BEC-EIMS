<?php
session_start();
include_once "dbconnect.php";
include_once "soft_delete_helper.php";

// Check if user is admin
if (!isset($_SESSION['acctype']) || !in_array($_SESSION['acctype'], ['superadmin', 'admin'])) {
    header("Location: login.php");
    exit();
}

// Handle soft delete actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    $borrower_id = intval($_POST['borrower_id'] ?? 0);
    $user_id = $_SESSION['user_id'] ?? null;
    
    switch ($action) {
        case 'restore':
            if (restoreBorrower($borrower_id, $user_id)) {
                $_SESSION['message'] = "Record restored successfully!";
            } else {
                $_SESSION['error'] = "Failed to restore record.";
            }
            break;
            
        case 'hard_delete':
            if (hardDeleteBorrower($borrower_id)) {
                $_SESSION['message'] = "Record permanently deleted!";
            } else {
                $_SESSION['error'] = "Failed to delete record.";
            }
            break;
    }
    
    header("Location: manage_deleted_records.php");
    exit();
}

// Get deleted records
$deleted_records = getDeletedBorrowers();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="istyle.css">
    <title>Manage Deleted Records</title>
</head>
<body data-page="manage_deleted_records">

<!-- SIDEBAR -->
<section id="sidebar">
    <a href="#" class="brand">
        <i class='bx bxs-package'></i>
        <span class="text">BEC EIMS</span>
    </a>
    <ul class="side-menu top">
        <li>
            <a href="dashboard_superadmin.php">
                <i class='bx bxs-dashboard'></i>
                <span class="text">Dashboard</span>
            </a>
        </li>
        <li>
            <a href="usermng.php">
                <i class='bx bx-group'></i>
                <span class="text">User Management</span>
            </a>
        </li>
        <li>
            <a href="borrowform.php">
                <i class='bx bxs-report'></i>
                <span class="text">Borrowers Forms</span>
            </a>
        </li>
        <li class="active">
            <a href="manage_deleted_records.php">
                <i class='bx bxs-trash'></i>
                <span class="text">Deleted Records</span>
            </a>
        </li>
    </ul>
    <ul class="side-menu">
        <li>
            <a href="login.php" class="logout">
                <i class='bx bxs-log-out'></i>
                <span class="text">Logout</span>
            </a>
        </li>
    </ul>
</section>

<!-- CONTENT -->
<section id="content">
    <nav>
        <i class='bx bx-menu'></i>
        <a href="#" class="nav-link">Deleted Records Management</a>
        <a href="#" class="profile">
            <img src="img/people.png">
        </a>
    </nav>

    <main>
        <div class="head-title">
            <div class="left">
                <h1>Manage Deleted Records</h1>
                <ul class="breadcrumb">
                    <li><a href="#">Admin</a></li>
                    <li><i class='bx bx-chevron-right'></i></li>
                    <li><a class="active" href="#">Deleted Records</a></li>
                </ul>
            </div>
        </div>

        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-success" style="background-color: #d4edda; color: #155724; padding: 10px; border-radius: 4px; margin-bottom: 15px;">
                <?php echo $_SESSION['message']; ?>
                <?php unset($_SESSION['message']); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger" style="background-color: #f8d7da; color: #721c24; padding: 10px; border-radius: 4px; margin-bottom: 15px;">
                <?php echo $_SESSION['error']; ?>
                <?php unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>

        <div class="table-data">
            <div class="order">
                <div class="head">
                    <h3>Soft Deleted Records</h3>
                    <i class='bx bx-trash'></i>
                </div>
                
                <?php if ($deleted_records && $deleted_records->num_rows > 0): ?>
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Borrower Name</th>
                                <th>Department</th>
                                <th>Status</th>
                                <th>Deleted Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $deleted_records->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $row['id']; ?></td>
                                    <td>
                                        <p><?php echo htmlspecialchars($row['firstname'] . ' ' . $row['lastname']); ?></p>
                                    </td>
                                    <td><?php echo htmlspecialchars($row['department']); ?></td>
                                    <td>
                                        <span class="status <?php echo $row['status']; ?>">
                                            <?php echo ucfirst($row['status']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo date("M j, Y g:i A", strtotime($row['deleted_at'])); ?></td>
                                    <td>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="borrower_id" value="<?php echo $row['id']; ?>">
                                            <input type="hidden" name="action" value="restore">
                                            <button type="submit" class="btn-restore" onclick="return confirm('Restore this record?')">
                                                <i class='bx bx-undo'></i> Restore
                                            </button>
                                        </form>
                                        
                                        <form method="POST" style="display: inline; margin-left: 5px;">
                                            <input type="hidden" name="borrower_id" value="<?php echo $row['id']; ?>">
                                            <input type="hidden" name="action" value="hard_delete">
                                            <button type="submit" class="btn-delete" onclick="return confirm('⚠️ WARNING: This will permanently delete the record and cannot be undone. Are you sure?')">
                                                <i class='bx bx-trash'></i> Delete Permanently
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div style="text-align: center; padding: 40px;">
                        <i class='bx bx-trash' style="font-size: 48px; color: #ccc;"></i>
                        <p style="color: #666; margin-top: 10px;">No deleted records found.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>
</section>

<style>
.btn-restore {
    background-color: #28a745;
    color: white;
    border: none;
    padding: 5px 10px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 12px;
}

.btn-restore:hover {
    background-color: #218838;
}

.btn-delete {
    background-color: #dc3545;
    color: white;
    border: none;
    padding: 5px 10px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 12px;
}

.btn-delete:hover {
    background-color: #c82333;
}

.status {
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: bold;
}

.status.pending {
    background-color: #ffeaa7;
    color: #d63031;
}

.status.approved {
    background-color: #55a3ff;
    color: white;
}

.status.rejected {
    background-color: #ff7675;
    color: white;
}

.status.returned {
    background-color: #00b894;
    color: white;
}
</style>

</body>
</html> 