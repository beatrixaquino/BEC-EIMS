<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple Dropdown Test</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="istyle.css">
</head>
<body>
    <div id="sidebar">
        <div class="side-menu top">
            <ul>
                <li class="dropdown" id="borrowersDropdown">
                    <a href="borrowform.php" class="dropdown-toggle">
                        <i class='bx bxs-report'></i>
                        <span class="text">Borrowers Forms</span>
                        <i class='bx bx-chevron-down dropdown-arrow'></i>
                    </a>
                    <ul class="dropdown-menu" id="borrowersDropdownMenu">
                        <li><a href="borrowform.php"><i class='bx bxs-report'></i> All Forms</a></li>
                        <li><a href="manage_deleted_records.php"><i class='bx bxs-trash'></i> Deleted Records</a></li>
                        <li><a href="borrowform.php?filter=pending"><i class='bx bxs-time'></i> Pending Forms</a></li>
                        <li><a href="borrowform.php?filter=approved"><i class='bx bxs-check-circle'></i> Approved Forms</a></li>
                        <li><a href="borrowform.php?filter=rejected"><i class='bx bxs-x-circle'></i> Rejected Forms</a></li>
                        <li><a href="borrowform.php?filter=returned"><i class='bx bxs-archive'></i> Returned Forms</a></li>
                    </ul>
                </li>
                <li>
                    <a href="equiplist.php">
                        <i class='bx bxs-grid-alt'></i>
                        <span class="text">Equipment List</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <div id="content">
        <h1>Simple Dropdown Test</h1>
        <p>Testing the cleaner dropdown approach:</p>
        
        <div style="margin-top: 20px; padding: 20px; background: #f8f9fa; border-radius: 8px;">
            <h3>How to Test:</h3>
            <ol>
                <li><strong>Click "Borrowers Forms" text</strong> → Should navigate to borrowform.php</li>
                <li><strong>Click the dropdown arrow (▼)</strong> → Should show dropdown menu</li>
                <li><strong>Click dropdown items</strong> → Should navigate to respective pages</li>
            </ol>
        </div>
        
        <div style="margin-top: 20px; padding: 20px; background: #e9ecef; border-radius: 8px;">
            <h3>Expected Results:</h3>
            <ul>
                <li>✅ Link text works normally</li>
                <li>✅ Arrow toggles dropdown</li>
                <li>✅ Dropdown items are clickable</li>
                <li>✅ Clean, simple interface</li>
            </ul>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html> 