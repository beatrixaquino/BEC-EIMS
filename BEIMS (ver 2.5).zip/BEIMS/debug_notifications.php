<?php
session_start();
include_once "dbconnect.php";
include_once "notification_helper.php";

echo "<h2>🔍 Notification System Debug</h2>";

// Check session
echo "<h3>✅ 1. Session Check:</h3>";
if (isset($_SESSION['user_id'])) {
    echo "<p style='color: green;'>✅ User ID: " . $_SESSION['user_id'] . "</p>";
    echo "<p>Username: " . ($_SESSION['username'] ?? 'Not set') . "</p>";
    echo "<p>Account Type: " . ($_SESSION['acctype'] ?? 'Not set') . "</p>";
} else {
    echo "<p style='color: red;'>❌ No user logged in</p>";
    echo "<p><a href='login.php'>Go to Login</a></p>";
}

// Check user role
echo "<h3>✅ 2. User Role Check:</h3>";
$user_role = getUserRole();
echo "<p>Detected Role: <strong>" . $user_role . "</strong></p>";

// Test notification creation
echo "<h3>✅ 3. Test Notification Creation:</h3>";
if (isset($_SESSION['user_id'])) {
    $test_result = createNotification(
        $_SESSION['user_id'],
        "Test Notification",
        "This is a test notification for debugging",
        "test_notification",
        null
    );
    
    if ($test_result) {
        echo "<p style='color: green;'>✅ Test notification created successfully</p>";
    } else {
        echo "<p style='color: red;'>❌ Failed to create test notification</p>";
    }
} else {
    echo "<p style='color: orange;'>⚠️ Cannot test notification creation - not logged in</p>";
}

// Check notification count
echo "<h3>✅ 4. Notification Count Check:</h3>";
if (isset($_SESSION['user_id'])) {
    $count = getUnreadNotificationsCount($_SESSION['user_id'], $user_role);
    echo "<p>Unread notifications for current user: <strong>" . $count . "</strong></p>";
} else {
    echo "<p style='color: orange;'>⚠️ Cannot check notification count - not logged in</p>";
}

// Show recent notifications
echo "<h3>✅ 5. Recent Notifications:</h3>";
if (isset($_SESSION['user_id'])) {
    $notifications = getNotifications($_SESSION['user_id'], 5, 0, $user_role);
    
    if (count($notifications) > 0) {
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>ID</th><th>User ID</th><th>Title</th><th>Type</th><th>Read</th><th>Created</th></tr>";
        foreach ($notifications as $notif) {
            $read_status = $notif['is_read'] ? '✅ Read' : '❌ Unread';
            echo "<tr>";
            echo "<td>" . $notif['id'] . "</td>";
            echo "<td>" . $notif['user_id'] . "</td>";
            echo "<td>" . htmlspecialchars($notif['title']) . "</td>";
            echo "<td>" . $notif['type'] . "</td>";
            echo "<td>" . $read_status . "</td>";
            echo "<td>" . $notif['created_at'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No notifications found for current user.</p>";
    }
} else {
    echo "<p style='color: orange;'>⚠️ Cannot show notifications - not logged in</p>";
}

// Show all notifications (for admin testing)
echo "<h3>✅ 6. All Notifications in Database:</h3>";
$sql = "SELECT * FROM notifications ORDER BY created_at DESC LIMIT 10";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>ID</th><th>User ID</th><th>Title</th><th>Type</th><th>Read</th><th>Created</th></tr>";
    while ($row = $result->fetch_assoc()) {
        $read_status = $row['is_read'] ? '✅ Read' : '❌ Unread';
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['user_id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['title']) . "</td>";
        echo "<td>" . $row['type'] . "</td>";
        echo "<td>" . $read_status . "</td>";
        echo "<td>" . $row['created_at'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No notifications found in database.</p>";
}

echo "<h3>🎯 Summary:</h3>";
if (isset($_SESSION['user_id'])) {
    echo "<p style='color: green;'>✅ Session is working - User ID: " . $_SESSION['user_id'] . "</p>";
    echo "<p>Role: " . $user_role . "</p>";
} else {
    echo "<p style='color: red;'>❌ Session not working - Please login</p>";
}

echo "<p><a href='login.php'>Login</a> | <a href='dashboard_stutea.php'>Dashboard</a> | <a href='borrowform_stutea.php'>Test Form</a></p>";

$conn->close();
?> 