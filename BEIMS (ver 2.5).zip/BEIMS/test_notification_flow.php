<?php
session_start();
include_once "dbconnect.php";
include_once "notification_system.php";

echo "<h2>🧪 Notification Flow Test</h2>";

// Check current session
echo "<h3>📋 Current Session:</h3>";
if (isset($_SESSION['user_id'])) {
    echo "<p style='color: green;'>✅ Logged in as User ID: " . $_SESSION['user_id'] . "</p>";
    echo "<p>Username: " . ($_SESSION['username'] ?? 'Not set') . "</p>";
    echo "<p>Account Type: " . ($_SESSION['acctype'] ?? 'Not set') . "</p>";
} else {
    echo "<p style='color: red;'>❌ Not logged in</p>";
    echo "<p><a href='login.php'>Login First</a></p>";
    exit();
}

$notificationSystem = getNotificationSystem();
$notificationEvents = getNotificationEvents();
$user_role = $notificationSystem->getUserRole();

echo "<h3>🎭 User Role: " . $user_role . "</h3>";

// Test notification flow based on user type
echo "<h3>🧪 Testing Notification Flow:</h3>";

if ($user_role === 'borrower' || $user_role === 'student' || $user_role === 'teacher') {
    echo "<h4>📝 Student/Teacher Form Submission Test:</h4>";
    echo "<p>Current User ID: " . $_SESSION['user_id'] . " (Student/Teacher)</p>";
    
    // Simulate form submission from student/teacher
    $result = $notificationEvents->onFormSubmitted(999, $_SESSION['user_id'], "Test Student", "Computer Science");
    
    if ($result) {
        echo "<p style='color: green;'>✅ Form submission notification sent successfully!</p>";
        echo "<p>📤 Sent to:</p>";
        echo "<ul>";
        echo "<li>Student (User ID " . $_SESSION['user_id'] . ") - form_submitted notification</li>";
        echo "<li>Superadmin (User ID 1) - new_form notification</li>";
        echo "</ul>";
    } else {
        echo "<p style='color: red;'>❌ Failed to send form submission notifications</p>";
    }
    
} elseif ($user_role === 'admin' || $user_role === 'superadmin') {
    echo "<h4>👨‍💼 Admin Form Status Update Test:</h4>";
    echo "<p>Current User ID: " . $_SESSION['user_id'] . " (Admin/Superadmin)</p>";
    
    // Simulate form status update from admin
    $result = $notificationEvents->onFormStatusChanged(999, 4, "Test Student", "approved");
    
    if ($result) {
        echo "<p style='color: green;'>✅ Form status update notification sent successfully!</p>";
        echo "<p>📤 Sent to:</p>";
        echo "<ul>";
        echo "<li>Student (User ID 4) - form_approved notification</li>";
        echo "<li>Superadmin (User ID 1) - form_approved notification</li>";
        echo "</ul>";
    } else {
        echo "<p style='color: red;'>❌ Failed to send form status update notifications</p>";
    }
}

// Check notification count for current user
echo "<h3>📊 Current User Notification Count:</h3>";
$count = getUnreadNotificationsCount($_SESSION['user_id'], $user_role);
echo "<p>Unread notifications for current user: <strong>" . $count . "</strong></p>";

// Show notifications for current user
echo "<h3>📋 Notifications for Current User:</h3>";
$notifications = getNotifications($_SESSION['user_id'], 5, 0, $user_role);

if (count($notifications) > 0) {
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>ID</th><th>User ID</th><th>Title</th><th>Type</th><th>Read</th><th>Created</th></tr>";
    foreach ($notifications as $notif) {
        $read_status = $notif['is_read'] ? '✅ Read' : '❌ Unread';
        $row_color = $notif['user_id'] == $_SESSION['user_id'] ? 'background-color: #e8f5e8;' : 'background-color: #ffe8e8;';
        echo "<tr style='$row_color'>";
        echo "<td>" . $notif['id'] . "</td>";
        echo "<td>" . $notif['user_id'] . "</td>";
        echo "<td>" . htmlspecialchars($notif['title']) . "</td>";
        echo "<td>" . $notif['type'] . "</td>";
        echo "<td>" . $read_status . "</td>";
        echo "<td>" . $notif['created_at'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No notifications found for current user.</p>";
}

// Show all notifications in database
echo "<h3>🗄️ All Notifications in Database:</h3>";
$sql = "SELECT * FROM notifications ORDER BY created_at DESC LIMIT 10";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>ID</th><th>User ID</th><th>Title</th><th>Type</th><th>Read</th><th>Created</th></tr>";
    while ($row = $result->fetch_assoc()) {
        $read_status = $row['is_read'] ? '✅ Read' : '❌ Unread';
        $row_color = $row['user_id'] == $_SESSION['user_id'] ? 'background-color: #e8f5e8;' : 'background-color: #ffe8e8;';
        echo "<tr style='$row_color'>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['user_id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['title']) . "</td>";
        echo "<td>" . $row['type'] . "</td>";
        echo "<td>" . $read_status . "</td>";
        echo "<td>" . $row['created_at'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No notifications found in database.</p>";
}

echo "<h3>🎯 Expected Notification Flow:</h3>";
echo "<h4>📝 Student/Teacher submits form (borrowform_stutea.php):</h4>";
echo "<ul>";
echo "<li>✅ Student gets 'form_submitted' notification (their user_id)</li>";
echo "<li>✅ Superadmin gets 'new_form' notification (user_id = 1)</li>";
echo "</ul>";

echo "<h4>👨‍💼 Admin updates form status (borrowform.php):</h4>";
echo "<ul>";
echo "<li>✅ Student gets status notification (their user_id from form)</li>";
echo "<li>✅ Superadmin gets status notification (user_id = 1)</li>";
echo "</ul>";

echo "<p><a href='dashboard_stutea.php'>Go to Student Dashboard</a> | <a href='dashboard_superadmin.php'>Go to Admin Dashboard</a> | <a href='borrowform_stutea.php'>Test Student Form</a> | <a href='borrowform.php'>Test Admin Form</a></p>";

$conn->close();
?> 