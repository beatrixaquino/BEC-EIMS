<?php
session_start();
include_once "dbconnect.php";

echo "<h2>🔍 User ID Implementation Debug</h2>";

// ✅ 1. Check if session stores the logged-in user ID
echo "<h3>✅ 1. Session Check:</h3>";
if (isset($_SESSION['user_id'])) {
    echo "<p style='color: green;'>✅ Session user_id: " . $_SESSION['user_id'] . "</p>";
    echo "<p>Username: " . ($_SESSION['username'] ?? 'Not set') . "</p>";
    echo "<p>Account Type: " . ($_SESSION['acctype'] ?? 'Not set') . "</p>";
} else {
    echo "<p style='color: red;'>❌ No user_id in session. Please login first.</p>";
    echo "<p><a href='login.php'>Go to Login</a></p>";
}

// ✅ 2. Check database structure
echo "<h3>✅ 2. Database Structure Check:</h3>";
$sql = "DESCRIBE borrowers";
$result = $conn->query($sql);

if ($result) {
    $has_user_id = false;
    while ($row = $result->fetch_assoc()) {
        if ($row['Field'] === 'user_id') {
            $has_user_id = true;
            echo "<p style='color: green;'>✅ user_id column exists: " . $row['Type'] . "</p>";
        }
    }
    if (!$has_user_id) {
        echo "<p style='color: red;'>❌ user_id column not found. Run run_add_user_id.sql first.</p>";
    }
} else {
    echo "<p style='color: red;'>❌ Error checking table structure: " . $conn->error . "</p>";
}

// ✅ 3. Check recent borrower forms
echo "<h3>✅ 3. Recent Borrower Forms:</h3>";
$sql = "SELECT id, firstname, lastname, user_id, created_at FROM borrowers ORDER BY created_at DESC LIMIT 5";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>ID</th><th>Name</th><th>User ID</th><th>Created</th></tr>";
    while ($row = $result->fetch_assoc()) {
        $user_id_status = $row['user_id'] ? "✅ " . $row['user_id'] : "❌ NULL";
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['firstname'] . ' ' . $row['lastname']) . "</td>";
        echo "<td>" . $user_id_status . "</td>";
        echo "<td>" . $row['created_at'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No borrower forms found.</p>";
}

// ✅ 4. Test query for current user's forms
if (isset($_SESSION['user_id'])) {
    echo "<h3>✅ 4. Current User's Forms:</h3>";
    $sql = "SELECT * FROM borrowers WHERE user_id = ? ORDER BY created_at DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        echo "<p style='color: green;'>✅ Found " . $result->num_rows . " forms for user ID " . $_SESSION['user_id'] . "</p>";
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>ID</th><th>Name</th><th>Status</th><th>Created</th></tr>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row['id'] . "</td>";
            echo "<td>" . htmlspecialchars($row['firstname'] . ' ' . $row['lastname']) . "</td>";
            echo "<td>" . $row['status'] . "</td>";
            echo "<td>" . $row['created_at'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p style='color: orange;'>⚠️ No forms found for user ID " . $_SESSION['user_id'] . "</p>";
    }
}

// ✅ 5. Check users table
echo "<h3>✅ 5. Available Users:</h3>";
$sql = "SELECT id, username, acctype, status FROM users ORDER BY id";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>ID</th><th>Username</th><th>Type</th><th>Status</th></tr>";
    while ($row = $result->fetch_assoc()) {
        $current_user = (isset($_SESSION['user_id']) && $_SESSION['user_id'] == $row['id']) ? " 👤" : "";
        echo "<tr>";
        echo "<td>" . $row['id'] . $current_user . "</td>";
        echo "<td>" . htmlspecialchars($row['username']) . "</td>";
        echo "<td>" . $row['acctype'] . "</td>";
        echo "<td>" . $row['status'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No users found.</p>";
}

echo "<h3>🎯 Summary:</h3>";
if (isset($_SESSION['user_id'])) {
    echo "<p style='color: green;'>✅ Session is working - User ID: " . $_SESSION['user_id'] . "</p>";
} else {
    echo "<p style='color: red;'>❌ Session not working - Please login</p>";
}

echo "<p><a href='run_add_user_id.sql'>Run Database Update</a> | <a href='login.php'>Login</a> | <a href='borrowform_stutea.php'>Test Form Submission</a></p>";

$conn->close();
?> 