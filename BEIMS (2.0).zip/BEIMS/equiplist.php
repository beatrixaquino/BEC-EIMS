<?php
session_start();
ob_start();
include_once "dbconnect.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = isset($_POST['id']) && !empty($_POST['id']) ? intval($_POST['id']) : null;

    $itemname = $_POST['itemname'];
    $specification = $_POST['specification'];
    $itemcategory = !empty($_POST['itemcategory']) ? $_POST['itemcategory'] : 'Uncategorized';
    $quantityreq = intval($_POST['quantityreq']);
    $unit_req = !empty($_POST['unit_req']) ? $_POST['unit_req'] : 'pcs';
    $quantityon = isset($_POST['quantityon']) && $_POST['quantityon'] !== '' ? intval($_POST['quantityon']) : 0;
    $unit_on = !empty($_POST['unit_on']) ? $_POST['unit_on'] : 'pcs';

    $difference = !empty($_POST['difference']) ? $_POST['difference'] : null;
    $remarks = !empty($_POST['remarks']) ? $_POST['remarks'] : null;
    $itemdescription = !empty($_POST['itemdescription']) ? $_POST['itemdescription'] : null;

    $complianceauditone = isset($_POST['complianceauditone']) && $_POST['complianceauditone'] !== '' ? intval($_POST['complianceauditone']) : null;
    $unit1 = !empty($_POST['unit1']) ? $_POST['unit1'] : null;

    $complianceaudittwo = isset($_POST['complianceaudittwo']) && $_POST['complianceaudittwo'] !== '' ? intval($_POST['complianceaudittwo']) : null;
    $unit2 = !empty($_POST['unit2']) ? $_POST['unit2'] : null;

    // File upload
    $eqpphoto = null;
    if (isset($_FILES['eqpphoto']) && $_FILES['eqpphoto']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = 'uploads/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        $fileName = time() . "_" . basename($_FILES['eqpphoto']['name']);
        $targetFilePath = $uploadDir . $fileName;

        if (move_uploaded_file($_FILES['eqpphoto']['tmp_name'], $targetFilePath)) {
            $eqpphoto = $fileName;
        }
    }

    // UPDATE
    if ($id) {
        $sql = "UPDATE item_list SET 
            itemname=?, specification=?, itemcategory=?, quantityreq=?, unit_req=?, quantityon=?, unit_on=?, 
            difference=?, remarks=?, itemdescription=?, complianceauditone=?, unit1=?, complianceaudittwo=?, unit2=?";
        if ($eqpphoto) {
            $sql .= ", eqpphoto=?";
        }
        $sql .= " WHERE id=?";

        $stmt = $conn->prepare($sql);

        if (!$stmt) {
            $_SESSION['message'] = "Prepare failed: " . $conn->error;
            header("Location: equiplist.php");
            exit();
        }

        if ($eqpphoto) {
            $stmt->bind_param(
                "sssisisssssiissi",
                $itemname,
                $specification,
                $itemcategory,
                $quantityreq,
                $unit_req,
                $quantityon,
                $unit_on,
                $difference,
                $remarks,
                $itemdescription,
                $complianceauditone,
                $unit1,
                $complianceaudittwo,
                $unit2,
                $eqpphoto,
                $id
            );
        } else {
            $stmt->bind_param(
                "sssisisssssiisi",
                $itemname,
                $specification,
                $itemcategory,
                $quantityreq,
                $unit_req,
                $quantityon,
                $unit_on,
                $difference,
                $remarks,
                $itemdescription,
                $complianceauditone,
                $unit1,
                $complianceaudittwo,
                $unit2,
                $id
            );
        }


        // INSERT
    } else {
        $sql = "INSERT INTO item_list (
        itemname, specification, itemcategory, quantityreq, unit_req, quantityon, unit_on, 
        difference, remarks, itemdescription, complianceauditone, unit1, complianceaudittwo, unit2, eqpphoto
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);

        if (!$stmt) {
            file_put_contents("debug_log.txt", "ERROR: Prepare failed - " . $conn->error . "\n", FILE_APPEND);
            $_SESSION['message'] = "Prepare failed: " . $conn->error;
            header("Location: equiplist.php");
            exit();
        }

        $stmt->bind_param(
            "sssisisssisisss",
            $itemname,
            $specification,
            $itemcategory,
            $quantityreq,
            $unit_req,
            $quantityon,
            $unit_on,
            $difference,
            $remarks,
            $itemdescription,
            $complianceauditone,
            $unit1,
            $complianceaudittwo,
            $unit2,
            $eqpphoto
        );
    }
    if ($stmt->execute()) {
        file_put_contents("debug_log.txt", "Data inserted/updated successfully\n", FILE_APPEND);
        $_SESSION['message'] = $id ? "Item updated successfully!" : "Item added successfully!";
    } else {
        file_put_contents("debug_log.txt", "ERROR: " . $stmt->error . "\n", FILE_APPEND);
        $_SESSION['message'] = "Database operation failed: " . $stmt->error;
    }


    $stmt->close();
    header("Location: equiplist.php");
    exit();
}

// DELETE item
if (isset($_GET['delete'])) {
    $deleteId = intval($_GET['delete']);
    $delQuery = "DELETE FROM item_list WHERE id=?";
    $stmt = $conn->prepare($delQuery);
    $stmt->bind_param("i", $deleteId);
    $stmt->execute();
    $stmt->close();
    $_SESSION['message'] = "Item deleted successfully.";
    header("Location: equiplist.php");
    exit();
}

// Fetch items
$sql = "SELECT * FROM item_list ORDER BY created_at DESC";
$result = $conn->query($sql);

ob_end_flush();
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="istyle.css">
    <title>AdminHub</title>
</head>

<body data-page="equiplist">

    <!-- SIDEBAR -->
    <section id="sidebar">
        <a href="#" class="brand">
            <i class='bx bxs-package'></i>
            <span class="text">BEC EIMS</span>
        </a>
        <ul class="side-menu top">
            <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'dashboard_superadmin.php' ? 'active' : ''; ?>">
                <a href="dashboard_superadmin.php">
                    <i class='bx bxs-dashboard'></i>
                    <span class="text">Dashboard</span>
                </a>
            </li>
            <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'usermng.php' ? 'active' : ''; ?>">
                <a href="usermng.php">
                    <i class='bx bx-group'></i>
                    <span class="text">User Management</span>
                </a>
            </li>
            <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'borrowform.php' ? 'active' : ''; ?>">
                <a href="borrowform.php">
                <i class='bx bx-clipboard'></i>
                    <span class="text">Borrowers Forms</span>
                </a>
            </li>
            <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'equiplist.php' ? 'active' : ''; ?>">
                <a href="equiplist.php">
                <i class='bx bxs-wrench' ></i>
                    <span class="text">Equipment List</span>
                </a>
            </li>
        </ul>
        <ul class="side-menu">
            <li>
                <a href="login.php" class="logout">
                    <i class='bx bxs-log-out'></i>
                    <span class="text">Logout</span>
                </a>
            </li>
        </ul>
    </section>
    <!-- SIDEBAR -->


    <!-- CONTENT -->
    <section id="content">
        <nav>
            <i class='bx bx-menu'></i>
            <a href="#" class="nav-link">Categories</a>
            <form id="globalSearchForm" action="#" autocomplete="off">
                <div class="form-input">
                    <input type="search" id="globalSearchInput" placeholder="Search...">
                    <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
                </div>
            </form>
            <input type="checkbox" id="switch-mode" hidden>
            <label for="switch-mode" class="switch-mode"></label>
            <a href="#" class="notification">
                <i class='bx bxs-bell'></i>
                <span class="num">8</span>
            </a>
            <a href="#" class="profile">
                <img src="img/people.png">
            </a>
        </nav>

        <main>
            <div class="head-title">
                <div class="left">
                    <h1>Equipment List</h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="">Equipment List</a>
                        </li>
                        <li><i class='bx bx-chevron-right'></i></li>
                        <li>
                            <a class="active" href="+">Form</a>
                        </li>
                    </ul>
                </div>
                <a href="#" class="btn-download" onclick="">
                    <i class='bx bxs-report'></i>
                    <span class="text">Generate Report</span>
                </a>
            </div>

            <div class="table-data">
                <div class="order">
                    <div class="head">
                        <h3>List of Equipment</h3>
                        <i class='bx bx-filter' id="filterBtn"></i>
                        <i class='bx bx-folder-plus' id="addCategoryBtn" style="cursor:pointer;"></i>
                        <!-- Place filter buttons here -->
                    </div>

                    <div class="filter-group" id="filterGroup">
                        <button class="filter-option" data-category="all">All</button>
                        <button class="filter-option" data-category="Supplies and Materials">Supplies and Materials</button>
                        <button class="filter-option" data-category="Equipment">Equipment</button>
                        <button class="filter-option" data-category="Tools">Tools</button>
                    </div>

                    <div class="equipment-grid">
                        <?php if ($result->num_rows > 0): ?>
                            <?php while ($row = $result->fetch_assoc()): ?>
                                <div class="equipment-card" data-category="<?php echo htmlspecialchars($row['itemcategory']); ?>">
                                    <img src="uploads/<?php echo htmlspecialchars($row['eqpphoto'] ?? 'placeholder.png'); ?>" alt="Equipment Image" class="equipment-img">
                                    <h4><?php echo htmlspecialchars($row['itemname']); ?></h4>
                                    <p><strong>Category:</strong> <?php echo htmlspecialchars($row['itemcategory']); ?></p>
                                    <p><strong>Available:</strong> <?php echo htmlspecialchars($row['quantityon']); ?> <?php echo htmlspecialchars($row['unit_on']); ?></p>
                                    <div class="card-actions">
                                        <button class="btn-view-card" data-id="<?php echo $row['id']; ?>">View</button>
                                        <button class="btn-edit-card" data-id="<?php echo $row['id']; ?>">Edit</button>
                                        <button class="btn-delete-card" data-id="<?php echo $row['id']; ?>">Delete</button>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <p>No equipment available.</p>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="todo">
                    <div class="head">
                        <h3>Add New Equipment</h3>
                    </div>

                    <form id="itemDetailsForm" action="equiplist.php" method="POST" enctype="multipart/form-data">
                        <input type="hidden" id="equiplist" name="id">

                        <div class="form-group">
                            <label for="itemname">Item Name</label>
                            <div class="input-group">
                                <input type="text" id="itemname" name="itemname" placeholder="Item Name">
                                <i class='bx bxs-label'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="specification">Item Specification</label>
                            <div class="input-group">
                                <input type="text" id="specification" name="specification" placeholder="Item Specification">
                                <i class='bx bx-detail'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="itemcategory">Item Categorization</label>
                            <div class="input-group" style="display: flex; align-items: center;">
                                <select id="itemcategory" name="itemcategory">
                                    <option value="Uncategorized">Uncategorized</option>
                                    <?php
                                    $catResult = $conn->query("SELECT name FROM categories ORDER BY name ASC");
                                    while ($catRow = $catResult->fetch_assoc()) {
                                        echo '<option value="' . htmlspecialchars($catRow['name']) . '">' . htmlspecialchars(ucfirst($catRow['name'])) . '</option>';
                                    }
                                    ?>
                                </select>
                                <i class='bx bx-folder-plus' id="addCategoryBtn" style="margin-left:8px; cursor:pointer; font-size:1.3rem;" title="Add Category"></i>
                                <i class='bx bx-chevron-down'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="quantityreq">Quantity Required</label>
                            <div class="quantity-wrapper">
                                <input type="number" id="quantityreq" name="quantityreq" placeholder="0" min="1">
                                <select id="unit_req" name="unit_req">
                                    <option value="pcs">pcs</option>
                                    <option value="sets">sets</option>
                                    <option value="units">units</option>
                                    <option value="box">box</option>
                                    <option value="others">others</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="quantityon">Quantity on Site</label>
                            <div class="quantity-wrapper">
                                <input type="number" id="quantityon" name="quantityon" placeholder="0" min="1">
                                <select id="unit_on" name="unit_on">
                                    <option value="pcs">pcs</option>
                                    <option value="sets">sets</option>
                                    <option value="units">units</option>
                                    <option value="box">box</option>
                                    <option value="others">others</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="difference">Difference</label>
                            <div class="input-group">
                                <input type="text" id="difference" name="difference" placeholder="Difference">
                                <i class='bx bxs-calculator'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="remarks">Inspectors Remarks</label>
                            <div class="input-group">
                                <input type="text" id="remarks" name="remarks" placeholder="Inspector Remarks">
                                <i class='bx bx-comment-detail'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="itemdescription">Item Description</label>
                            <div class="input-group">
                                <input type="text" id="itemdescription" name="itemdescription" placeholder="Item Description">
                                <i class='bx bx-file-blank'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="complianceauditone">Quantity onsite during Compliance Audit Year 1</label>
                            <div class="quantity-wrapper">
                                <input type="number" id="complianceauditone" name="complianceauditone" placeholder="0" min="1">
                                <select id="unit1" name="unit1">
                                    <option value="pcs">pcs</option>
                                    <option value="sets">sets</option>
                                    <option value="units">units</option>
                                    <option value="box">box</option>
                                    <option value="others">others</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="complianceaudittwo">Quantity onsite during Compliance Audit Year 2</label>
                            <div class="quantity-wrapper">
                                <input type="number" id="complianceaudittwo" name="complianceaudittwo" placeholder="0" min="1">
                                <select id="unit2" name="unit2">
                                    <option value="pcs">pcs</option>
                                    <option value="sets">sets</option>
                                    <option value="units">units</option>
                                    <option value="box">box</option>
                                    <option value="others">others</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="eqpphoto">Equipment Image</label>
                            <div class="upload-container">
                                <div class="upload-preview">
                                    <img id="eqpphoto-preview" src="#" alt="Equipment Photo" style="display:none;">
                                </div>
                                <label for="eqpphoto" class="upload-box">
                                    <div class="upload-icon">
                                        <i class='bx bx-cloud-upload'></i>
                                        <p>Upload Image</p>
                                        <p class="file-size-note">Image size must be less than 2MB</p>
                                    </div>
                                </label>
                                <input type="file" id="eqpphoto" name="eqpphoto" style="display: none;" onchange="previewImage(event, 'eqpphoto-preview')">
                            </div>
                        </div>

                        <button type="submit" class="btn-submit">Submit</button>
                    </form>

                </div>
            </div>
        </main>
    </section>

    <!-- Add Category Modal -->
    <div id="addCategoryModal" class="modal" style="display:none;">
        <div class="modal-content" style="background:#fff; padding:20px; border-radius:8px; max-width:400px; margin:auto; position:relative;">
            <span id="closeCategoryModal" style="position:absolute; top:10px; right:15px; cursor:pointer; font-size:20px;">&times;</span>
            <h3>Add New Category</h3>
            <form id="addCategoryForm">
                <input type="text" id="newCategoryName" placeholder="Category Name" required style="width:100%; padding:8px; margin-bottom:10px;">
                <button type="submit" style="padding:8px 16px;">Add Category</button>
            </form>
            <div id="addCategoryMsg" style="color:green; margin-top:10px;"></div>
        </div>
    </div>

    <script>
        function previewImage(event, previewId) {
            const input = event.target;
            const preview = document.getElementById(previewId);

            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.style.display = "block";
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        document.addEventListener("DOMContentLoaded", () => {
            // Handle EDIT button
            document.querySelectorAll(".btn-edit-card").forEach(btn => {
                btn.addEventListener("click", function(e) {
                    e.stopPropagation(); // Prevent row click
                    const itemId = this.getAttribute("data-id");

                    fetch(`fetch_equipment_info.php?id=${itemId}`)
                        .then(response => response.json())
                        .then(data => {
                            if (data.error) {
                                alert(data.error);
                            } else {
                                // Fill the form with the fetched data
                                document.getElementById("equiplist").value = data.id;
                                document.getElementById("itemname").value = data.itemname;
                                document.getElementById("specification").value = data.specification;
                                document.getElementById("itemcategory").value = data.itemcategory;
                                document.getElementById("quantityreq").value = data.quantityreq;
                                document.getElementById("unit_req").value = data.unit_req;
                                document.getElementById("quantityon").value = data.quantityon;
                                document.getElementById("unit_on").value = data.unit_on;
                                document.getElementById("difference").value = data.difference;
                                document.getElementById("remarks").value = data.remarks;
                                document.getElementById("itemdescription").value = data.itemdescription;
                                document.getElementById("complianceauditone").value = data.complianceauditone;
                                document.getElementById("unit1").value = data.unit1;
                                document.getElementById("complianceaudittwo").value = data.complianceaudittwo;
                                document.getElementById("unit2").value = data.unit2;

                                if (data.eqpphoto) {
                                    const preview = document.getElementById("eqpphoto-preview");
                                    preview.src = `uploads/${data.eqpphoto}`;
                                    preview.style.display = "block";
                                }
                            }
                        });
                });
            });

            // Handle DELETE button
            document.querySelectorAll(".btn-delete-card").forEach(btn => {
                btn.addEventListener("click", function(e) {
                    e.stopPropagation(); // Prevent row click
                    const itemId = this.getAttribute("data-id");

                    if (confirm("Are you sure you want to delete this equipment?")) {
                        fetch(`delete_equipment.php?id=${itemId}`, {
                                method: "POST"
                            })
                            .then(response => response.json())
                            .then(data => {
                                if (data.success) {
                                    alert("Item deleted successfully!");
                                    location.reload(); // Refresh the table
                                } else {
                                    alert("Error deleting item: " + data.error);
                                }
                            });
                    }
                });
            });

            // Filter button logic
            const filterOptions = document.querySelectorAll(".filter-option");
            const equipmentCards = document.querySelectorAll(".equipment-card");

            filterOptions.forEach(btn => {
                btn.addEventListener("click", function() {
                    // Remove active class from all
                    filterOptions.forEach(b => b.classList.remove("active"));
                    this.classList.add("active");

                    const category = this.getAttribute("data-category");
                    equipmentCards.forEach(card => {
                        if (category === "all" || card.getAttribute("data-category") === category) {
                            card.style.display = "";
                        } else {
                            card.style.display = "none";
                        }
                    });
                });
            });

            const filterBtn = document.getElementById("filterBtn");
            const filterGroup = document.getElementById("filterGroup");

            // Start hidden
            filterGroup.classList.add("hide");

            filterBtn.addEventListener("click", function(e) {
                e.stopPropagation();
                filterGroup.classList.toggle("hide");
            });

            // Hide filter group when clicking outside
            document.addEventListener("click", function(e) {
                if (!filterGroup.contains(e.target) && e.target !== filterBtn) {
                    filterGroup.classList.add("hide");
                }
            });

            // Universal search for equipment cards
            const globalSearchForm = document.getElementById("globalSearchForm");
            const globalSearchInput = document.getElementById("globalSearchInput");

            if (globalSearchForm && globalSearchInput) {
                globalSearchForm.addEventListener("submit", function(e) {
                    e.preventDefault();
                    const query = globalSearchInput.value.trim().toLowerCase();
                    const equipmentCards = document.querySelectorAll(".equipment-card");
                    if (equipmentCards.length > 0) {
                        equipmentCards.forEach(card => {
                            const name = card.querySelector("h4").textContent.toLowerCase();
                            const category = card.getAttribute("data-category").toLowerCase();
                            const spec = card.querySelector("p") ? card.querySelector("p").textContent.toLowerCase() : "";
                            if (name.includes(query) || category.includes(query) || spec.includes(query)) {
                                card.style.display = "";
                            } else {
                                card.style.display = "none";
                            }
                        });
                    }
                });

                // Optional: Live search as you type
                globalSearchInput.addEventListener("input", function() {
                    const query = globalSearchInput.value.trim().toLowerCase();
                    const equipmentCards = document.querySelectorAll(".equipment-card");
                    if (equipmentCards.length > 0) {
                        equipmentCards.forEach(card => {
                            const name = card.querySelector("h4").textContent.toLowerCase();
                            const category = card.getAttribute("data-category").toLowerCase();
                            const spec = card.querySelector("p") ? card.querySelector("p").textContent.toLowerCase() : "";
                            if (name.includes(query) || category.includes(query) || spec.includes(query)) {
                                card.style.display = "";
                            } else {
                                card.style.display = "none";
                            }
                        });
                    }
                });
            }

            // Modal logic
            const addCategoryBtn = document.getElementById("addCategoryBtn");
            const addCategoryModal = document.getElementById("addCategoryModal");
            const closeCategoryModal = document.getElementById("closeCategoryModal");
            const addCategoryForm = document.getElementById("addCategoryForm");
            const newCategoryName = document.getElementById("newCategoryName");
            const addCategoryMsg = document.getElementById("addCategoryMsg");
            const itemCategorySelect = document.getElementById("itemcategory");

            addCategoryBtn.addEventListener("click", function(e) {
                e.preventDefault(); // Prevent form submission
                e.stopPropagation(); // Prevent bubbling
                addCategoryModal.style.display = "block";
                addCategoryMsg.textContent = "";
                newCategoryName.value = "";
                newCategoryName.focus();
            });

            closeCategoryModal.addEventListener("click", function() {
                addCategoryModal.style.display = "none";
            });

            window.addEventListener("click", function(event) {
                if (event.target == addCategoryModal) {
                    addCategoryModal.style.display = "none";
                }
            });

            // AJAX to add category
            addCategoryForm.addEventListener("submit", function(e) {
                e.preventDefault(); // Prevents any form submission
                const category = newCategoryName.value.trim();
                if (!category) return;

                fetch('add_category.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'category=' + encodeURIComponent(category)
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        addCategoryMsg.textContent = "Category added!";
                        // Add new option to select
                        const option = document.createElement("option");
                        option.value = category;
                        option.textContent = category.charAt(0).toUpperCase() + category.slice(1);
                        itemCategorySelect.appendChild(option);
                        itemCategorySelect.value = category;
                        setTimeout(() => {
                            addCategoryModal.style.display = "none";
                        }, 800);
                    } else {
                        addCategoryMsg.textContent = data.error || "Error adding category.";
                        addCategoryMsg.style.color = "red";
                    }
                })
                .catch(() => {
                    addCategoryMsg.textContent = "Error connecting to server.";
                    addCategoryMsg.style.color = "red";
                });
            });
        });
    </script>
</body>

</html>
