<?php
$host = "localhost";  // Your MySQL host
$username = "root";  // Default XAMPP MySQL username
$password = ""; // Your MySQL password
$database = "beims"; // Replace with your actual database name

// Create a connection
$conn = mysqli_connect($host, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}
?>
