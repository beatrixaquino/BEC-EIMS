-- Use the database
USE my_database;

SELECT * FROM users;
