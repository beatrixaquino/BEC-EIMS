<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Output as JSON
header('Content-Type: application/json');

// Include the database connection
include_once "dbconnect.php";

// Check if the 'id' is passed via GET request
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);  // Sanitize input

    $sql = "SELECT * FROM borrowers WHERE id = ?";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        echo json_encode(["error" => "Query preparation failed: " . $conn->error]);
        exit();
    }

    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $data = $result->fetch_assoc();
        
        // Also fetch requested items for this borrower
        $items_sql = "SELECT * FROM requested_items WHERE borrower_id = ?";
        $items_stmt = $conn->prepare($items_sql);
        $items_stmt->bind_param("i", $id);
        $items_stmt->execute();
        $items_result = $items_stmt->get_result();
        
        $requested_items = [];
        while ($item = $items_result->fetch_assoc()) {
            $requested_items[] = $item;
        }
        
        $data['requested_items'] = $requested_items;
        
        echo json_encode($data);
    } else {
        echo json_encode(["error" => "No data found for this ID."]);
    }

    $stmt->close();
    if (isset($items_stmt)) {
        $items_stmt->close();
    }
} else {
    echo json_encode(["error" => "No ID provided."]);
}

$conn->close();
?> 