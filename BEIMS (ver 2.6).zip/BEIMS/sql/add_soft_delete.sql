-- Add soft delete column to borrowers table
ALTER TABLE borrowers ADD COLUMN deleted_at TIMESTAMP NULL DEFAULT NULL;

-- Add index for better performance when filtering deleted records
ALTER TABLE borrowers ADD INDEX idx_deleted_at (deleted_at);

-- Show the updated table structure
DESCRIBE borrowers; 