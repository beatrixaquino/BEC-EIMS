-- Keep the status enum as 'approved' and update PHP code to match
-- The database already has the correct enum values

-- Step 1: Check current status values
SELECT DISTINCT status FROM borrowers;

-- Step 2: Verify the enum is correct (should already be correct)
-- The enum should be: ENUM('pending', 'approved', 'rejected', 'returned')

-- Step 3: Verify the changes
SELECT DISTINCT status FROM borrowers;
DESCRIBE borrowers; 