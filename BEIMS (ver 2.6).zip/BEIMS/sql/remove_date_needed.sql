-- Remove date_needed column from requested_items table
ALTER TABLE requested_items DROP COLUMN date_needed;

-- Show the updated table structure
DESCRIBE requested_items; 