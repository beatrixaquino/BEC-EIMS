-- Create notifications table
CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('new_form', 'form_approved', 'form_rejected', 'form_submitted', 'equipment_added', 'equipment_updated', 'user_registered') NOT NULL,
    related_id INT, -- ID of the related record (form_id, equipment_id, etc.)
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_is_read (is_read),
    INDEX idx_type (type),
    INDEX idx_created_at (created_at)
);

-- Insert some sample notifications for testing
INSERT INTO notifications (user_id, title, message, type, related_id) VALUES
(1, 'New Borrow Form Submitted', 'A new borrow form has been submitted by John Doe', 'new_form', 1),
(1, 'Form Approved', 'Borrow form #123 has been approved', 'form_approved', 123),
(1, 'Equipment Added', 'New equipment "Laptop" has been added to the system', 'equipment_added', 5); 