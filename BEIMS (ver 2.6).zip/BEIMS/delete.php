<?php
// Include the database connection
include_once "dbconnect.php";

// Delete the account if the ID is provided
if (isset($_POST['id'])) {
    $id = $_POST['id'];

    $sql = "DELETE FROM admin_accounts WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();

    // Redirect back to the admin management page
    header("Location: adminmng.php");
    exit();
}
?>