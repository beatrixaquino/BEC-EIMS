// Centralized notification functionality
document.addEventListener('DOMContentLoaded', function() {
    try {
        console.log('Notification.js loaded');
        
        const notificationIcon = document.getElementById('notificationIcon');
        const notificationDropdown = document.getElementById('notificationDropdown');
        const notificationCount = document.getElementById('notificationCount');
        const notificationList = document.getElementById('notificationList');
        const markAllReadBtn = document.getElementById('markAllRead');

        console.log('Notification elements found:', {
            notificationIcon: !!notificationIcon,
            notificationDropdown: !!notificationDropdown,
            notificationCount: !!notificationCount,
            notificationList: !!notificationList,
            markAllReadBtn: !!markAllReadBtn
        });

        // Check if notification elements exist
        if (!notificationIcon || !notificationDropdown || !notificationCount || !notificationList) {
            console.log('Notification elements not found, skipping notification setup');
            return;
        }

    // Load notification count
    function loadNotificationCount() {
        console.log('Loading notification count...');
        fetch('get_notifications.php?action=count')
            .then(response => {
                console.log('Notification count response status:', response.status);
                return response.json();
            })
            .then(data => {
                console.log('Notification count data:', data);
                if (data.count > 0) {
                    notificationCount.textContent = data.count;
                    notificationCount.style.display = 'block';
                } else {
                    notificationCount.style.display = 'none';
                }
            })
            .catch(error => console.error('Error loading notification count:', error));
    }

    // Load notifications
    function loadNotifications() {
        console.log('Loading notifications...');
        fetch('get_notifications.php?action=list&limit=10')
            .then(response => {
                console.log('Notification list response status:', response.status);
                return response.json();
            })
            .then(data => {
                console.log('Notification list data:', data);
                notificationList.innerHTML = '';
                if (data.notifications && data.notifications.length > 0) {
                    data.notifications.forEach(notification => {
                        const isRead = notification.is_read ? 'read' : 'unread';
                        const timeAgo = getTimeAgo(notification.created_at);
                        const notificationItem = document.createElement('div');
                        notificationItem.className = `notification-item ${isRead}`;
                        notificationItem.setAttribute('data-id', notification.id);
                        notificationItem.innerHTML = `
                            <div class="notification-content">
                                <h5>${notification.title || 'Notification'}</h5>
                                <p>${notification.message}</p>
                                <small>${timeAgo}</small>
                            </div>
                            ${!notification.is_read ? '<div class="unread-indicator"></div>' : ''}
                        `;
                        notificationList.appendChild(notificationItem);
                    });
                } else {
                    notificationList.innerHTML = '<div class="no-notifications">No notifications</div>';
                }
            })
            .catch(error => console.error('Error loading notifications:', error));
    }

    // Get time ago
    function getTimeAgo(timestamp) {
        const now = new Date();
        const created = new Date(timestamp);
        const diffInSeconds = Math.floor((now - created) / 1000);
        
        if (diffInSeconds < 60) return 'Just now';
        if (diffInSeconds < 3600) return Math.floor(diffInSeconds / 60) + 'm ago';
        if (diffInSeconds < 86400) return Math.floor(diffInSeconds / 3600) + 'h ago';
        return Math.floor(diffInSeconds / 86400) + 'd ago';
    }

    // Toggle notification dropdown
    notificationIcon.addEventListener('click', function(e) {
        e.preventDefault();
        const isVisible = notificationDropdown.style.display === 'block';
        notificationDropdown.style.display = isVisible ? 'none' : 'block';
        if (!isVisible) {
            loadNotifications();
        }
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
        if (!notificationIcon.contains(e.target) && !notificationDropdown.contains(e.target)) {
            notificationDropdown.style.display = 'none';
        }
    });

    // Mark all as read
    if (markAllReadBtn) {
        markAllReadBtn.addEventListener('click', function() {
            fetch('get_notifications.php?action=mark_all_read', {
                method: 'POST'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    loadNotificationCount();
                    loadNotifications();
                }
            })
            .catch(error => console.error('Error marking all as read:', error));
        });
    }

    // Mark individual notification as read
    notificationList.addEventListener('click', function(e) {
        const notificationItem = e.target.closest('.notification-item');
        if (notificationItem && !notificationItem.classList.contains('read')) {
            const notificationId = notificationItem.getAttribute('data-id');
            fetch('get_notifications.php?action=mark_read', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'notification_id=' + notificationId
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    notificationItem.classList.add('read');
                    notificationItem.classList.remove('unread');
                    const unreadIndicator = notificationItem.querySelector('.unread-indicator');
                    if (unreadIndicator) {
                        unreadIndicator.remove();
                    }
                    loadNotificationCount();
                }
            })
            .catch(error => console.error('Error marking notification as read:', error));
        }
    });

    // Load initial notification count
    loadNotificationCount();
    } catch (error) {
        console.error('Error in notification system:', error);
    }
}); 