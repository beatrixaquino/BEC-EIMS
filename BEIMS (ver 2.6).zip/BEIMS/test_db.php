<?php
include_once "dbconnect.php";

echo "<h2>Database Connection Test</h2>";

// Test database connection
if ($conn) {
    echo "<p style='color: green;'>✅ Database connection successful</p>";
} else {
    echo "<p style='color: red;'>❌ Database connection failed</p>";
    exit();
}

// Check if notifications table exists
$result = $conn->query("SHOW TABLES LIKE 'notifications'");
if ($result->num_rows > 0) {
    echo "<p style='color: green;'>✅ Notifications table exists</p>";
    
    // Show table structure
    echo "<h3>Notifications Table Structure:</h3>";
    $result = $conn->query("DESCRIBE notifications");
    echo "<table border='1' style='border-collapse: collapse;'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['Field'] . "</td>";
        echo "<td>" . $row['Type'] . "</td>";
        echo "<td>" . $row['Null'] . "</td>";
        echo "<td>" . $row['Key'] . "</td>";
        echo "<td>" . $row['Default'] . "</td>";
        echo "<td>" . $row['Extra'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // Count notifications
    $result = $conn->query("SELECT COUNT(*) as total FROM notifications");
    $row = $result->fetch_assoc();
    echo "<p>Total notifications: " . $row['total'] . "</p>";
    
    // Show sample notifications
    $result = $conn->query("SELECT * FROM notifications ORDER BY created_at DESC LIMIT 5");
    if ($result->num_rows > 0) {
        echo "<h3>Sample Notifications:</h3>";
        echo "<table border='1' style='border-collapse: collapse;'>";
        echo "<tr><th>ID</th><th>User ID</th><th>Title</th><th>Message</th><th>Type</th><th>Is Read</th><th>Created</th></tr>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row['id'] . "</td>";
            echo "<td>" . $row['user_id'] . "</td>";
            echo "<td>" . htmlspecialchars($row['title']) . "</td>";
            echo "<td>" . htmlspecialchars(substr($row['message'], 0, 50)) . "...</td>";
            echo "<td>" . $row['type'] . "</td>";
            echo "<td>" . ($row['is_read'] ? 'Yes' : 'No') . "</td>";
            echo "<td>" . $row['created_at'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No notifications found in database.</p>";
    }
} else {
    echo "<p style='color: red;'>❌ Notifications table does not exist</p>";
    
    // Show all tables
    echo "<h3>Available Tables:</h3>";
    $result = $conn->query("SHOW TABLES");
    echo "<ul>";
    while ($row = $result->fetch_array()) {
        echo "<li>" . $row[0] . "</li>";
    }
    echo "</ul>";
}

// Test creating a notification
echo "<h3>Test Creating Notification:</h3>";
try {
    $sql = "INSERT INTO notifications (user_id, title, message, type, created_at) VALUES (1, 'Test Notification', 'This is a test notification', 'test', NOW())";
    $result = $conn->query($sql);
    
    if ($result) {
        echo "<p style='color: green;'>✅ Test notification created successfully</p>";
        
        // Get the ID of the created notification
        $notification_id = $conn->insert_id;
        echo "<p>Created notification ID: " . $notification_id . "</p>";
        
        // Clean up - delete the test notification
        $conn->query("DELETE FROM notifications WHERE id = " . $notification_id);
        echo "<p>Test notification cleaned up</p>";
    } else {
        echo "<p style='color: red;'>❌ Failed to create test notification</p>";
        echo "<p>Error: " . $conn->error . "</p>";
    }
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error creating test notification: " . $e->getMessage() . "</p>";
}
?> 