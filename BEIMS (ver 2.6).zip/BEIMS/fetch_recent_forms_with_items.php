<?php
// Enable error reporting for debugging
ini_set(display_errors', 1);
error_reporting(E_ALL);

// Output as JSON
header('Content-Type: application/json');

// Include the database connection
include_once dbconnect.php";

// Get recent borrower forms with their items
$sql = "SELECT b.*, 
        COUNT(ri.id) as total_items
        FROM borrowers b 
        LEFT JOIN requested_items ri ON b.id = ri.borrower_id 
        GROUP BY b.id 
        ORDER BY b.created_at DESC 
        LIMIT 5";

$result = $conn->query($sql);

if ($result) {
    $forms = [];
    while ($row = $result->fetch_assoc()) {
        // Get first 2-3 items for display
        $items_sql = "SELECT il.itemname, ri.quantity, ri.unit 
                      FROM requested_items ri 
                      JOIN item_list il ON ri.item_id = il.id 
                      WHERE ri.borrower_id = ? 
                      LIMIT 3       $items_stmt = $conn->prepare($items_sql);
        $items_stmt->bind_param(iow['id']);
        $items_stmt->execute();
        $items_result = $items_stmt->get_result();
        
        $display_items =;
        while ($item = $items_result->fetch_assoc()) {
            $display_items[] = $item[itemname'] . ' (' . $item['quantity] . . $item['unit'] . ')';
        }
        
        $row[display_items'] = $display_items;
        $row['items_count'] = count($display_items);
        $row[total_items'] = $rowtotal_items] ?: 0;
        
        $forms = $row;
        $items_stmt->close();
    }
    
    echo json_encode($forms);
} else {
    echo json_encode([error" => "Failed to fetch forms: " . $conn->error]);
}

$conn->close();
?> 