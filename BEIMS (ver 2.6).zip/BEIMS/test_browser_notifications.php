<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Browser Notification Test</title>
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="istyle.css">
</head>
<body>
    <div style="padding: 20px;">
        <h1>Browser Notification Test</h1>
        
        <!-- Test notification elements -->
        <div style="margin: 20px 0;">
            <a href="#" class="notification" id="notificationIcon">
                <i class='bx bxs-bell'></i>
                <span class="num" id="notificationCount">0</span>
            </a>
            <div class="notification-dropdown" id="notificationDropdown" style="display: none;">
                <div class="notification-header">
                    <h4>Notifications</h4>
                    <button id="markAllRead" class="mark-all-read">Mark all read</button>
                </div>
                <div class="notification-list" id="notificationList">
                    <!-- Notifications will be loaded here -->
                </div>
            </div>
        </div>
        
        <div style="margin: 20px 0;">
            <button onclick="testFetch()">Test Fetch API</button>
            <button onclick="testElements()">Test Elements</button>
            <button onclick="testNotificationJS()">Test Notification.js</button>
        </div>
        
        <div id="debugOutput" style="margin: 20px 0; padding: 10px; background: #f0f0f0; border: 1px solid #ccc;">
            <h3>Debug Output:</h3>
            <div id="debugContent"></div>
        </div>
    </div>

    <script src="script.js"></script>
    <script src="notification.js"></script>
    
    <script>
        function testFetch() {
            console.log('Testing fetch API...');
            document.getElementById('debugContent').innerHTML = '<p>Testing fetch API...</p>';
            
            fetch('get_notifications.php?action=count')
                .then(response => {
                    console.log('Response status:', response.status);
                    console.log('Response headers:', response.headers);
                    return response.json();
                })
                .then(data => {
                    console.log('Notification count data:', data);
                    document.getElementById('debugContent').innerHTML = 
                        `<h4>Fetch Test Results:</h4><p>Response: ${JSON.stringify(data)}</p>`;
                })
                .catch(error => {
                    console.error('Fetch error:', error);
                    document.getElementById('debugContent').innerHTML = 
                        `<h4>Fetch Test Error:</h4><p>Error: ${error.message}</p>`;
                });
        }
        
        function testElements() {
            const elements = {
                notificationIcon: document.getElementById('notificationIcon'),
                notificationDropdown: document.getElementById('notificationDropdown'),
                notificationCount: document.getElementById('notificationCount'),
                notificationList: document.getElementById('notificationList'),
                markAllRead: document.getElementById('markAllRead')
            };
            
            let output = '<h4>Element Check Results:</h4>';
            for (const [name, element] of Object.entries(elements)) {
                output += `<p>${name}: ${element ? '✅ Found' : '❌ Not found'}</p>`;
            }
            
            document.getElementById('debugContent').innerHTML = output;
        }
        
        function testNotificationJS() {
            console.log('Testing notification.js...');
            document.getElementById('debugContent').innerHTML = '<p>Testing notification.js...</p>';
            
            // Check if notification.js functions are available
            if (typeof loadNotificationCount === 'function') {
                console.log('loadNotificationCount function found');
                loadNotificationCount();
            } else {
                console.log('loadNotificationCount function not found');
            }
            
            if (typeof loadNotifications === 'function') {
                console.log('loadNotifications function found');
                loadNotifications();
            } else {
                console.log('loadNotifications function not found');
            }
        }
        
        // Check elements on page load
        document.addEventListener('DOMContentLoaded', function() {
            console.log('Page loaded, checking elements...');
            testElements();
        });
        
        // Add global error handler
        window.addEventListener('error', function(e) {
            console.error('Global error:', e.error);
            document.getElementById('debugContent').innerHTML += 
                `<p style="color: red;">Global Error: ${e.error.message}</p>`;
        });
    </script>
</body>
</html> 