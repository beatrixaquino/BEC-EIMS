<?php
session_start();
include_once "dbconnect.php";
include_once "notification_helper.php";

echo "<h2>Notification System Debug</h2>";

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "<p style='color: red;'>❌ User not logged in</p>";
    echo "<p>Session data: " . print_r($_SESSION, true) . "</p>";
} else {
    echo "<p style='color: green;'>✅ User logged in - ID: " . $_SESSION['user_id'] . "</p>";
    echo "<p>Account type: " . ($_SESSION['acctype'] ?? 'Not set') . "</p>";
}

// Test getUserRole function
$user_role = getUserRole();
echo "<p>User role: " . $user_role . "</p>";

// Check if notifications table exists
$result = $conn->query("SHOW TABLES LIKE 'notifications'");
if ($result->num_rows > 0) {
    echo "<p style='color: green;'>✅ Notifications table exists</p>";
} else {
    echo "<p style='color: red;'>❌ Notifications table does not exist</p>";
}

// Count total notifications
$result = $conn->query("SELECT COUNT(*) as total FROM notifications");
$row = $result->fetch_assoc();
echo "<p>Total notifications in database: " . $row['total'] . "</p>";

// Count unread notifications
$result = $conn->query("SELECT COUNT(*) as unread FROM notifications WHERE is_read = FALSE");
$row = $result->fetch_assoc();
echo "<p>Unread notifications: " . $row['unread'] . "</p>";

// Test the getUnreadNotificationsCount function
if (isset($_SESSION['user_id'])) {
    $count = getUnreadNotificationsCount($_SESSION['user_id'], $user_role);
    echo "<p>Unread count for current user: " . $count . "</p>";
}

// Show recent notifications
echo "<h3>Recent Notifications:</h3>";
$result = $conn->query("SELECT * FROM notifications ORDER BY created_at DESC LIMIT 10");
if ($result->num_rows > 0) {
    echo "<table border='1' style='border-collapse: collapse;'>";
    echo "<tr><th>ID</th><th>User ID</th><th>Title</th><th>Message</th><th>Type</th><th>Is Read</th><th>Created</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['user_id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['title']) . "</td>";
        echo "<td>" . htmlspecialchars($row['message']) . "</td>";
        echo "<td>" . $row['type'] . "</td>";
        echo "<td>" . ($row['is_read'] ? 'Yes' : 'No') . "</td>";
        echo "<td>" . $row['created_at'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No notifications found in database.</p>";
}

// Test the API endpoint
echo "<h3>Testing API Endpoint:</h3>";
$url = "get_notifications.php?action=count";
echo "<p>Testing: " . $url . "</p>";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_COOKIE, "PHPSESSID=" . session_id());
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "<p>HTTP Code: " . $httpCode . "</p>";
echo "<p>Response: " . htmlspecialchars($response) . "</p>";

// Test list endpoint
echo "<h3>Testing List Endpoint:</h3>";
$url = "get_notifications.php?action=list&limit=5";
echo "<p>Testing: " . $url . "</p>";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_COOKIE, "PHPSESSID=" . session_id());
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "<p>HTTP Code: " . $httpCode . "</p>";
echo "<p>Response: " . htmlspecialchars($response) . "</p>";
?> 