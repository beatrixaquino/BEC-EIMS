<?php
session_start();
include_once "dbconnect.php";
include_once "soft_delete_helper.php";

// Check if user is admin
if (!isset($_SESSION['acctype']) || !in_array($_SESSION['acctype'], ['superadmin', 'admin'])) {
    header("Location: login.php");
    exit();
}

// Handle soft delete actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    $borrower_id = intval($_POST['borrower_id'] ?? 0);
    $user_id = $_SESSION['user_id'] ?? null;
    
    switch ($action) {
        case 'restore':
            if (restoreBorrower($borrower_id, $user_id)) {
                $_SESSION['message'] = "Record restored successfully!";
            } else {
                $_SESSION['error'] = "Failed to restore record.";
            }
            break;
            
        case 'hard_delete':
            if (hardDeleteBorrower($borrower_id)) {
                $_SESSION['message'] = "Record permanently deleted!";
            } else {
                $_SESSION['error'] = "Failed to delete record.";
            }
            break;
    }
    
    header("Location: manage_deleted_records.php");
    exit();
}

// Get deleted records
$deleted_records = getDeletedBorrowers();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="istyle.css">
    <title>Manage Deleted Records</title>
</head>
<body data-page="manage_deleted_records">

<!-- SIDEBAR -->
<section id="sidebar">
    <a href="#" class="brand">
        <i class='bx bxs-package'></i>
        <span class="text">BEC EIMS</span>
    </a>
    <ul class="side-menu top">
        <li>
            <a href="dashboard_superadmin.php">
                <i class='bx bxs-dashboard'></i>
                <span class="text">Dashboard</span>
            </a>
        </li>
        <li>
            <a href="usermng.php">
                <i class='bx bx-group'></i>
                <span class="text">User Management</span>
            </a>
        </li>
        <li class="dropdown" id="borrowersDropdown">
            <a href="borrowform.php" class="dropdown-toggle">
                <i class='bx bx-clipboard'></i>
                <span class="text">Borrowers Forms</span>
                <i class='bx bx-chevron-down dropdown-arrow'></i>
            </a>
            <ul class="dropdown-menu" id="borrowersDropdownMenu">
                <li><a href="borrowform.php"><i class='bx bxs-report'></i> All Forms</a></li>
                <li><a href="manage_deleted_records.php"><i class='bx bxs-trash'></i> Deleted Records</a></li>
                <li><a href="borrowform.php?filter=pending"><i class='bx bxs-time'></i> Pending Forms</a></li>
                <li><a href="borrowform.php?filter=approved"><i class='bx bxs-check-circle'></i> Approved Forms</a></li>
                <li><a href="borrowform.php?filter=rejected"><i class='bx bxs-x-circle'></i> Rejected Forms</a></li>
                <li><a href="borrowform.php?filter=returned"><i class='bx bxs-archive'></i> Returned Forms</a></li>
            </ul>
        </li>
        <li>
            <a href="equiplist.php">
                <i class='bx bxs-wrench'></i>
                <span class="text">Equipment List</span>
            </a>
        </li>
    </ul>
    <ul class="side-menu">
        <li>
            <a href="login.php" class="logout">
                <i class='bx bxs-log-out'></i>
                <span class="text">Logout</span>
            </a>
        </li>
    </ul>
</section>

<!-- CONTENT -->
<section id="content">
    <!-- NAVBAR -->
    <nav>
        <i class='bx bx-menu'></i>
        <a href="#" class="nav-link">Categories</a>
        <form action="#">
            <div class="form-input">
                <input type="search" placeholder="Search...">
                <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
            </div>
        </form>
        <input type="checkbox" id="switch-mode" hidden>
        <label for="switch-mode" class="switch-mode"></label>
        <a href="#" class="notification" id="notificationIcon">
            <i class='bx bxs-bell'></i>
            <span class="num" id="notificationCount">0</span>
        </a>
        <div class="notification-dropdown" id="notificationDropdown" style="display: none;">
            <div class="notification-header">
                <h4>Notifications</h4>
                <button id="markAllRead" class="mark-all-read">Mark all read</button>
            </div>
            <div class="notification-list" id="notificationList">
                <!-- Notifications will be loaded here -->
            </div>
        </div>
        <a href="#" class="profile">
            <img src="img/people.png">
        </a>
    </nav>
    <!-- NAVBAR -->

    <main>
        <div class="head-title">
            <div class="left">
                <h1>Manage Deleted Records</h1>
                <ul class="breadcrumb">
                    <li><a href="#">Admin</a></li>
                    <li><i class='bx bx-chevron-right'></i></li>
                    <li><a class="active" href="#">Deleted Records</a></li>
                </ul>
            </div>
        </div>

        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-success" style="background-color: #d4edda; color: #155724; padding: 10px; border-radius: 4px; margin-bottom: 15px;">
                <?php echo $_SESSION['message']; ?>
                <?php unset($_SESSION['message']); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger" style="background-color: #f8d7da; color: #721c24; padding: 10px; border-radius: 4px; margin-bottom: 15px;">
                <?php echo $_SESSION['error']; ?>
                <?php unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>

        <div class="table-data">
            <div class="order">
                <div class="head">
                    <h3>Soft Deleted Records</h3>
                    <i class='bx bx-trash'></i>
                </div>
                
                <?php if ($deleted_records && $deleted_records->num_rows > 0): ?>
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Borrower Name</th>
                                <th>Department</th>
                                <th>Status</th>
                                <th>Deleted Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $deleted_records->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $row['id']; ?></td>
                                    <td>
                                        <p><?php echo htmlspecialchars($row['firstname'] . ' ' . $row['lastname']); ?></p>
                                    </td>
                                    <td><?php echo htmlspecialchars($row['department']); ?></td>
                                    <td>
                                        <span class="status <?php echo $row['status']; ?>">
                                            <?php echo ucfirst($row['status']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo date("M j, Y g:i A", strtotime($row['deleted_at'])); ?></td>
                                    <td>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="borrower_id" value="<?php echo $row['id']; ?>">
                                            <input type="hidden" name="action" value="restore">
                                            <button type="submit" class="btn-restore" onclick="return confirm('Restore this record?')">
                                                <i class='bx bx-undo'></i> Restore
                                            </button>
                                        </form>
                                        
                                        <form method="POST" style="display: inline; margin-left: 5px;">
                                            <input type="hidden" name="borrower_id" value="<?php echo $row['id']; ?>">
                                            <input type="hidden" name="action" value="hard_delete">
                                            <button type="submit" class="btn-delete" onclick="return confirm('⚠️ WARNING: This will permanently delete the record and cannot be undone. Are you sure?')">
                                                <i class='bx bx-trash'></i> Delete Permanently
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div style="text-align: center; padding: 40px;">
                        <i class='bx bx-trash' style="font-size: 48px; color: #ccc;"></i>
                        <p style="color: #666; margin-top: 10px;">No deleted records found.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>
</section>

<style>
.btn-restore {
    background-color: #28a745;
    color: white;
    border: none;
    padding: 5px 10px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 12px;
}

.btn-restore:hover {
    background-color: #218838;
}

.btn-delete {
    background-color: #dc3545;
    color: white;
    border: none;
    padding: 5px 10px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 12px;
}

.btn-delete:hover {
    background-color: #c82333;
}

.status {
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: bold;
}

.status.pending {
    background-color: #FFC107; /* Yellow */
    color: #000000;
}

.status.approved {
    background-color: #4CAF50; /* Green */
    color: #FFFFFF;
}

.status.rejected {
    background-color: #F44336; /* Red */
    color: #FFFFFF;
}

.status.returned {
    background-color: #2196F3; /* Blue */
    color: #FFFFFF;
}
</style>

<script src="script.js"></script>
<script src="notification.js"></script>
</body>
</html> 