<?php
include_once "dbconnect.php";

echo "<h2>Testing Borrowers Table</h2>";

// Check if borrowers table exists and has data
$sql = "SELECT COUNT(*) as count FROM borrowers WHERE deleted_at IS NULL";
$result = $conn->query($sql);
if ($result) {
    $row = $result->fetch_assoc();
    echo "<p>Total active borrowers: " . $row['count'] . "</p>";
} else {
    echo "<p>Error: " . $conn->error . "</p>";
}

// Show sample data
$sql = "SELECT id, idnum, firstname, lastname, department, status FROM borrowers WHERE deleted_at IS NULL LIMIT 5";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    echo "<h3>Sample borrowers data:</h3>";
    echo "<table border='1'>";
    echo "<tr><th>ID</th><th>ID Number</th><th>First Name</th><th>Last Name</th><th>Department</th><th>Status</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['idnum'] . "</td>";
        echo "<td>" . $row['firstname'] . "</td>";
        echo "<td>" . $row['lastname'] . "</td>";
        echo "<td>" . $row['department'] . "</td>";
        echo "<td>" . $row['status'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No data found in borrowers table</p>";
}

// Test the exact query from fetch_student_info.php
if (isset($_GET['test_id'])) {
    $test_id = intval($_GET['test_id']);
    echo "<h3>Testing fetch_student_info.php query for ID: " . $test_id . "</h3>";
    
    $sql = "SELECT id, idnum, firstname, middleinitial, lastname, department, course, email, cpnnumber, consent, status, borrow_date, return_date 
            FROM borrowers WHERE id = ?";
    $stmt = $conn->prepare($sql);
    
    if ($stmt) {
        $stmt->bind_param("i", $test_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result && $result->num_rows > 0) {
            $data = $result->fetch_assoc();
            echo "<p>Found borrower data:</p>";
            echo "<pre>" . print_r($data, true) . "</pre>";
        } else {
            echo "<p>No borrower found with ID: " . $test_id . "</p>";
        }
        $stmt->close();
    } else {
        echo "<p>Error preparing statement: " . $conn->error . "</p>";
    }
}

$conn->close();
?> 