<?php
// Start session to store any messages
session_start();

// Include the database connection file
include_once "dbconnect.php";

// Check for form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve form data and handle file uploads
    $firstname = $_POST['firstname'];
    $middleinitial = $_POST['middleinitial'];
    $lastname = $_POST['lastname'];
    $yearlvl = $_POST['yearlvl'];
    $course = $_POST['course'];
    $studidnum = $_POST['studidnum'];
    $email = $_POST['email'];
    $nameofgrdn = $_POST['nameofgrdn'];
    $address = $_POST['address'];
    $cpnnumber = $_POST['cpnnumber'];
    $consent = isset($_POST['consent']) ? 1 : 0;

    // Process file uploads for idphoto, regform, and signature
    $idphoto = !empty($_FILES['idphoto']['tmp_name']) ? file_get_contents($_FILES['idphoto']['tmp_name']) : null;
    $regform = !empty($_FILES['regform']['tmp_name']) ? file_get_contents($_FILES['regform']['tmp_name']) : null;
    $signature = !empty($_FILES['signature']['tmp_name']) ? file_get_contents($_FILES['signature']['tmp_name']) : null;

    // Insert form data into database
    $sql = "INSERT INTO students_info 
            (firstname, middleinitial, lastname, yearlvl, course, studidnum, email, nameofgrdn, address, cpnnumber, idphoto, regform, signature, consent) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    
    // Now we need 14 type specifiers for the 14 placeholders
    $stmt->bind_param(
        "sssssssssssbbi",
        $firstname, $middleinitial, $lastname, $yearlvl, $course, $studidnum, $email, $nameofgrdn, $address, $cpnnumber, $idphoto, $regform, $signature, $consent
    );

    // Send binary data for each file (10th, 11th, and 12th placeholders)
    if ($idphoto) $stmt->send_long_data(10, $idphoto);
    if ($regform) $stmt->send_long_data(11, $regform);
    if ($signature) $stmt->send_long_data(12, $signature);

    // Execute the query and check if it was successful
    if ($stmt->execute()) {
        $_SESSION['message'] = "Form submitted successfully.";
    } else {
        $_SESSION['message'] = "Submission failed: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();

    header("Location: form.php");
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->
<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
}

:root {
    --grey: #F4F2FF;
    --dark-grey: #B7B7B7;
    --green: #23AE00;
    --red: #FE2727;
    --blue: #277FFE;
    --light-blue: #B6C6FF;
    --dark-blue: #1368E3;
    --text: #9B9B9B;
}

body {
    background: var(--light-blue);
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    padding: 0 16px;
}

.container {
    max-width: 750px;
    width: 100%;
    padding: 28px; /* Add some padding */
    background: #fff; /* Background for the container */
    border-radius: 12px; /* Rounded corners */
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); /* Optional shadow for depth */
}

.title {
    font-size: 24px;
    font-weight: 600;
    margin-bottom: 20px; /* Space below the title */
    text-align: center; /* Center title */
}

.form-group {
    margin-bottom: 14px; /* Space between form groups */
}

.form-group label {
    display: inline-block;
    margin-bottom: 4px; /* Space below the label */
}

.uniform-select {
    padding: 12px 20px; /* Ensure consistent padding */
    border: 1px solid var(--dark-grey); /* Border color */
    width: 100%; /* Ensure all selects take full width */
    height: 46px; /* Set a specific height to match other input boxes */
    border-radius: 6px; /* Rounded corners */
    appearance: none; /* Remove default styling in some browsers */
    background-color: #fff; /* Background color */
    transition: border-color .3s ease; /* Smooth border color transition */
}

/* Style the select on focus */
.uniform-select:focus {
    border-color: var(--blue); /* Change border color on focus */
    background: var(--grey); /* Background color on focus */
}

.input-group {
    width: 100%;
    position: relative; /* Positioning context for icons */
}

.input-group input {
    padding: 12px 20px; /* Padding inside input */
    outline: none; /* Remove outline on focus */
    border-radius: 6px; /* Rounded corners */
    border: 1px solid var(--dark-grey); /* Border color */
    width: 100%; /* Full width */
    height: 46px; /* Set a specific height to match other input boxes */
    transition: border-color .3s ease; /* Smooth border color transition */
}

.input-group input:focus {
    border-color: var(--blue); /* Change border color on focus */
    background: var(--grey); /* Background color on focus */
}

.input-group i {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    right: 20px;
    color: var(--text); /* Icon color */
    pointer-events: none; /* Ignore mouse events */
}

.checkbox-container span {
    font-size: 13px; /* Adjust the size as needed */
    line-height: 1.5; /* Adjust line height for better spacing if necessary */
}

.btn-submit {
    padding: 12px 0; /* Button padding */
    width: 100%; /* Full width */
    color: #fff; /* Text color */
    border-radius: 6px; /* Rounded corners */
    cursor: pointer; /* Pointer on hover */
    border: none; /* No border */
    font-weight: 500; /* Font weight */
    background: var(--blue); /* Background color */
    margin-top: 20px; /* Space above button */
    transition: background .3s ease; /* Smooth background transition */
}

.btn-submit:hover {
    background: var(--dark-blue); /* Darker blue on hover */
}

</style>

    <title>Student ID Information Form</title>
</head>
<body>
	
	<div class="container">
    <form id="studentForm" action="form.php" method="POST" class="active" enctype="multipart/form-data" onsubmit="return validateForm()">
			<h2 class="title">Student ID Information Form</h2>

			<div class="form-group">
				<label for="firstname">First Name</label>
				<div class="input-group">
					<input type="firstname" id="firstname" name="firstname" placeholder="First Name">
				</div>
			</div>

            <div class="form-group">
                <label for="middleinitial">Middle Initial</label>
				<div class="input-group">
                    <input type="text" id="middleinitial" name="middleinitial" placeholder="Middle Initial">
				</div>
			</div>

			<div class="form-group">
                            <label for="firstname">Last Name</label>
                            <div class="input-group">
                                <input type="text" id="lastname" name="lastname" placeholder="Last Name" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="yrlevel">Year Level</label>
                            <div class="input-group">
                                <select id="yrlevel" name="yearlvl" class="uniform-select" required>
                                    <option value="" disabled selected>Select Year Level</option>
                                    <option value="firstyr">1st Year</option>
                                    <option value="secondyr">2nd Year</option>
									<option value="thirdyr">3rd Year</option>
									<option value="fourthyr">4th Year</option>
                                </select>
                                <i class='bx bx-chevron-down'></i>
                            </div>
                        </div>

						<div class="form-group">
                            <label for="course">Course</label>
                            <div class="input-group">
                                <select id="course" name="course" class="uniform-select" required>
                                    <option value="" disabled selected>Select Course</option>
                                    <option value="beed">Bachelor of Elementary Education (BEED)</option>
                                    <option value="bsede">Bachelor of Secondary Education (BSED) Major in English </option>
									<option value="bsedf">Bachelor of Secondary Education (BSED) Major in Filipino</option>
									<option value="bsedm">Bachelor of Secondary Education (BSED) Major in Mathematics</option>
									<option value="bseds">Bachelor of Secondary Education (BSED) Major in Science</option>
									<option value="bsedss">Bachelor of Secondary Education (BSED) Major in Social Studies</option>
									<option value="bsedv">Bachelor of Secondary Education (BSED) Major in Values Education </option>
									<option value="bsis">Bachelor of Science in Information Systems (BSIS)</option>
									<option value="bsbahrm">Bachelor of Science in Business Administration (BSBA) Major in Human Resource Management</option>
									<option value="bsbafm">Bachelor of Science in Business Administration (BSBA) Major in Financial Management</option>
									<option value="bsa">Bachelor of Science in Accountancy (BSA)</option>
									<option value="bsais">Bachelor of Science in Accounting Information Systems (BSAIS)</option>
									<option value="ccnt">Certificate of Computer and Network Technology (CCNT)</option>
									<option value="chrm">Certificate in Hotel and Restaurant Management (CHRM)</option>
                                </select>
                                <i class='bx bx-chevron-down'></i>
                            </div>
                        </div>

						<div class="form-group">
                            <label for="studidnum">Student ID Number</label>
                            <div class="input-group">
                                <input type="number" id="studidnum" name="studidnum" placeholder="Student ID Number" required>
                            </div>
                        </div>

						<div class="form-group">
                            <label for="email">Email Address</label>
                            <div class="input-group">
                                <input type="email" id="email" name="email" placeholder="Email Address" required>
                            </div>
                        </div>

						<div class="form-group">
                            <label for="nameofgrdn">Name of Guardian</label>
                            <div class="input-group">
                                <input type="text" id="nameofgrdn" name="nameofgrdn" placeholder="Name of Guardian" required>
                            </div>
                        </div>

						<div class="form-group">
                            <label for="address">Address</label>
                            <div class="input-group">
                                <input type="text" id="address" name="address" placeholder="Address" required>
                            </div>
                        </div>

						<div class="form-group">
                            <label for="cpnnumber">Contact No. of Guardian</label>
                            <div class="input-group">
                                <input type="number" id="cpnnumber" name="cpnnumber" placeholder="Contact No. of Guardian" required>
                            </div>
                        </div>

						<div class="form-group">
                            <label for="idphoto">Attach your ID Photo</label>
                            <div class="input-group">
                                <input type="file" id="idphoto" name="idphoto" placeholder="Attach your ID Photo" required>
                            </div>
                        </div>

						<div class="form-group">
                            <label for="regform">Attach photo of your Registration Form</label>
                            <div class="input-group">
                                <input type="file" id="regform" name="regform" placeholder="Attach photo of your Registration Form" required>
                            </div>
                        </div>

						<div class="form-group">
                            <label for="signature">Attach photo of your Signature</label>
                            <div class="input-group">
                                <input type="file" id="signature" name="signature" placeholder="Attach photo of your Signature" required>
                            </div>
                        </div>

						<!-- Consent Checkbox -->
						<div class="form-group">
							<label class="checkbox-container">
								<input type="checkbox" id="consent" name="consent" required>
								<span>I confirm that all the information provided in this form is accurate and correct, and I consent to sharing my data for ID card creation.</span>
							</label>
						</div>

                        <button type="submit" class="btn-submit">Submit</button>
            </form>

            <script>
            function validateForm() {
            const consentCheckbox = document.getElementById('consent');
    
            // Check if the consent checkbox is checked
            if (!consentCheckbox.checked) {
            alert('Please confirm that you consent to sharing your data.'); // Alert for unchecked checkbox
            return false; // Prevent form submission
            }

            // If all validations pass, show success alert
            alert('Form submitted successfully!'); // Success alert
            return true; // Allow form submission to proceed
            }
            </script>

</body>
</html>