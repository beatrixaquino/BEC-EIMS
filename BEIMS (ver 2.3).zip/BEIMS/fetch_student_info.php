<?php
// Force JSON output and handle CORS (optional but recommended)
header('Content-Type: application/json');

// Disable error display in response (recommended for production)
ini_set('display_errors', 0);
error_reporting(0);

// Include the database connection
include_once "dbconnect.php";

// Check if the 'id' is passed via GET
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);  // Sanitize input

    $sql = "SELECT id, idnum, firstname, middleinitial, lastname, department, course, email, cpnnumber, consent, status, borrow_date, return_date 
            FROM borrowers WHERE id = ?";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        echo json_encode(["error" => "Query preparation failed: " . $conn->error]);
        exit;
    }

    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if a matching record was found
    if ($result && $result->num_rows > 0) {
        $data = $result->fetch_assoc();

        // Return the data as JSON
        echo json_encode($data);
    } else {
        echo json_encode(["error" => "No borrower found with that ID."]);
    }

    $stmt->close();
} else {
    echo json_encode(["error" => "No borrower ID provided."]);
}

$conn->close();
