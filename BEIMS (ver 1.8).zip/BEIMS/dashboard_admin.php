<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->
	<link rel="stylesheet" href="istyle.css">

	<title>Admin Hub</title>
</head>
<body data-page="dashboard_admin">


	<!-- SIDEBAR -->
	<section id="sidebar">
		<a href="#" class="brand">
			<i class='bx bxs-package' ></i>
			<span class="text">BEC EIMS</span>
		</a>
		<ul class="side-menu top">
			<li class="active">
				<a href="dashboard_admin.php">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Dashboard</span>
				</a>
			</li>
			<li>
				<a href="admin_borrowform.php">
					<i class='bx bx-clipboard'></i>
					<span class="text">Borrowers Forms</span>
				</a>
			</li>
			<li>
				<a href="equiplist.php">
                <i class='bx bxs-wrench' ></i>
					<span class="text">Equipment List</span>
				</a>
			</li>
		</ul>
		<ul class="side-menu">
			<li>
				<a href="login.php" class="logout">
					<i class='bx bxs-log-out' ></i>
					<span class="text">Logout</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->



	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu' ></i>
			<a href="#" class="nav-link">Categories</a>
			<form action="#">
				<div class="form-input">
					<input type="search" placeholder="Search...">
					<button type="submit" class="search-btn"><i class='bx bx-search' ></i></button>
				</div>
			</form>
			<input type="checkbox" id="switch-mode" hidden>
			<label for="switch-mode" class="switch-mode"></label>
			<a href="#" class="notification">
				<i class='bx bxs-bell' ></i>
				<span class="num">8</span>
			</a>
			<a href="#" class="profile">
				<img src="img/people.png">
			</a>
		</nav>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
			<div class="head-title">
				<div class="left">
					<h1>Dashboard</h1>
					<ul class="breadcrumb">
						<li>
							<a href="#">Dashboard</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="#">Home</a>
						</li>
					</ul>
				</div>
				<a href="#" class="btn-download">
					<i class='bx bxs-report'></i>
					<span class="text">Generated Reports</span>
				</a>
			</div>

			<ul class="box-info">
				<a href="#" class="box-link">
				<li>
					<i class='bx bxs-user-pin'></i>
					<span class="text">
						<h3>300</h3>
						<p>Number of Users</p>
					</span>
				</li>
				</a>
				<a href="#" class="box-link">
				<li>
					<i class='bx bxs-hourglass' ></i>
					<span class="text">
						<h3>3</h3>
						<p>Pending Requests</p>
					</span>
				</li>
				</a>
				<a href="#" class="box-link">
				<li>
					<i class='bx bx-check'></i>
					<span class="text">
						<h3>2</h3>
						<p>Approved Forms</p>
					</span>
				</li>
				</a>
				<a href="#" class="box-link">
				<li>
					<i class='bx bx-archive-in' ></i>
					<span class="text">
						<h3>3</h3>
						<p>Returned Items</p>
					</span>
				</li>
				</a>
			</ul>


			<div class="table-data">
				<div class="order">
					<div class="head">
						<h3>Submitted Borrowers Forms</h3>
						<i class='bx bx-search' ></i>
						<i class='bx bx-filter' ></i>
					</div>
					<table>
						<thead>
							<tr>
								<th>Name</th>
								<th>Date Order</th>
								<th>Status</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>
									<img src="img/people.png">
									<p>John Doe</p>
								</td>
								<td>01-10-2021</td>
								<td><span class="status completed">Completed</span></td>
							</tr>
							<tr>
								<td>
									<img src="img/people.png">
									<p>John Doe</p>
								</td>
								<td>01-10-2021</td>
								<td><span class="status pending">Pending</span></td>
							</tr>
							<tr>
								<td>
									<img src="img/people.png">
									<p>John Doe</p>
								</td>
								<td>01-10-2021</td>
								<td><span class="status process">Process</span></td>
							</tr>
							<tr>
								<td>
									<img src="img/people.png">
									<p>John Doe</p>
								</td>
								<td>01-10-2021</td>
								<td><span class="status pending">Pending</span></td>
							</tr>
							<tr>
								<td>
									<img src="img/people.png">
									<p>John Doe</p>
								</td>
								<td>01-10-2021</td>
								<td><span class="status completed">Completed</span></td>
							</tr>
						</tbody>
					</table>
				</div>
				<div class="todo">
					<div class="head">
						<h3>Calendar</h3>
						<i class='bx bx-plus' ></i>
						<i class='bx bx-filter' ></i>

					</div>
						<div class="calendar-controls">
            				<button id="prev-month">&lt; Previous</button>
            				<h2 id="current-month-year">Month Year</h2>
            				<button id="next-month">Next &gt;</button>
        				</div>

						<div class="calendar-grid" id="calendar-header">
            			<div class="calendar-header">Sun</div>
            			<div class="calendar-header">Mon</div>
            			<div class="calendar-header">Tue</div>
            			<div class="calendar-header">Wed</div>
            			<div class="calendar-header">Thu</div>
            			<div class="calendar-header">Fri</div>
            			<div class="calendar-header">Sat</div>
        			</div>

					<div class="calendar-grid" id="calendar-days"></div>

					<div class="modal" id="event-modal">
        				<div class="modal-content">
            				<div class="modal-header">
                				<h3 id="modal-event-title">Event Title</h3>
                				<button class="close-btn" id="close-modal">&times;</button>
            				</div>
            				<div class="event-meta">
                				<span class="event-type" id="modal-event-type">General</span>
                				<span class="event-time" id="modal-event-time">All day</span>
                				<span class="event-venue" id="modal-event-venue">Online</span>
            				</div>
            				<div class="event-details">
                				<p id="modal-event-description">Event description goes here.</p>
            				</div>
            				<div class="event-actions">
                				<button class="edit-btn">Edit</button>
                				<button class="delete-btn">Delete</button>
            				</div>
        				</div>

					</div>

    			</div>
			</div>
		</main>
		<!-- MAIN -->
	</section>
	<!-- CONTENT -->
	

	<script src="script.js"></script>
</body>
</html>