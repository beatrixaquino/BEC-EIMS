<?php
// Start session and output buffering
session_start();
ob_start();

// Include database connection
include_once "dbconnect.php";

// --- Handle Form Submission (Add or Update) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = isset($_POST['id']) && !empty($_POST['id']) ? intval($_POST['id']) : null;
    $itemname = $_POST['itemname'];
    $specification = $_POST['specification'];
    $itemcategory = $_POST['itemcategory'];
    $quantityreq = intval($_POST['quantityreq']);
    $unit_req = $_POST['unit_req'];
    $quantityon = intval($_POST['quantityon']);
    $unit_on = $_POST['unit_on'];
    $difference = $_POST['difference'];
    $remarks = $_POST['remarks'];
    $itemdescription = $_POST['itemdescription'];
    $complianceauditone = intval($_POST['complianceauditone']);
    $unit1 = $_POST['unit1'];
    $complianceaudittwo = intval($_POST['complianceaudittwo']);
    $unit2 = $_POST['unit2'];

    // File handling
    $idphoto = null;
    if (isset($_FILES['idphoto']) && $_FILES['idphoto']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = 'uploads/';
        $fileName = basename($_FILES['idphoto']['name']);
        $targetFilePath = $uploadDir . $fileName;

        if (move_uploaded_file($_FILES['idphoto']['tmp_name'], $targetFilePath)) {
            $idphoto = $fileName;
        }
    }

    // Insert or update
    if ($id) {
        // Update existing item
        $sql = "UPDATE item_list SET itemname=?, specification=?, itemcategory=?, quantityreq=?, unit_req=?, quantityon=?, unit_on=?, difference=?, remarks=?, itemdescription=?, complianceauditone=?, unit1=?, complianceaudittwo=?, unit2=?"
             . ($idphoto ? ", idphoto=?" : "")
             . " WHERE id=?";
        $stmt = $conn->prepare($sql);

        if ($idphoto) {
            $stmt->bind_param("sssssisisssisssi", $itemname, $specification, $itemcategory, $quantityreq, $unit_req, $quantityon, $unit_on, $difference, $remarks, $itemdescription, $complianceauditone, $unit1, $complianceaudittwo, $unit2, $idphoto, $id);
        } else {
            $stmt->bind_param("sssssisisssisss", $itemname, $specification, $itemcategory, $quantityreq, $unit_req, $quantityon, $unit_on, $difference, $remarks, $itemdescription, $complianceauditone, $unit1, $complianceaudittwo, $unit2, $id);
        }
    } else {
        // Insert new item
        $sql = "INSERT INTO item_list (itemname, specification, itemcategory, quantityreq, unit_req, quantityon, unit_on, difference, remarks, itemdescription, complianceauditone, unit1, complianceaudittwo, unit2, idphoto)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssssisisssisss", $itemname, $specification, $itemcategory, $quantityreq, $unit_req, $quantityon, $unit_on, $difference, $remarks, $itemdescription, $complianceauditone, $unit1, $complianceaudittwo, $unit2, $idphoto);
    }

    if ($stmt->execute()) {
        $_SESSION['message'] = $id ? "Item updated successfully!" : "Item added successfully!";
    } else {
        $_SESSION['message'] = "Database operation failed: " . $stmt->error;
    }

    $stmt->close();
    header("Location: equiplist.php");
    exit();
}

// --- Handle Delete Action ---
if (isset($_GET['delete'])) {
    $deleteId = intval($_GET['delete']);
    $delQuery = "DELETE FROM item_list WHERE id=?";
    $stmt = $conn->prepare($delQuery);
    $stmt->bind_param("i", $deleteId);
    $stmt->execute();
    $stmt->close();
    $_SESSION['message'] = "Item deleted successfully.";
    header("Location: equiplist.php");
    exit();
}

// --- Fetch all items ---
$sql = "SELECT * FROM item_list ORDER BY created_at DESC";
$result = $conn->query($sql);

ob_end_flush();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="istyle.css">
    <title>AdminHub</title>
</head>
<body data-page="equiplist">

<!-- SIDEBAR -->
<section id="sidebar">
		<a href="#" class="brand">
			<i class='bx bxs-package' ></i>
			<span class="text">BEC EIMS</span>
		</a>
		<ul class="side-menu top">
			<li class="active">
				<a href="dashboard_superadmin.php">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Dashboard</span>
				</a>
			</li>
			<li>
				<a href="usermng.php">
					<i class='bx bx-group' ></i>
					<span class="text">User Management</span>
				</a>
			</li>
			<li>
				<a href="borrowform.php">
					<i class='bx bx-clipboard'></i>
					<span class="text">Borrowers Forms</span>
				</a>
			</li>
			<li>
				<a href="equiplist.php">
					<i class='bx bxs-id-card'></i>
					<span class="text">Equipment List</span>
				</a>
			</li>
		</ul>
		<ul class="side-menu">
			<li>
				<a href="login.php" class="logout">
					<i class='bx bxs-log-out' ></i>
					<span class="text">Logout</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->


    <!-- CONTENT -->
    <section id="content">
        <nav>
            <i class='bx bx-menu'></i>
            <a href="#" class="nav-link">Categories</a>
            <form action="#">
                <div class="form-input">
                    <input type="search" placeholder="Search...">
                    <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
                </div>
            </form>
            <input type="checkbox" id="switch-mode" hidden>
            <label for="switch-mode" class="switch-mode"></label>
            <a href="#" class="notification">
                <i class='bx bxs-bell'></i>
                <span class="num">8</span>
            </a>
            <a href="#" class="profile">
                <img src="img/people.png">
            </a>
        </nav>

        <main>
            <div class="head-title">
                <div class="left">
                    <h1>Equipment List</h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="">Equipment List</a>
                        </li>
                        <li><i class='bx bx-chevron-right'></i></li>
                        <li>
                            <a class="active" href="+">Form</a>
                        </li>
                    </ul>
                </div>
                <a href="#" class="btn-download" onclick="">
                    <i class='bx bxs-report'></i>
                    <span class="text">Generate Report</span>
                </a>
            </div>

            <div class="table-data">
            <div class="order">
        <div class="head">
            <h3>List of Equipment</h3>
            <i class='bx bx-search'></i>
            <i class='bx bx-filter'></i>
        </div>

        <div class="equipment-grid">
<?php if ($result->num_rows > 0): ?>
    <?php while ($row = $result->fetch_assoc()): ?>
        <div class="equipment-card">
            <img src="uploads/<?php echo htmlspecialchars($row['idphoto'] ?? 'placeholder.png'); ?>" alt="Equipment Image" class="equipment-img">
            <h4><?php echo htmlspecialchars($row['itemname']); ?></h4>
            <p><strong>Category:</strong> <?php echo htmlspecialchars($row['itemcategory']); ?></p>
            <p><strong>Available:</strong> <?php echo htmlspecialchars($row['quantityon']); ?> <?php echo htmlspecialchars($row['unit_on']); ?></p>
            <div class="card-actions">
                <button class="btn-view-card" data-id="<?php echo $row['id']; ?>">View</button>
                <button class="btn-edit-card" data-id="<?php echo $row['id']; ?>">Edit</button>
                <button class="btn-delete-card" data-id="<?php echo $row['id']; ?>">Delete</button>
            </div>
        </div>
    <?php endwhile; ?>
<?php else: ?>
    <p>No equipment available.</p>
<?php endif; ?>
</div>
            </div>
                <div class="todo">
                    <div class="head">
                        <h3>Add New Equipment</h3>
                    </div>

                    <form id="itemDetailsForm" action="equiplist.php" method="POST" enctype="multipart/form-data">
                    <input type="hidden" id="equiplist" name="id">

                    <div class="form-group">
                            <label for="itemname">Item Name</label>
                            <div class="input-group">
                                <input type="text" id="itemname" name="itemname" placeholder="Item Name" required>
                                <i class='bx bxs-label'></i>
                            </div>
                    </div>

                     <div class="form-group">
                            <label for="specification">Item Specification</label>
                            <div class="input-group">
                                <input type="text" id="specification" name="specification" placeholder="Item Specification" required>
                                <i class='bx bx-detail'></i>
                            </div>
                    </div>
                    
                    <div class="form-group">
                            <label for="itemcategory">Item Categorization</label>
                            <div class="input-group">
                                <select id="itemcategory" name="itemcategory" required>
                                    <option value="" disabled selected>Select Item Category</option>
                                    <option value="supplyandmaterials">Supplies and Materials</option>
                                    <option value="equipment">Equipment</option>
                                    <option value="tools">Tools</option>
                                </select>
                                <i class='bx bx-chevron-down'></i>
                            </div>
                        </div>

                     <div class="form-group">
                        <label for="quantityreq">Quantity Required</label>
                            <div class="quantity-wrapper">
                                <input type="number" id="quantityreq" name="quantityreq" placeholder="0" min="1" required>
                                <select id="unit_req" name="unit_req" required>
                                    <option value="pcs">pcs</option>
                                    <option value="sets">sets</option>
                                    <option value="units">units</option>
                                    <option value="box">box</option>
                                    <option value="others">others</option>
                                </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="quantityon">Quantity on Site</label>
                            <div class="quantity-wrapper">
                                <input type="number" id="quantityon" name="quantityon" placeholder="0" min="1" required>
                                <select id="unit_on" name="unit_on" required>
                                    <option value="pcs">pcs</option>
                                    <option value="sets">sets</option>
                                    <option value="units">units</option>
                                    <option value="box">box</option>
                                    <option value="others">others</option>
                                </select>
                        </div>
                    </div>

                    <div class="form-group">
                            <label for="difference">Difference</label>
                            <div class="input-group">
                                <input type="text" id="difference" name="difference" placeholder="Difference">
                                <i class='bx bxs-calculator' ></i>
                            </div>
                    </div>

                    <div class="form-group">
                            <label for="remarks">Inspectors Remarks</label>
                            <div class="input-group">
                                <input type="text" id="remarks" name="remarks" placeholder="Inspector Remarks">
                                <i class='bx bx-comment-detail'></i>
                            </div>
                    </div>

                    <div class="form-group">
                            <label for="itemdescription">Item Description</label>
                            <div class="input-group">
                                <input type="text" id="itemdescription" name="itemdescription" placeholder="Item Description">
                                <i class='bx bx-file-blank'></i>
                            </div>
                    </div>

                    <div class="form-group">
                        <label for="complianceauditone">Quantity onsite during Compliance Audit Year 1</label>
                            <div class="quantity-wrapper">
                                <input type="number" id="complianceauditone" name="complianceauditone" placeholder="0" min="1">
                                <select id="unit1" name="unit1">
                                    <option value="pcs">pcs</option>
                                    <option value="sets">sets</option>
                                    <option value="units">units</option>
                                    <option value="box">box</option>
                                    <option value="others">others</option>
                                </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="complianceaudittwo">Quantity onsite during Compliance Audit Year 2</label>
                            <div class="quantity-wrapper">
                                <input type="number" id="complianceaudittwo" name="complianceaudittwo" placeholder="0" min="1">
                                <select id="unit2" name="unit2">
                                    <option value="pcs">pcs</option>
                                    <option value="sets">sets</option>
                                    <option value="units">units</option>
                                    <option value="box">box</option>
                                    <option value="others">others</option>
                                </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="eqpphoto">Equipment Image</label>
                            <div class="upload-container">
                                <div class="upload-preview">
                                    <img id="idphoto-preview" src="#" alt="Equipment Photo" style="display:none;">
                                </div>
                        <label for="eqpphoto" class="upload-box">
                            <div class="upload-icon">
                                <i class='bx bx-cloud-upload'></i>
                                    <p>Upload Image</p>
                                    <p class="file-size-note">Image size must be less than 2MB</p>
                            </div>
                        </label>
                            <input type="file" id="eqpphoto" name="idphoto" style="display: none;" onchange="previewImage(event, 'idphoto-preview')">
                            </div>
                    </div>

                    <button type="submit" class="btn-submit">Submit</button>
                    

                </div>
            </div>
        </main>
    </section>

    <script>
document.addEventListener("DOMContentLoaded", () => {
    // Handle EDIT button
    document.querySelectorAll(".btn-edit").forEach(btn => {
        btn.addEventListener("click", function (e) {
            e.stopPropagation();  // Prevent row click
            const itemId = this.getAttribute("data-id");

            fetch(`fetch_equipment_info.php?id=${itemId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.error) {
                        alert(data.error);
                    } else {
                        // Fill the form with the fetched data
                        document.getElementById("equiplist").value = data.id;
                        document.getElementById("itemname").value = data.itemname;
                        document.getElementById("specification").value = data.specification;
                        document.getElementById("itemcategory").value = data.itemcategory;
                        document.getElementById("quantityreq").value = data.quantityreq;
                        document.getElementById("unit_req").value = data.unit_req;
                        document.getElementById("quantityon").value = data.quantityon;
                        document.getElementById("unit_on").value = data.unit_on;
                        document.getElementById("difference").value = data.difference;
                        document.getElementById("remarks").value = data.remarks;
                        document.getElementById("itemdescription").value = data.itemdescription;
                        document.getElementById("complianceauditone").value = data.complianceauditone;
                        document.getElementById("unit1").value = data.unit1;
                        document.getElementById("complianceaudittwo").value = data.complianceaudittwo;
                        document.getElementById("unit2").value = data.unit2;

                        if (data.idphoto) {
                            const preview = document.getElementById("idphoto-preview");
                            preview.src = `uploads/${data.idphoto}`;
                            preview.style.display = "block";
                        }
                    }
                });
        });
    });

    // Handle DELETE button
    document.querySelectorAll(".btn-delete").forEach(btn => {
        btn.addEventListener("click", function (e) {
            e.stopPropagation();  // Prevent row click
            const itemId = this.getAttribute("data-id");

            if (confirm("Are you sure you want to delete this equipment?")) {
                fetch(`delete_equipment.php?id=${itemId}`, { method: "POST" })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert("Item deleted successfully!");
                            location.reload();  // Refresh the table
                        } else {
                            alert("Error deleting item: " + data.error);
                        }
                    });
            }
        });
    });
});
</script>

<script src="script.js"></script>
</body>
</html>
