<?php
// Enable error reporting
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Output JSON
header('Content-Type: application/json');

// Include database connection
include_once "dbconnect.php";

// Check if the borrower form ID is provided
if (isset($_GET['form_id'])) {
    $form_id = intval($_GET['form_id']);  // Sanitize input

    // Query to fetch borrowed items for the given form
    $sql = "SELECT item_name, date_needed, quantity, unit FROM borrowed_items WHERE form_id = ?";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        echo json_encode(["error" => "Failed to prepare statement: " . $conn->error]);
        exit();
    }

    $stmt->bind_param("i", $form_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $items = [];
    while ($row = $result->fetch_assoc()) {
        $items[] = $row;
    }

    echo json_encode($items);

    $stmt->close();
} else {
    echo json_encode(["error" => "No form ID provided."]);
}

$conn->close();
