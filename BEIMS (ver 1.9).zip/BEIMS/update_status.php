<?php
header("Content-Type: application/json");

// Include the database connection
include_once "dbconnect.php";

// Decode the JSON data received from the client
$data = json_decode(file_get_contents("php://input"), true);

file_put_contents('log.txt', print_r($data, true));

// Check if id and status are set
if (!isset($data['id']) || !isset($data['status'])) {
    echo json_encode(["success" => false, "error" => "Invalid input - missing ID or status"]);
    exit();
}

$id = intval($data['id']);
$status = $data['status'];

// Check that the status matches an allowed enum value
if (!in_array($status, ['accepted', 'rejected', 'pending'])) {
    echo json_encode(["success" => false, "error" => "Invalid status value"]);
    exit();
}

// Prepare the SQL statement to update status
$stmt = $conn->prepare("UPDATE students_info SET status = ? WHERE id = ?");
$stmt->bind_param("si", $status, $id);

// Execute and check for errors
if ($stmt->execute()) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false, "error" => $stmt->error]);
}

$stmt->close();
?>
