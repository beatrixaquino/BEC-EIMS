<?php
// Start session and include DB connection
session_start();
include_once 'dbconnect.php'; // adjust if your connection file has a different name

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve data from the form
    $idnum = $_POST['idnum'];
    $firstname = $_POST['firstname'];
    $middleinitial = $_POST['middleinitial'];
    $lastname = $_POST['lastname'];
    $department = $_POST['department'];
    $course = $_POST['course'];
    $email = $_POST['email'];
    $cpnnumber = $_POST['cpnnumber'];
    $consent = isset($_POST['consent']) ? 1 : 0; // Set consent to 1 if checked

    // Prepare SQL insert statement
    $sql = "INSERT INTO borrowers_form (idnum, firstname, middleinitial, lastname, department, course, email, cpnnumber, consent)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssssi", $idnum, $firstname, $middleinitial, $lastname, $department, $course, $email, $cpnnumber, $consent);
    $stmt->execute();

    // Check for success and set a session message
    if ($stmt->affected_rows > 0) {
        $_SESSION['message'] = "Submission successful!";
    } else {
        $_SESSION['message'] = "Submission failed. Please try again.";
    }

    // Redirect to avoid form resubmission
    header("Location: borrowform.php");
    exit();
}

// Fetch existing submissions (if needed)
$sql = "SELECT * FROM borrowers_form";
$result = $conn->query($sql);
ob_end_flush(); // Flush output buffer
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="istyle.css">
    <title>Superadmin Hub</title>
</head>
<body data-page="borrowform">

<!-- SIDEBAR -->
<section id="sidebar">
		<a href="#" class="brand">
			<i class='bx bxs-package' ></i>
			<span class="text">BEC EIMS</span>
		</a>
		<ul class="side-menu top">
			<li class="active">
				<a href="dashboard_superadmin.php">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Dashboard</span>
				</a>
			</li>
			<li>
				<a href="usermng.php">
					<i class='bx bx-group' ></i>
					<span class="text">User Management</span>
				</a>
			</li>
			<li>
				<a href="borrowform.php">
                    <i class='bx bx-clipboard'></i>
					<span class="text">Borrowers Forms</span>
				</a>
			</li>
			<li>
				<a href="equiplist.php">
                    <i class='bx bxs-wrench' ></i>
					<span class="text">Equipment List</span>
				</a>
			</li>
		</ul>
		<ul class="side-menu">
			<li>
				<a href="login.php" class="logout">
					<i class='bx bxs-log-out' ></i>
					<span class="text">Logout</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->


    <!-- CONTENT -->
    <section id="content">
        <nav>
            <i class='bx bx-menu'></i>
            <a href="#" class="nav-link">Categories</a>
            <form action="#">
                <div class="form-input">
                    <input type="search" placeholder="Search...">
                    <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
                </div>
            </form>
            <input type="checkbox" id="switch-mode" hidden>
            <label for="switch-mode" class="switch-mode"></label>
            <a href="#" class="notification">
                <i class='bx bxs-bell'></i>
                <span class="num">8</span>
            </a>
            <a href="#" class="profile">
                <img src="img/people.png">
            </a>
        </nav>

        <main>
            <div class="head-title">
                <div class="left">
                    <h1>Borrowers Forms</h1>
                    <ul class="breadcrumb">
                        <li>
                            <a href="#">Borrowers Forms</a>
                        </li>
                        <li><i class='bx bx-chevron-right'></i></li>
                        <li>
                            <a class="active" href="submforms.php">Form</a>
                        </li>
                    </ul>
                </div>
                <a href="#" class="btn-download" onclick="copyFormLink()">
    <i class='bx bx-copy'></i>
    <span class="text">Generate Report</span>
</a>
            </div>

            <div class="table-data">
            <div class="order">
        <div class="head">
            <h3>Borrowers Forms</h3>
            <i class='bx bx-search'></i>
            <i class='bx bx-filter'></i>
        </div>
        <table>
    <thead>
        <tr>
            <th>Borrower's Name</th>
            <th>Date Submitted</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($result && $result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr data-id="<?php echo $row['id']; ?>" class="student-row">
                    <td><?php echo htmlspecialchars($row['firstname'] . ' ' . $row['lastname']); ?></td>
                    <td><?php echo htmlspecialchars(date("F j, Y g:i A", strtotime($row['created_at']))); ?></td>
                    <td id="status-<?php echo $row['id']; ?>"><?php echo htmlspecialchars($row['status']); ?></td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="3">No records found.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
            </div>
                <div class="todo">
                    <div class="head">
                        <h3>Tool Borrowers Form</h3>
                    </div>
                    <form id="studentDetailsForm" action="borrowform.php" method="POST" enctype="multipart/form-data">
                        <input type="hidden" id="borrowform" name="id">
                        
                        <div class="form-group">
                            <label for="idnum">ID Number</label>
                            <div class="input-group">
                                <input type="text" id="idnum" name="idnum" placeholder="ID Number" required>
                                <i class='bx bx-id-card'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="firstname">First Name</label>
                            <div class="input-group">
                                <input type="text" id="firstname" name="firstname" placeholder="First Name" required>
                                <i class='bx bx-user'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="middleinitial">Middle Initial</label>
                            <div class="input-group">
                                <input type="text" id="middleinitial" name="middleinitial" placeholder="Middle Initial" required>
                                <i class='bx bx-user'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="lastname">Last Name</label>
                            <div class="input-group">
                                <input type="text" id="lastname" name="lastname" placeholder="Last Name" required>
                                <i class='bx bx-user'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="department">Department</label>
                            <div class="input-group">
                                <select id="department" name="department" required>
                                    <option value="" disabled selected>Select Department</option>
                                    <option value="department">Student</option>
                                    <option value="department">Faculty Member</option>
                                </select>
                                <i class='bx bx-chevron-down'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="course">Course</label>
                            <div class="input-group">
                                <select id="course" name="course" required>
                                    <option value="" disabled selected>Select Course</option>
                                    <option value="cookery">CHRM Cookery NC II</option>
                                    <option value="fbs">CHRM Food and Beverages NC II</option>
                                    <option value="fos">CHRM Front Office Services NC II</option>
                                    <option value="housekeeping">CHRM Housekeeping NC II</option>
                                    <option value="bartending">CHRM Bartending NC II</option>
                                </select>
                                <i class='bx bx-chevron-down'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="email">School Email</label>
                            <div class="input-group">
                                <input type="email" id="email" name="email" placeholder="School Email" required>
                                <i class='bx bx-envelope'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="cpnnumber">Contact Number</label>
                            <div class="input-group">
                                <input type="text" id="cpnnumber" name="cpnnumber" placeholder="Contact Number" required>
                                <i class='bx bx-phone'></i>
                            </div>
                        </div>

                        <div class="borrowed-items-card">
    <h3>Borrowed Items</h3>
    <table class="borrowed-items-table">
        <thead>
            <tr>
                <th>Item Name</th>
                <th>Date Needed</th>
                <th>Quantity</th>
            </tr>
        </thead>
        <tbody id="borrowedItemsTable">
            <!-- Temporary sample rows -->
            <tr>
                <td>Chef Knife</td>
                <td>July 5, 2025</td>
                <td>2 pcs</td>
            </tr>
            <tr>
                <td>Apron</td>
                <td>July 6, 2025</td>
                <td>10 pcs</td>
            </tr>
        </tbody>
    </table>
</div>

<div class="borrow-dates">
    <div class="form-group">
        <label for="borrow_date">Borrow Date</label>
        <div class="input-group">
            <input type="date" id="borrow_date" name="borrow_date" required>
        </div>
    </div>

    <div class="form-group">
        <label for="return_date">Return Date</label>
        <div class="input-group">
            <input type="date" id="return_date" name="return_date" required>
        </div>
    </div>
</div>

                        <!-- Consent Checkbox -->
						<div class="form-group">
							<label class="checkbox-container">
								<input type="checkbox" id="consent" name="consent" required>
								<span>I confirm that all the information I have provided is accurate and correct, and I consent to its use for processing my equipment borrowing request.</span>
							</label>
						</div>
                    
                        <div class="form-group">
                            <label for="formstatus">Form Status</label>
                            <div class="input-group">
                                <select id="formstatus" name="formstatus" required>
                                    <option value="" disabled selected>Select Status</option>
                                    <option value="pending">Pending</option>
                                    <option value="approved">Approved</option>
                                    <option value="rejected">Rejected</option>
                                    <option value="returned">Returned</option>
                                </select>
                                <i class='bx bx-chevron-down'></i>
                            </div>
                        </div>
                        

                        <button type="button" class="btn-accept" data-id="<?php echo $row['id']; ?>" onclick="updateStatus(<?php echo $row['id']; ?>, 'approved')">Approve</button>
                        <button type="button" class="btn-reject" data-id="<?php echo $row['id']; ?>" onclick="updateStatus(<?php echo $row['id']; ?>, 'rejected')">Reject</button>


                    </form>
                </div>
            </div>
        </main>
    </section>

    <script>
document.addEventListener("DOMContentLoaded", () => {
    const rows = document.querySelectorAll(".student-row");

    rows.forEach(row => {
        row.addEventListener("click", function () {
            const borrowerId = this.getAttribute("data-id");
            console.log("Selected row ID:", borrowerId);

            // Fetch the borrower data based on the ID
            fetch(`fetch_student_info.php?id=${borrowerId}`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error("Failed to fetch borrower data");
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.error) {
                        console.error(data.error);
                    } else {
                        // Populate form fields with the fetched data
                        document.getElementById("borrowform").value = data.id;
                        document.getElementById("idnum").value = data.idnum;
                        document.getElementById("firstname").value = data.firstname;
                        document.getElementById("middleinitial").value = data.middleinitial;
                        document.getElementById("lastname").value = data.lastname;
                        document.getElementById("department").value = data.department;
                        document.getElementById("course").value = data.course;
                        document.getElementById("email").value = data.email;
                        document.getElementById("cpnnumber").value = data.cpnnumber;

                        // Set consent checkbox
                        document.getElementById("consent").checked = data.consent == 1;

                        // Attach Accept and Reject event listeners dynamically with the correct ID
                        const acceptButton = document.querySelector(".btn-accept");
                        const rejectButton = document.querySelector(".btn-reject");

                        acceptButton.onclick = () => updateStatus(data.id, "accepted");
                        rejectButton.onclick = () => updateStatus(data.id, "rejected");
                    }
                })
                .catch(error => console.error("Error fetching borrower data:", error));
        });
    });

    function updateStatus(id, status) {
        fetch('update_status.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ id: id, status: status })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Status updated successfully!');
                location.reload(); // Refresh page to reflect changes
            } else {
                alert('Failed to update status: ' + data.error);
            }
        })
        .catch((error) => {
            console.error('Error:', error);
        });
    }

    function copyFormLink() {
        const formLink = "http://localhost/Try%20Lang/form.php";
        navigator.clipboard.writeText(formLink)
            .then(() => alert("Form link copied to clipboard!"))
            .catch(err => console.error("Failed to copy link: ", err));
    }

    window.copyFormLink = copyFormLink;
});
</script>

<script src="script.js"></script>
</body>
</html>
