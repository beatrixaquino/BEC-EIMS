<?php
// add_category.php
include_once "dbconnect.php";
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['category'])) {
    $category = trim($_POST['category']);
    if ($category === '') {
        echo json_encode(['success' => false, 'error' => 'Category cannot be empty.']);
        exit;
    }
    // Optional: Check if category already exists
    $stmt = $conn->prepare("SELECT COUNT(*) FROM categories WHERE name=?");
    $stmt->bind_param("s", $category);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();
    if ($count > 0) {
        echo json_encode(['success' => false, 'error' => 'Category already exists.']);
        exit;
    }
    // Insert new category
    $stmt = $conn->prepare("INSERT INTO categories (name) VALUES (?)");
    $stmt->bind_param("s", $category);
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Database error.']);
    }
    $stmt->close();
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request.']);
}