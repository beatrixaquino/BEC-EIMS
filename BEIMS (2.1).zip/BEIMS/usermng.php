<?php
// Start session to store messages
session_start();

// Include the database connection file
include_once "dbconnect.php";

// Handle account deletion if the delete parameter is set
if (isset($_GET['delete'])) {
    $idToDelete = $_GET['delete'];

    // Prepare and execute delete query
    $sql = "DELETE FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $idToDelete);
    $stmt->execute();

    $_SESSION['message'] = "User account deleted successfully.";

    // Redirect back to the main page
    header("Location: usermng.php");
    exit();
}

// Insert or Update admin account into the database
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = isset($_POST['id']) ? $_POST['id'] : null; // Check if 'id' exists in POST data for updating
    $username = $_POST['username'];
    $password = $_POST['password'];
    $acctype = $_POST['acctype'];

    if ($id) {
        // Update an existing admin account
        $sql = "UPDATE users SET username=?, password=?, acctype=? WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssi", $username, $password, $acctype, $id);
        $_SESSION['message'] = "Admin account updated successfully.";
    } else {
        // Insert a new admin account
        $sql = "INSERT INTO users (username, password, acctype, created_at) VALUES (?, ?, ?, NOW())";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $username, $password, $acctype);
        $_SESSION['message'] = "New admin account created successfully.";
    }
    $stmt->execute();

    header("Location: usermng.php");
    exit();
}

// Fetch all user accounts
$sql = "SELECT * FROM users";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Boxicons -->
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <!-- My CSS -->
    <link rel="stylesheet" href="istyle.css">
    <title>UserHub</title>
</head>
<body data-page="usermng">
    <!-- SIDEBAR -->
    <section id="sidebar">
        <a href="#" class="brand">
        <i class='bx bxs-package'></i>
            <span class="text">BEC EIMS</span>
        </a>
        <ul class="side-menu top">
            <li class="active">
                <a href="dashboard_superadmin.php">
                    <i class='bx bxs-dashboard'></i>
                    <span class="text">Dashboard</span>
                </a>
            </li>
            <li>
                <a href="usermng.php">
                    <i class='bx bx-group'></i>
                    <span class="text">User Management</span>
                </a>
            </li>
            <li>
                <a href="borrowform.php">
                    <i class='bx bx-clipboard'></i>
                    <span class="text">Borrowers Forms</span>
                </a>
            </li>
            <li>
                <a href="equiplist.php">
                    <i class='bx bxs-wrench' ></i>
                    <span class="text">Equipment List</span>
                </a>
            </li>
        </ul>
        <ul class="side-menu">
            <li>
                <a href="login.php" class="logout">
                    <i class='bx bxs-log-out'></i>
                    <span class="text">Logout</span>
                </a>
            </li>
        </ul>
    </section>
    <!-- SIDEBAR -->

    <!-- CONTENT -->
    <section id="content">
        <!-- NAVBAR -->
        <nav>
            <i class='bx bx-menu'></i>
            <a href="#" class="nav-link">Categories</a>
            <form id="globalSearchForm" action="#" autocomplete="off">
                <div class="form-input">
                    <input type="search" id="globalSearchInput" placeholder="Search...">
                    <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
                </div>
            </form>
            <input type="checkbox" id="switch-mode" hidden>
            <label for="switch-mode" class="switch-mode"></label>
            <a href="#" class="notification">
                <i class='bx bxs-bell'></i>
                <span class="num">8</span>
            </a>
            <a href="#" class="profile">
                <img src="img/people.png">
            </a>
        </nav>
        <!-- NAVBAR -->

        <!-- MAIN -->
        <main>
            <div class="head-title">
                <div class="left">
                    <h1>User Management</h1>
                    <ul class="breadcrumb">
                        <li><a href="#">User Management</a></li>
                        <li><i class='bx bx-chevron-right'></i></li>
                        <li><a class="active" href="#">Home</a></li>
                    </ul>
                </div>
            </div>

            <!-- Admin account table and form -->
            <div class="table-data">
                <div class="order">
                    <div class="head">
                        <h3>User Accounts</h3>
                        <i class='bx bx-filter' id="accountFilterBtn"></i>
                    </div>

                    <div class="filter-group hide" id="accountFilterGroup">
                        <button class="filter-option" data-type="all">All</button>
                        <button class="filter-option" data-type="superadmin">Superadmin</button>
                        <button class="filter-option" data-type="admin">Admin</button>
                        <button class="filter-option" data-type="teacher">Teacher</button>
                        <button class="filter-option" data-type="student">Student</button>
                    </div>

                    <!-- Table code -->
                    <table>
                        <thead>
                            <tr>
                                <th>Account Username</th>
                                <th>Account Type</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = $result->fetch_assoc()): ?>
                            <tr class="user-row" data-type="<?php echo htmlspecialchars($row['acctype']); ?>">
                                <td>
                                    <img src="img/people.png">
                                    <p><?php echo $row['username']; ?></p>
                                </td>
                                <td><?php echo $row['acctype']; ?></td>
                                <td>
                                <div class="admin-table">
                                <button 
                                    type="button"
                                    class="btn-edit admin-action-btn" 
                                    data-id="<?php echo $row['id']; ?>"
                                    data-username="<?php echo $row['username']; ?>" 
                                    data-password="<?php echo $row['password']; ?>" 
                                    data-acctype="<?php echo $row['acctype']; ?>">
                                    Edit
                                </button>
                                <a href="usermng.php?delete=<?php echo $row['id']; ?>" class="btn-delete admin-action-btn" onclick="return confirm('Are you sure you want to delete this admin?')">Delete</a>
                                </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Form for adding/editing admin accounts -->
                <div class="todo">
                    <div class="head">
                        <h3>User Account Form</h3>
                    </div>
                    <form action="usermng.php" method="POST">
                        <input type="hidden" id="admin-id" name="id">
                        
                        <div class="form-group">
                            <label for="username">Username</label>
                            <div class="input-group">
                                <input type="text" id="username" name="username" placeholder="Username" required>
                                <i class='bx bx-user'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="password">Password</label>
                            <div class="input-group">
                                <input type="text" id="password" name="password" placeholder="Your password" required>
                                <i class='bx bx-lock-alt'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="acctype">Account Type</label>
                            <div class="input-group">
                                <select id="acctype" name="acctype" required>
                                    <option value="" disabled selected>Select Account Type</option>
                                    <option value="superadmin">superadmin</option>
                                    <option value="admin">admin</option>
                                    <option value="teacher">teacher</option>
                                    <option value="student">student</option>
                                </select>
                                <i class='bx bx-chevron-down'></i>
                            </div>
                        </div>

                        <button type="submit" class="btn-submit">Submit</button>
                        <button type="button" class="btn-submit btn-cancel" onclick="clearForm()">Cancel</button>
                    </form>
                </div>
            </div>
        </main>
        <!-- MAIN -->
    </section>
    <!-- CONTENT -->

    <script src="script.js"></script>

    <script>
    // Display alert if there is a session message
    window.onload = function() {
        <?php if (isset($_SESSION['message'])): ?>
            alert("<?php echo $_SESSION['message']; ?>");
            <?php unset($_SESSION['message']); ?> // Clear message after displaying
        <?php endif; ?>
    };

    function clearForm() {
    document.getElementById('admin-id').value = '';
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';
    document.getElementById('acctype').selectedIndex = 0;
}

const accountFilterOptions = document.querySelectorAll("#accountFilterGroup .filter-option");
const userCards = document.querySelectorAll(".user-row"); // or ".user-row" for table

accountFilterOptions.forEach(btn => {
    btn.addEventListener("click", function() {
        // Remove active class from all
        accountFilterOptions.forEach(b => b.classList.remove("active"));
        this.classList.add("active");

        const type = this.getAttribute("data-type");
        userCards.forEach(card => {
            if (type === "all" || card.getAttribute("data-type") === type) {
                card.style.display = "";
            } else {
                card.style.display = "none";
            }
        });
    });
});

const accountFilterBtn = document.getElementById("accountFilterBtn");
const accountFilterGroup = document.getElementById("accountFilterGroup");

accountFilterBtn.addEventListener("click", function(e) {
    e.stopPropagation();
    accountFilterGroup.classList.toggle("hide");
});

// Hide filter group when clicking outside
document.addEventListener("click", function(e) {
    if (!accountFilterGroup.contains(e.target) && e.target !== accountFilterBtn) {
        accountFilterGroup.classList.add("hide");
    }
});

// Universal search for user rows
const globalSearchForm = document.getElementById("globalSearchForm");
const globalSearchInput = document.getElementById("globalSearchInput");

if (globalSearchForm && globalSearchInput) {
    globalSearchForm.addEventListener("submit", function(e) {
        e.preventDefault();
        const query = globalSearchInput.value.trim().toLowerCase();
        const userRows = document.querySelectorAll(".user-row");
        if (userRows.length > 0) {
            userRows.forEach(row => {
                // Search in all table cells for this row
                const rowText = row.textContent.toLowerCase();
                if (rowText.includes(query)) {
                    row.style.display = "";
                } else {
                    row.style.display = "none";
                }
            });
        }
    });

    // Optional: Live search as you type
    globalSearchInput.addEventListener("input", function() {
        const query = globalSearchInput.value.trim().toLowerCase();
        const userRows = document.querySelectorAll(".user-row");
        if (userRows.length > 0) {
            userRows.forEach(row => {
                const rowText = row.textContent.toLowerCase();
                if (rowText.includes(query)) {
                    row.style.display = "";
                } else {
                    row.style.display = "none";
                }
            });
        }
    });
}
</script>
</body>
</html>
