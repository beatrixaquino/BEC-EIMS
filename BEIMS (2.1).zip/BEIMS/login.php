<?php
session_start();
include_once "dbconnect.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!empty($_POST['username']) && !empty($_POST['password'])) {
        $user = trim($_POST['username']);
        $pass = trim($_POST['password']);

        // Ensure connection exists
        if (!$conn) {
            die("Database connection failed: " . mysqli_connect_error());
        }

        // Securely fetch user data
        $sql = "SELECT * FROM users WHERE username = ?";
        $stmt = $conn->prepare($sql);

        if (!$stmt) {
            die("Prepare failed: " . $conn->error);
        }

        $stmt->bind_param("s", $user);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();

            // Check plain text (for development) or hashed passwords (for production)
            if ($row['password'] === $pass || password_verify($pass, $row['password'])) {
                session_regenerate_id(true);
                $_SESSION['username'] = $user;
                $_SESSION['acctype'] = $row['acctype'];

                // Redirect based on user role
                $redirect_pages = [
                    'superadmin' => 'dashboard_superadmin.php',
                    'admin' => 'dashboard_admin.php',
                    'teacher' => 'dashboard_teacher.php',
                    'student' => 'dashboard_student.php'
                ];

                header("Location: " . ($redirect_pages[$row['acctype']] ?? 'index.html'));
                exit();
            } else {
                echo "<script>alert('Invalid password!'); window.location.href = 'login.php';</script>";
                exit();
            }
        } else {
            echo "<script>alert('User not found!'); window.location.href = 'login.php';</script>";
            exit();
        }

        $stmt->close();
    } else {
        echo "<script>alert('Please provide both username and password!'); window.location.href = 'login.php';</script>";
        exit();
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http.equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title> Login </title>
  <link rel="stylesheet" href="style.css">
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>

<body>

    <div class="wrapper">
        <form action="login.php" method="POST">
            <h1>Login</h1>
            <div class="input-box">
                <input type="text" id="username" name="username" placeholder="Username" required>
                <i class='bx bxs-user'></i>
            </div>
            <div class="input-box">
                <input type="password" id="password" name="password" placeholder="Password" required>
                <i class='bx bxs-lock-alt' id="togglePassword" onclick="togglePassword()" style="display: none;"></i>
                <i class='bx bx-show' id="showIcon" onclick="togglePassword()" style="display: inline;"></i>
                <i class='bx bx-hide' id="hideIcon" onclick="togglePassword()" style="display: none;"></i>
            </div>

            <div class="remember-forgot"><label><input type="checkbox"> Remember me </label><a href="#">Forgot Password?</a></div>
            <button type="submit" class="btn">Login</button>

            <div class="register-link">
                <p>Don't have an account? <a href="#">Register</a> </p>
            </div>
        </form>
    </div>

    <script>
        function togglePassword() {
            const passwordInput = document.getElementById('password');
            const showIcon = document.getElementById('showIcon');
            const hideIcon = document.getElementById('hideIcon');

            if (passwordInput.type === 'password') {
                passwordInput.type = 'text'; // Show the password
                showIcon.style.display = 'none'; // Hide show icon
                hideIcon.style.display = 'inline-block'; // Show hide icon
            } else {
                passwordInput.type = 'password'; // Hide the password
                showIcon.style.display = 'inline-block'; // Show show icon
                hideIcon.style.display = 'none'; // Hide hide icon
            }
        }
    </script>

</body>
</html>
