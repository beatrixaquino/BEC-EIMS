<?php
/**
 * Comprehensive Notification System
 * Handles role-based notifications for all system events
 */

include_once "dbconnect.php";

/**
 * Notification Types by Role
 */
class NotificationTypes {
    // Borrower notifications (students/teachers)
    const BORROWER_NOTIFICATIONS = [
        'form_submitted' => 'Form submitted successfully',
        'form_failed' => 'Form submission failed',
        'form_approved' => 'Your form has been approved',
        'form_rejected' => 'Your form has been rejected',
        'return_received' => 'Return confirmed by admin',
        'due_soon' => 'Item due soon',
        'overdue_item' => 'Item is overdue',
        'form_edited_by_admin' => 'Your form was edited by admin',
        'item_unavailable' => 'Requested item is unavailable',
        'return_reminder' => 'Return reminder'
    ];
    
    // Admin notifications
    const ADMIN_NOTIFICATIONS = [
        'new_form' => 'New borrower form submitted',
        'borrow_request_for_date' => 'Request for future event date',
        'overdue_item_exists' => 'Item has passed due date',
        'inventory_audit_soon' => 'Upcoming inventory check',
        'equipment_added' => 'New equipment added',
        'equipment_edited' => 'Equipment was edited',
        'equipment_deleted' => 'Equipment was deleted',
        'category_added' => 'New category added',
        'category_edited' => 'Category was edited',
        'category_deleted' => 'Category was deleted',
        'account_added' => 'New user account added',
        'account_edited' => 'User account edited',
        'account_deactivated' => 'User account deactivated',
        'account_reactivated' => 'User account reactivated',
        'form_cancelled_by_user' => 'Form cancelled by user',
        'item_running_low' => 'Item inventory running low',
        'form_auto_cancelled' => 'Form automatically cancelled',
        'system_error_log' => 'System error occurred',
        'login_activity' => 'Unusual login activity'
    ];
}

/**
 * Notification System Class
 */
class NotificationSystem {
    private $conn;
    
    public function __construct($conn) {
        $this->conn = $conn;
    }
    
    /**
     * Create notification for specific user
     */
    public function createNotification($user_id, $title, $message, $type, $related_id = null) {
        $sql = "INSERT INTO notifications (user_id, title, message, type, related_id, created_at) VALUES (?, ?, ?, ?, ?, NOW())";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("isssi", $user_id, $title, $message, $type, $related_id);
        return $stmt->execute();
    }
    
    /**
     * Create notification for multiple users
     */
    public function createNotificationForUsers($user_ids, $title, $message, $type, $related_id = null) {
        $success = true;
        foreach ($user_ids as $user_id) {
            if (!$this->createNotification($user_id, $title, $message, $type, $related_id)) {
                $success = false;
            }
        }
        return $success;
    }
    
    /**
     * Create notification for all admins/superadmins
     */
    public function notifyAdmins($title, $message, $type, $related_id = null) {
        // For now, hardcode superadmin user_id = 1 since that's the known superadmin ID
        $admin_ids = [1]; // Superadmin user_id = 1
        
        // In the future, you can uncomment this to dynamically get admin IDs:
        // $sql = "SELECT id FROM users WHERE acctype IN ('admin', 'superadmin')";
        // $result = $this->conn->query($sql);
        // $admin_ids = [];
        // while ($row = $result->fetch_assoc()) {
        //     $admin_ids[] = $row['id'];
        // }
        
        return $this->createNotificationForUsers($admin_ids, $title, $message, $type, $related_id);
    }
    
    /**
     * Create notification for all superadmins only
     */
    public function notifySuperAdmins($title, $message, $type, $related_id = null) {
        // For now, hardcode superadmin user_id = 1 since that's the known superadmin ID
        $superadmin_ids = [1]; // Superadmin user_id = 1
        
        // In the future, you can uncomment this to dynamically get superadmin IDs:
        // $sql = "SELECT id FROM users WHERE acctype = 'superadmin'";
        // $result = $this->conn->query($sql);
        // $superadmin_ids = [];
        // while ($row = $result->fetch_assoc()) {
        //     $superadmin_ids[] = $row['id'];
        // }
        
        return $this->createNotificationForUsers($superadmin_ids, $title, $message, $type, $related_id);
    }
    
    /**
     * Get user role from session
     */
    public function getUserRole() {
        if (isset($_SESSION['acctype'])) {
            switch ($_SESSION['acctype']) {
                case 'student':
                    return 'borrower';
                case 'teacher':
                    return 'borrower';
                case 'admin':
                    return 'admin';
                case 'superadmin':
                    return 'superadmin';
                default:
                    return 'borrower';
            }
        }
        return 'borrower';
    }
    
    /**
     * Check if user is admin/superadmin
     */
    public function isAdmin() {
        $role = $this->getUserRole();
        return $role === 'admin' || $role === 'superadmin';
    }
    
    /**
     * Check if user is superadmin
     */
    public function isSuperAdmin() {
        return $this->getUserRole() === 'superadmin';
    }
}

/**
 * Event-specific notification functions
 */
class NotificationEvents {
    private $notificationSystem;
    
    public function __construct($notificationSystem) {
        $this->notificationSystem = $notificationSystem;
    }
    
    /**
     * Form submission events
     */
    public function onFormSubmitted($borrower_id, $borrower_user_id, $submitter_name, $department) {
        // Notify borrower
        if ($borrower_user_id) {
            $this->notificationSystem->createNotification(
                $borrower_user_id,
                "Form Submitted Successfully",
                "Your borrow request has been submitted successfully. Request ID: #{$borrower_id}",
                "form_submitted",
                $borrower_id
            );
        }
        
        // Notify admins
        $this->notificationSystem->notifyAdmins(
            "New Borrow Form Submitted",
            "A new borrow form has been submitted by {$submitter_name} ({$department})",
            "new_form",
            $borrower_id
        );
    }
    
    /**
     * Form status change events
     */
    public function onFormStatusChanged($borrower_id, $borrower_user_id, $borrower_name, $new_status) {
        $status_messages = [
            'approved' => 'approved',
            'rejected' => 'rejected',
            'returned' => 'returned'
        ];
        
        $status = $status_messages[$new_status] ?? $new_status;
        
        // Notify borrower
        if ($borrower_user_id) {
            $this->notificationSystem->createNotification(
                $borrower_user_id,
                "Form Status Updated",
                "Your borrow request has been {$status}",
                "form_{$new_status}",
                $borrower_id
            );
        }
        
        // Notify admins about status change
        $this->notificationSystem->notifyAdmins(
            "Form Status Updated",
            "Form for {$borrower_name} has been {$status}",
            "form_{$new_status}",
            $borrower_id
        );
    }
    
    /**
     * Equipment management events
     */
    public function onEquipmentAdded($item_name, $added_by_user_id) {
        $this->notificationSystem->notifyAdmins(
            "New Equipment Added",
            "Equipment '{$item_name}' has been added to the system",
            "equipment_added",
            null
        );
    }
    
    public function onEquipmentEdited($item_name, $edited_by_user_id) {
        $this->notificationSystem->notifyAdmins(
            "Equipment Edited",
            "Equipment '{$item_name}' has been modified",
            "equipment_edited",
            null
        );
    }
    
    public function onEquipmentDeleted($item_name, $deleted_by_user_id) {
        $this->notificationSystem->notifyAdmins(
            "Equipment Deleted",
            "Equipment '{$item_name}' has been removed from the system",
            "equipment_deleted",
            null
        );
    }
    
    /**
     * Category management events
     */
    public function onCategoryAdded($category_name, $added_by_user_id) {
        $this->notificationSystem->notifyAdmins(
            "New Category Added",
            "Category '{$category_name}' has been added",
            "category_added",
            null
        );
    }
    
    public function onCategoryEdited($category_name, $edited_by_user_id) {
        $this->notificationSystem->notifyAdmins(
            "Category Edited",
            "Category '{$category_name}' has been modified",
            "category_edited",
            null
        );
    }
    
    public function onCategoryDeleted($category_name, $deleted_by_user_id) {
        $this->notificationSystem->notifyAdmins(
            "Category Deleted",
            "Category '{$category_name}' has been removed",
            "category_deleted",
            null
        );
    }
    
    /**
     * User account management events
     */
    public function onAccountAdded($username, $account_type, $added_by_user_id) {
        $this->notificationSystem->notifyAdmins(
            "New Account Added",
            "New {$account_type} account '{$username}' has been created",
            "account_added",
            null
        );
    }
    
    public function onAccountEdited($username, $account_type, $edited_by_user_id) {
        $this->notificationSystem->notifyAdmins(
            "Account Edited",
            "{$account_type} account '{$username}' has been modified",
            "account_edited",
            null
        );
    }
    
    public function onAccountDeactivated($username, $account_type, $deactivated_by_user_id) {
        $this->notificationSystem->notifyAdmins(
            "Account Deactivated",
            "{$account_type} account '{$username}' has been deactivated",
            "account_deactivated",
            null
        );
    }
    
    public function onAccountReactivated($username, $account_type, $reactivated_by_user_id) {
        $this->notificationSystem->notifyAdmins(
            "Account Reactivated",
            "{$account_type} account '{$username}' has been reactivated",
            "account_reactivated",
            null
        );
    }
    
    /**
     * Form failure events
     */
    public function onFormFailed($borrower_user_id, $reason) {
        if ($borrower_user_id) {
            $this->notificationSystem->createNotification(
                $borrower_user_id,
                "Form Submission Failed",
                "Your borrow request could not be submitted: {$reason}",
                "form_failed",
                null
            );
        }
    }
    
    /**
     * Due date events
     */
    public function onDueSoon($borrower_user_id, $item_name, $due_date) {
        if ($borrower_user_id) {
            $this->notificationSystem->createNotification(
                $borrower_user_id,
                "Item Due Soon",
                "Your borrowed item '{$item_name}' is due on {$due_date}",
                "due_soon",
                null
            );
        }
    }
    
    public function onOverdueItem($borrower_user_id, $item_name) {
        if ($borrower_user_id) {
            $this->notificationSystem->createNotification(
                $borrower_user_id,
                "Item Overdue",
                "Your borrowed item '{$item_name}' is overdue. Please return it immediately.",
                "overdue_item",
                null
            );
        }
        
        // Also notify admins about overdue items
        $this->notificationSystem->notifyAdmins(
            "Overdue Item Detected",
            "Item '{$item_name}' is overdue",
            "overdue_item_exists",
            null
        );
    }
    
    /**
     * Return confirmation events
     */
    public function onReturnConfirmed($borrower_user_id, $item_name, $confirmed_by_admin) {
        if ($borrower_user_id) {
            $this->notificationSystem->createNotification(
                $borrower_user_id,
                "Return Confirmed",
                "Your return of '{$item_name}' has been confirmed by {$confirmed_by_admin}",
                "return_received",
                null
            );
        }
    }
    
    /**
     * Inventory events
     */
    public function onItemRunningLow($item_name, $current_quantity, $threshold = 5) {
        $this->notificationSystem->notifyAdmins(
            "Low Inventory Alert",
            "Item '{$item_name}' is running low (Current: {$current_quantity}, Threshold: {$threshold})",
            "item_running_low",
            null
        );
    }
    
    public function onItemUnavailable($borrower_user_id, $item_name) {
        if ($borrower_user_id) {
            $this->notificationSystem->createNotification(
                $borrower_user_id,
                "Item Unavailable",
                "The requested item '{$item_name}' is currently unavailable",
                "item_unavailable",
                null
            );
        }
    }
}

// Initialize the notification system
$notificationSystem = new NotificationSystem($conn);
$notificationEvents = new NotificationEvents($notificationSystem);

// Helper function to get notification system instance
function getNotificationSystem() {
    global $notificationSystem;
    return $notificationSystem;
}

// Helper function to get notification events instance
function getNotificationEvents() {
    global $notificationEvents;
    return $notificationEvents;
}
?> 