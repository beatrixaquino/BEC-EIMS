<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Output as JSON
header('Content-Type: application/json');

// Include the database connection
include_once "dbconnect.php";

// Check if the 'item_id' is passed via GET request
if (isset($_GET['item_id'])) {
    $item_id = intval($_GET['item_id']);  // Sanitize input

    // Query to get categories for this item
    $sql = "SELECT c.id, c.name FROM item_categories ic 
            JOIN categories c ON ic.category_id = c.id 
            WHERE ic.item_id = ?";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        echo json_encode(["error" => "Query preparation failed: " . $conn->error]);
        exit();
    }

    $stmt->bind_param("i", $item_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $categories = [];
    while ($row = $result->fetch_assoc()) {
        $categories[] = [
            'id' => $row['id'],
            'name' => ucfirst($row['name'])
        ];
    }
    
    echo json_encode($categories);

    $stmt->close();
} else {
    echo json_encode(["error" => "No item_id provided."]);
}

$conn->close();
?> 