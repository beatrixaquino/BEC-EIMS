-- Simple fix for date issues (keeping 'approved' status)

-- Step 1: Check current data
SELECT id, firstname, lastname, borrow_date, return_date, status FROM borrowers LIMIT 10;

-- Step 2: Check for any invalid dates (0000-00-00)
SELECT id, firstname, lastname, borrow_date, return_date 
FROM borrowers 
WHERE borrow_date = '0000-00-00' OR return_date = '0000-00-00';

-- Step 3: Fix any invalid dates by setting them to NULL
UPDATE borrowers SET borrow_date = NULL WHERE borrow_date = '0000-00-00';
UPDATE borrowers SET return_date = NULL WHERE return_date = '0000-00-00';

-- Step 4: Verify the fix
SELECT id, firstname, lastname, borrow_date, return_date, status FROM borrowers LIMIT 10;

-- Step 5: Check status enum is correct
DESCRIBE borrowers; 