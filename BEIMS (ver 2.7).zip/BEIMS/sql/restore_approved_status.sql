-- Restore 'approved' status to the enum
-- This fixes the issue where 'approved' was removed from the enum

-- Step 1: Check current enum values
SELECT DISTINCT status FROM borrowers;

-- Step 2: Update the enum to include 'approved' again
ALTER TABLE borrowers MODIFY COLUMN status ENUM('pending', 'approved', 'rejected', 'returned') DEFAULT 'pending';

-- Step 3: Verify the fix
SELECT DISTINCT status FROM borrowers;
DESCRIBE borrowers;

-- Step 4: Test that 'approved' is now a valid value
-- This should work without error:
UPDATE borrowers SET status = 'approved' WHERE id = 1 LIMIT 1; 