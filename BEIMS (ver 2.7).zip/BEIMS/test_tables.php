<?php
include_once "dbconnect.php";

echo "<h2>Testing Database Tables</h2>";

// Check if requested_items table exists
$sql = "SHOW TABLES LIKE 'requested_items'";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    echo "<p style='color: green;'>✅ requested_items table exists</p>";
} else {
    echo "<p style='color: red;'>❌ requested_items table does not exist</p>";
}

// Check if item_list table exists
$sql = "SHOW TABLES LIKE 'item_list'";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    echo "<p style='color: green;'>✅ item_list table exists</p>";
} else {
    echo "<p style='color: red;'>❌ item_list table does not exist</p>";
}

// Check requested_items structure
echo "<h3>requested_items table structure:</h3>";
$sql = "DESCRIBE requested_items";
$result = $conn->query($sql);
if ($result) {
    echo "<table border='1'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['Field'] . "</td>";
        echo "<td>" . $row['Type'] . "</td>";
        echo "<td>" . $row['Null'] . "</td>";
        echo "<td>" . $row['Key'] . "</td>";
        echo "<td>" . $row['Default'] . "</td>";
        echo "<td>" . $row['Extra'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
}

// Check item_list structure
echo "<h3>item_list table structure:</h3>";
$sql = "DESCRIBE item_list";
$result = $conn->query($sql);
if ($result) {
    echo "<table border='1'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['Field'] . "</td>";
        echo "<td>" . $row['Type'] . "</td>";
        echo "<td>" . $row['Null'] . "</td>";
        echo "<td>" . $row['Key'] . "</td>";
        echo "<td>" . $row['Default'] . "</td>";
        echo "<td>" . $row['Extra'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
}

// Check sample data
echo "<h3>Sample data from requested_items:</h3>";
$sql = "SELECT * FROM requested_items LIMIT 3";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    echo "<table border='1'>";
    echo "<tr>";
    while ($row = $result->fetch_assoc()) {
        foreach ($row as $key => $value) {
            echo "<th>" . $key . "</th>";
        }
        break;
    }
    echo "</tr>";
    
    $result->data_seek(0);
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        foreach ($row as $value) {
            echo "<td>" . $value . "</td>";
        }
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No data in requested_items table</p>";
}

// Check sample data from item_list
echo "<h3>Sample data from item_list:</h3>";
$sql = "SELECT * FROM item_list LIMIT 3";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    echo "<table border='1'>";
    echo "<tr>";
    while ($row = $result->fetch_assoc()) {
        foreach ($row as $key => $value) {
            echo "<th>" . $key . "</th>";
        }
        break;
    }
    echo "</tr>";
    
    $result->data_seek(0);
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        foreach ($row as $value) {
            echo "<td>" . $value . "</td>";
        }
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No data in item_list table</p>";
}

$conn->close();
?> 