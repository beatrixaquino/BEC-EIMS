<?php
// Simple test to check fetch_borrowed_items.php
echo "<h2>Testing fetch_borrowed_items.php</h2>";

// Test with a sample borrower ID
$test_id = isset($_GET['id']) ? intval($_GET['id']) : 1;

echo "<p>Testing with borrower ID: " . $test_id . "</p>";

// Make a request to fetch_borrowed_items.php
$url = "fetch_borrowed_items.php?form_id=" . $test_id;
echo "<p>Requesting: " . $url . "</p>";

$response = file_get_contents($url);
echo "<p>Response:</p>";
echo "<pre>" . htmlspecialchars($response) . "</pre>";

// Try to decode as JSON
$json_data = json_decode($response, true);
if ($json_data === null) {
    echo "<p style='color: red;'>Error: Invalid JSON response</p>";
    echo "<p>JSON error: " . json_last_error_msg() . "</p>";
} else {
    echo "<p style='color: green;'>Valid JSON response</p>";
    echo "<p>Number of items: " . count($json_data) . "</p>";
    if (count($json_data) > 0) {
        echo "<table border='1'>";
        echo "<tr><th>Item Name</th><th>Quantity</th><th>Unit</th></tr>";
        foreach ($json_data as $item) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($item['item_name']) . "</td>";
            echo "<td>" . htmlspecialchars($item['quantity']) . "</td>";
            echo "<td>" . htmlspecialchars($item['unit']) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
}
?> 