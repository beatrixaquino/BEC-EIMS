<?php
// Start session and include DB connection
session_start();
include_once 'dbconnect.php'; // adjust if your connection file has a different name

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve data from the form
    $id = isset($_POST['id']) && !empty($_POST['id']) ? intval($_POST['id']) : null;
    $idnum = $_POST['idnum'];
    $firstname = $_POST['firstname'];
    $middleinitial = $_POST['middleinitial'];
    $lastname = $_POST['lastname'];
    $department = $_POST['department'];
    $course = $_POST['course'];
    $email = $_POST['email'];
    $cpnnumber = $_POST['cpnnumber'];
    $consent = isset($_POST['consent']) ? 1 : 0; // Set consent to 1 if checked
    $formstatus = $_POST['formstatus'];
    
    // Handle course field based on department
    if ($department === "Faculty Member") {
        $course = null; // Set course to null for faculty members
    }
    // Properly format dates for database storage
    $borrow_date = !empty($_POST['borrow_date']) ? date('Y-m-d', strtotime($_POST['borrow_date'])) : null;
    $return_date = !empty($_POST['return_date']) ? date('Y-m-d', strtotime($_POST['return_date'])) : null;

    if ($id) {
        // ✅ UPDATE existing borrower
        $sql = "UPDATE borrowers SET idnum=?, firstname=?, middleinitial=?, lastname=?, department=?, course=?, email=?, cpnnumber=?, consent=?, status=?, borrow_date=?, return_date=? WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssssssssi", $idnum, $firstname, $middleinitial, $lastname, $department, $course, $email, $cpnnumber, $consent, $formstatus, $borrow_date, $return_date, $id);
    } else {
        // ✅ INSERT new borrower
        $user_id = $_SESSION['user_id'] ?? null;
        $sql = "INSERT INTO borrowers (idnum, firstname, middleinitial, lastname, department, course, email, cpnnumber, consent, status, borrow_date, return_date, user_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssssssssi", $idnum, $firstname, $middleinitial, $lastname, $department, $course, $email, $cpnnumber, $consent, $formstatus, $borrow_date, $return_date, $user_id);
    }

    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        // Create notifications for status updates
        include_once "notification_helper.php";
        
        if ($id) {
            // Update notification for status change
            $borrower_name = $firstname . " " . $lastname;
            $status_message = "";
            $notification_type = "";
            
            switch ($formstatus) {
                case "approved":
                    $status_message = "Your borrow request has been approved!";
                    $notification_type = "form_approved";
                    break;
                case "rejected":
                    $status_message = "Your borrow request has been rejected.";
                    $notification_type = "form_rejected";
                    break;
                case "returned":
                    $status_message = "Your borrowed items have been returned successfully.";
                    $notification_type = "form_returned";
                    break;
            }
            
            if ($status_message) {
                // Get the borrower's user_id
                $borrower_sql = "SELECT user_id FROM borrowers WHERE id = ? AND deleted_at IS NULL";
                $borrower_stmt = $conn->prepare($borrower_sql);
                $borrower_stmt->bind_param("i", $id);
                $borrower_stmt->execute();
                $borrower_result = $borrower_stmt->get_result();
                
                if ($borrower_result->num_rows > 0) {
                    $borrower_data = $borrower_result->fetch_assoc();
                    $borrower_user_id = $borrower_data['user_id'];
                    
                    // Use the new notification system
                    include_once "notification_system.php";
                    $notificationEvents = getNotificationEvents();
                    $notificationEvents->onFormStatusChanged($id, $borrower_user_id, $borrower_name, $formstatus);
                }
            }
        }
        
        $_SESSION['message'] = $id ? "Borrower updated successfully!" : "Submission successful!";
    } else {
        $_SESSION['message'] = "Database operation failed. Please try again.";
    }

    $stmt->close();
    header("Location: borrowform.php");
    exit();
}

// Load borrower data if ID is provided via GET parameter
$editBorrowerId = isset($_GET['id']) ? intval($_GET['id']) : null;
$editBorrowerData = null;

if ($editBorrowerId) {
    $editStmt = $conn->prepare("SELECT * FROM borrowers WHERE id = ? AND deleted_at IS NULL");
    $editStmt->bind_param("i", $editBorrowerId);
    $editStmt->execute();
    $editResult = $editStmt->get_result();
    
    if ($editResult->num_rows > 0) {
        $editBorrowerData = $editResult->fetch_assoc();
    }
    $editStmt->close();
}

// Fetch existing submissions with optional status filtering
$statusFilter = isset($_GET['filter']) ? $_GET['filter'] : null;

if ($statusFilter) {
    $stmt = $conn->prepare("SELECT * FROM borrowers WHERE status = ? AND deleted_at IS NULL ORDER BY created_at DESC");
    $stmt->bind_param("s", $statusFilter);
} else {
    $stmt = $conn->prepare("SELECT * FROM borrowers WHERE deleted_at IS NULL ORDER BY created_at DESC");
}

$stmt->execute();
$result = $stmt->get_result();
ob_end_flush(); // Flush output buffer
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="istyle.css">
    <style>
        #courseGroup {
            transition: opacity 0.3s ease-in-out;
        }
    </style>
    <title>Superadmin Hub</title>
</head>
<body data-page="borrowform">

<!-- SIDEBAR -->
<section id="sidebar">
		<a href="#" class="brand">
			<i class='bx bxs-package' ></i>
			<span class="text">BEC EIMS</span>
		</a>
		<ul class="side-menu top">
			<li class="active">
				<a href="dashboard_superadmin.php">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Dashboard</span>
				</a>
			</li>
			<li>
				<a href="usermng.php">
					<i class='bx bx-group' ></i>
					<span class="text">User Management</span>
				</a>
			</li>
			<li class="dropdown" id="borrowersDropdown">
				<a href="borrowform.php" class="dropdown-toggle">
					<i class='bx bxs-report'></i>
					<span class="text">Borrowers Forms</span>
					<i class='bx bx-chevron-down dropdown-arrow'></i>
				</a>
				<ul class="dropdown-menu" id="borrowersDropdownMenu">
					<li><a href="borrowform.php"><i class='bx bxs-report'></i> All Forms</a></li>
					<li><a href="manage_deleted_records.php"><i class='bx bxs-trash'></i> Deleted Records</a></li>
					<li><a href="borrowform.php?filter=pending"><i class='bx bxs-time'></i> Pending Forms</a></li>
					<li><a href="borrowform.php?filter=approved"><i class='bx bxs-check-circle'></i> Approved Forms</a></li>
					<li><a href="borrowform.php?filter=rejected"><i class='bx bxs-x-circle'></i> Rejected Forms</a></li>
					<li><a href="borrowform.php?filter=returned"><i class='bx bxs-archive'></i> Returned Forms</a></li>
				</ul>
			</li>
			<li>
				<a href="equiplist.php">
					<i class='bx bxs-id-card'></i>
					<span class="text">Equipment List</span>
				</a>
			</li>
		</ul>
		<ul class="side-menu">
			<li>
				<a href="login.php" class="logout">
					<i class='bx bxs-log-out' ></i>
					<span class="text">Logout</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->


    <!-- CONTENT -->
    <section id="content">
        <nav>
            <i class='bx bx-menu'></i>
            <a href="#" class="nav-link">Categories</a>
            <form id="globalSearchForm" action="#" autocomplete="off">
                <div class="form-input">
                    <input type="search" id="globalSearchInput" placeholder="Search borrowers...">
                    <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
                </div>
            </form>
            <input type="checkbox" id="switch-mode" hidden>
            <label for="switch-mode" class="switch-mode"></label>
            <a href="#" class="notification" id="notificationIcon">
                <i class='bx bxs-bell'></i>
                <span class="num" id="notificationCount">0</span>
            </a>
            <div class="notification-dropdown" id="notificationDropdown" style="display: none;">
                <div class="notification-header">
                    <h4>Notifications</h4>
                    <button id="markAllRead" class="mark-all-read">Mark all read</button>
                </div>
                <div class="notification-list" id="notificationList">
                    <!-- Notifications will be loaded here -->
                </div>
            </div>
            <a href="#" class="profile">
                <img src="img/people.png">
            </a>
        </nav>

        <main>
                        <div class="head-title">
				<div class="left">
					<h1>
						<?php 
						$filter = $_GET['filter'] ?? '';
						if ($filter) {
							echo "Borrowers Forms - " . ucfirst($filter);
						} else {
							echo "Borrowers Forms";
						}
						?>
					</h1>
					<ul class="breadcrumb">
						<li>
							<a href="#">Borrowers Forms</a>
						</li>
						<li><i class='bx bx-chevron-right'></i></li>
						<li>
							<a class="active" href="submforms.php">
								<?php 
								if ($filter) {
									echo ucfirst($filter) . " Forms";
								} else {
									echo "Form";
								}
								?>
							</a>
						</li>
					</ul>
				</div>
                <a href="#" class="btn-download" onclick="copyFormLink()">
    <i class='bx bx-copy'></i>
    <span class="text">Generate Report</span>
</a>
            </div>

            <div class="table-data">
            <div class="order">
        <div class="head">
            <h3>Borrowers Forms</h3>
            <i class='bx bx-sort' id="sortBtn" title="Toggle Sort Order"></i>
            <i class='bx bx-filter' id="filterBtn"></i>
        </div>

        <div class="filter-group" id="filterGroup">
            <button class="filter-option" data-status="all">All</button>
            <button class="filter-option" data-status="pending">Pending</button>
            <button class="filter-option" data-status="approved">Approved</button>
            <button class="filter-option" data-status="rejected">Rejected</button>
            <button class="filter-option" data-status="returned">Returned</button>
        </div>
        <table>
    <thead>
        <tr>
            <th>Borrower's Name</th>
            <th>Date Submitted</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($result && $result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr data-id="<?php echo $row['id']; ?>" class="student-row">
                    <td><?php echo htmlspecialchars($row['firstname'] . ' ' . $row['lastname']); ?></td>
                    <td><?php echo htmlspecialchars(date("F j, Y g:i A", strtotime($row['created_at']))); ?></td>
                    <td id="status-<?php echo $row['id']; ?>">
                        <span class="status <?php echo $row['status']; ?>"><?php echo ucfirst(htmlspecialchars($row['status'])); ?></span>
                    </td>
                    <td>
                        <button type="button" class="btn-delete" onclick="softDeleteBorrower(<?php echo $row['id']; ?>)" title="Delete">
                            <i class='bx bx-trash'></i>
                            <span>Delete</span>
                        </button>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="4">No records found.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
            </div>
                <div class="todo">
                    <div class="head">
                        <h3>Tool Borrowers Form</h3>
                    </div>
                    <form id="studentDetailsForm" action="borrowform.php" method="POST" enctype="multipart/form-data">
                        <input type="hidden" id="borrowform" name="id" value="<?php echo $editBorrowerData ? $editBorrowerData['id'] : ''; ?>">
                        
                        <div class="form-group">
                            <label for="idnum">ID Number</label>
                            <div class="input-group">
                                <input type="text" id="idnum" name="idnum" placeholder="ID Number" required value="<?php echo $editBorrowerData ? htmlspecialchars($editBorrowerData['idnum']) : ''; ?>">
                                <i class='bx bx-id-card'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="firstname">First Name</label>
                            <div class="input-group">
                                <input type="text" id="firstname" name="firstname" placeholder="First Name" required value="<?php echo $editBorrowerData ? htmlspecialchars($editBorrowerData['firstname']) : ''; ?>">
                                <i class='bx bx-user'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="middleinitial">Middle Initial</label>
                            <div class="input-group">
                                <input type="text" id="middleinitial" name="middleinitial" placeholder="Middle Initial" required value="<?php echo $editBorrowerData ? htmlspecialchars($editBorrowerData['middleinitial']) : ''; ?>">
                                <i class='bx bx-user'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="lastname">Last Name</label>
                            <div class="input-group">
                                <input type="text" id="lastname" name="lastname" placeholder="Last Name" required value="<?php echo $editBorrowerData ? htmlspecialchars($editBorrowerData['lastname']) : ''; ?>">
                                <i class='bx bx-user'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="department">Department</label>
                            <div class="input-group">
                                <select id="department" name="department" required>
                                    <option value="" disabled <?php echo !$editBorrowerData ? 'selected' : ''; ?>>Select Department</option>
                                    <option value="Student" <?php echo ($editBorrowerData && $editBorrowerData['department'] == 'Student') ? 'selected' : ''; ?>>Student</option>
                                    <option value="Faculty Member" <?php echo ($editBorrowerData && $editBorrowerData['department'] == 'Faculty Member') ? 'selected' : ''; ?>>Faculty Member</option>
                                </select>
                                <i class='bx bx-chevron-down'></i>
                            </div>
                        </div>

                        <div class="form-group" id="courseGroup">
                            <label for="course">Course</label>
                            <div class="input-group">
                                <select id="course" name="course">
                                    <option value="" disabled <?php echo !$editBorrowerData ? 'selected' : ''; ?>>Select Course</option>
                                    <option value="cookery" <?php echo ($editBorrowerData && $editBorrowerData['course'] == 'cookery') ? 'selected' : ''; ?>>CHRM Cookery NC II</option>
                                    <option value="fbs" <?php echo ($editBorrowerData && $editBorrowerData['course'] == 'fbs') ? 'selected' : ''; ?>>CHRM Food and Beverages NC II</option>
                                    <option value="fos" <?php echo ($editBorrowerData && $editBorrowerData['course'] == 'fos') ? 'selected' : ''; ?>>CHRM Front Office Services NC II</option>
                                    <option value="housekeeping" <?php echo ($editBorrowerData && $editBorrowerData['course'] == 'housekeeping') ? 'selected' : ''; ?>>CHRM Housekeeping NC II</option>
                                    <option value="bartending" <?php echo ($editBorrowerData && $editBorrowerData['course'] == 'bartending') ? 'selected' : ''; ?>>CHRM Bartending NC II</option>
                                </select>
                                <i class='bx bx-chevron-down'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="email">School Email</label>
                            <div class="input-group">
                                <input type="email" id="email" name="email" placeholder="School Email" required value="<?php echo $editBorrowerData ? htmlspecialchars($editBorrowerData['email']) : ''; ?>">
                                <i class='bx bx-envelope'></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="cpnnumber">Contact Number</label>
                            <div class="input-group">
                                <input type="text" id="cpnnumber" name="cpnnumber" placeholder="Contact Number" required value="<?php echo $editBorrowerData ? htmlspecialchars($editBorrowerData['cpnnumber']) : ''; ?>">
                                <i class='bx bx-phone'></i>
                            </div>
                        </div>

                        <div class="borrowed-items-card">
    <h3>Borrowed Items</h3>
    <table class="borrowed-items-table">
        <thead>
            <tr>
                <th>Item Name</th>
                <th>Quantity</th>
            </tr>
        </thead>
        <tbody id="borrowedItemsTable">
            
        </tbody>
    </table>
</div>

<div class="borrow-dates">
    <div class="form-group">
        <label for="borrow_date">Borrow Date</label>
        <div class="input-group">
            <input type="date" id="borrow_date" name="borrow_date" required value="<?php echo $editBorrowerData ? $editBorrowerData['borrow_date'] : ''; ?>">
        </div>
    </div>

    <div class="form-group">
        <label for="return_date">Return Date</label>
        <div class="input-group">
            <input type="date" id="return_date" name="return_date" required value="<?php echo $editBorrowerData ? $editBorrowerData['return_date'] : ''; ?>">
        </div>
    </div>
</div>

                        <!-- Consent Checkbox -->
						<div class="form-group">
							<label class="checkbox-container">
								<input type="checkbox" id="consent" name="consent" required <?php echo ($editBorrowerData && $editBorrowerData['consent'] == 1) ? 'checked' : ''; ?>>
								<span>I confirm that all the information I have provided is accurate and correct, and I consent to its use for processing my equipment borrowing request.</span>
							</label>
						</div>
                    
                        <div class="form-group">
                            <label for="formstatus">Form Status</label>
                            <div class="input-group">
                                <select id="formstatus" name="formstatus" required>
                                    <option value="" disabled selected>Select Status</option>
                                    <option value="pending">Pending</option>
                                    <option value="approved">Approved</option>
                                    <option value="rejected">Rejected</option>
                                    <option value="returned">Returned</option>
                                </select>
                                <i class='bx bx-chevron-down'></i>
                            </div>
                        </div>
                        

                        <button type="submit" class="btn-submit">Save Changes</button>
                        

                    </form>
                </div>
            </div>
        </main>
    </section>

    <script>
    function softDeleteBorrower(borrowerId) {
        if (confirm('Are you sure you want to delete this record? This will move it to the deleted records section.')) {
            fetch('soft_delete_action.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=soft_delete&borrower_id=' + borrowerId
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Record deleted successfully!');
                    location.reload(); // Refresh the page
                } else {
                    alert('Error: ' + data.error);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while deleting the record');
            });
        }
    }

document.addEventListener("DOMContentLoaded", () => {
    // Department/Course conditional logic for superadmin form
    const departmentSelect = document.getElementById("department");
    const courseGroup = document.getElementById("courseGroup");
    const courseSelect = document.getElementById("course");

    function toggleCourseField() {
        const selectedDepartment = departmentSelect.value;
        
        if (selectedDepartment === "Faculty Member") {
            // Hide course field for faculty members
            courseGroup.style.display = "none";
            courseGroup.style.opacity = "0";
            courseSelect.removeAttribute("required");
            courseSelect.value = ""; // Clear the selection
        } else {
            // Show course field for students
            courseGroup.style.display = "block";
            courseGroup.style.opacity = "1";
            courseSelect.setAttribute("required", "required");
        }
    }

    // Add event listener for department change
    departmentSelect.addEventListener("change", toggleCourseField);

    const rows = document.querySelectorAll(".student-row");

    rows.forEach(row => {
    row.addEventListener("click", function () {
        const borrowerId = this.getAttribute("data-id");
        console.log("Selected row ID:", borrowerId);

        // Fetch the borrower data based on the ID
        fetch(`fetch_student_info.php?id=${borrowerId}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error("Failed to fetch borrower data");
                }
                return response.json();
            })
            .then(data => {
                if (data.error) {
                    console.error(data.error);
                } else {
                    console.log("Fetched data:", data);
                    // 👇 YOUR FORM FILLING LOGIC (already here)
                    document.getElementById("borrowform").value = data.id;
                    document.getElementById("idnum").value = data.idnum;
                    document.getElementById("firstname").value = data.firstname;
                    document.getElementById("middleinitial").value = data.middleinitial;
                    document.getElementById("lastname").value = data.lastname;
                    console.log("Department value from database:", data.department);
                    console.log("Department value type:", typeof data.department);
                    console.log("Department value length:", data.department ? data.department.length : 'null/undefined');
                    console.log("Department select element:", document.getElementById("department"));
                    console.log("Available department options:", Array.from(document.getElementById("department").options).map(opt => opt.value));
                    document.getElementById("department").value = data.department;
                    console.log("Department value after setting:", document.getElementById("department").value);
                    
                    // Handle course field - set to empty if null/undefined
                    if (data.course && data.course !== null && data.course !== '') {
                        document.getElementById("course").value = data.course;
                    } else {
                        document.getElementById("course").value = "";
                    }
                    document.getElementById("email").value = data.email;
                    document.getElementById("cpnnumber").value = data.cpnnumber;
                    // Handle borrow date
                    if (data.borrow_date && data.borrow_date !== "0000-00-00" && data.borrow_date !== null) {
                        document.getElementById("borrow_date").value = data.borrow_date;
                    } else {
                        document.getElementById("borrow_date").value = "";
                    }
                    
                    // Handle return date - fix the date format issue
                    if (data.return_date && data.return_date !== "0000-00-00" && data.return_date !== null) {
                        // Ensure proper date format for HTML date input (YYYY-MM-DD)
                        const returnDate = new Date(data.return_date);
                        if (!isNaN(returnDate.getTime())) {
                            document.getElementById("return_date").value = returnDate.toISOString().split('T')[0];
                        } else {
                            document.getElementById("return_date").value = "";
                        }
                    } else {
                        document.getElementById("return_date").value = "";
                    }
                    document.getElementById("consent").checked = data.consent == 1;
                    
                    // Set the form status dropdown to current status from database
                    document.getElementById("formstatus").value = data.status;

                    // ✅ 🔽 INSERT THIS HERE
                    fetch(`fetch_borrowed_items.php?form_id=${data.id}`)
                        .then(response => response.json())
                        .then(items => {
                            const tableBody = document.getElementById("borrowedItemsTable");
                            tableBody.innerHTML = ""; // Clear previous rows

                            items.forEach(item => {
                                const row = `<tr>
                                    <td>${item.item_name}</td>
                                    <td>${item.quantity} ${item.unit}</td>
                                </tr>`;
                                tableBody.insertAdjacentHTML("beforeend", row);
                            });
                        });

                    // Status update buttons removed - using form status dropdown instead
                }
            })
            .catch(error => console.error("Error fetching borrower data:", error));
    });
});


    // updateStatus function removed - status updates are now handled through the form submission

    function copyFormLink() {
        const formLink = "http://localhost/Try%20Lang/form.php";
        navigator.clipboard.writeText(formLink)
            .then(() => alert("Form link copied to clipboard!"))
            .catch(err => console.error("Failed to copy link: ", err));
    }

    window.copyFormLink = copyFormLink;

    // Filter functionality
    const filterBtn = document.getElementById("filterBtn");
    const filterGroup = document.getElementById("filterGroup");
    const filterOptions = document.querySelectorAll(".filter-option");
    const studentRows = document.querySelectorAll(".student-row");

    // Start with filter group hidden
    filterGroup.classList.add("hide");
    console.log("Initial hide class:", filterGroup.classList.contains("hide"));

    // Toggle filter group visibility
    filterBtn.addEventListener("click", function(e) {
        e.stopPropagation();
        filterGroup.classList.toggle("hide");
        console.log("Filter button clicked, hide class:", filterGroup.classList.contains("hide"));
    });

    // Hide filter group when clicking outside
    document.addEventListener("click", function(e) {
        if (!filterGroup.contains(e.target) && e.target !== filterBtn) {
            filterGroup.classList.add("hide");
        }
    });

    // Filter functionality - server-side filtering
    filterOptions.forEach(btn => {
        btn.addEventListener("click", function() {
            const status = this.getAttribute("data-status");
            
            if (status === "all") {
                window.location.href = "borrowform.php";
            } else {
                window.location.href = `borrowform.php?filter=${status}`;
            }
        });
    });

    // Auto-filter functionality when coming from dashboard
    function applyAutoFilter() {
        const urlParams = new URLSearchParams(window.location.search);
        const filterParam = urlParams.get('filter');
        
        if (filterParam) {
            // Find the corresponding filter button
            const targetButton = filterOptions.find(btn => btn.getAttribute("data-status") === filterParam);
            
            if (targetButton) {
                // Remove active class from all filter buttons
                filterOptions.forEach(b => b.classList.remove("active"));
                // Add active class to target button
                targetButton.classList.add("active");
                
                // Show the filter group
                filterGroup.classList.remove("hide");
            }
        }
    }

    // Apply auto-filter on page load - ensure DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', applyAutoFilter);
    } else {
        applyAutoFilter();
    }
    
    // Load borrowed items when editing
    <?php if ($editBorrowerData): ?>
    console.log('borrowform.php: Script loaded, editBorrowerData exists');
    document.addEventListener('DOMContentLoaded', function() {
        console.log('borrowform.php: DOMContentLoaded fired');
        const borrowerId = <?php echo $editBorrowerData['id']; ?>;
        console.log('borrowform.php: Loading borrowed items for borrower ID:', borrowerId);
        
        fetch(`fetch_borrowed_items.php?form_id=${borrowerId}`)
            .then(response => {
                console.log('borrowform.php: Response status:', response.status);
                return response.json();
            })
            .then(items => {
                console.log('borrowform.php: Borrowed items received:', items);
                const tableBody = document.getElementById("borrowedItemsTable");
                if (!tableBody) {
                    console.error('borrowform.php: Could not find borrowedItemsTable element');
                    return;
                }
                tableBody.innerHTML = ""; // Clear previous rows

                if (items && items.length > 0) {
                    items.forEach(item => {
                        console.log('borrowform.php: Processing item:', item);
                        const row = `<tr>
                            <td>${item.item_name}</td>
                            <td>${item.quantity} ${item.unit}</td>
                        </tr>`;
                        tableBody.insertAdjacentHTML("beforeend", row);
                    });
                } else {
                    console.log('borrowform.php: No items found');
                    tableBody.innerHTML = "<tr><td colspan='2' style='text-align: center; color: #666;'>No borrowed items found</td></tr>";
                }
            })
            .catch(error => {
                console.error("borrowform.php: Error loading borrowed items:", error);
                const tableBody = document.getElementById("borrowedItemsTable");
                if (tableBody) {
                    tableBody.innerHTML = "<tr><td colspan='2' style='text-align: center; color: #666;'>Error loading items</td></tr>";
                }
            });
    });
    
    // Fallback: also try to load items immediately if DOM is already ready
    if (document.readyState === 'loading') {
        console.log('borrowform.php: DOM still loading, waiting for DOMContentLoaded');
    } else {
        console.log('borrowform.php: DOM already ready, loading items immediately');
        const borrowerId = <?php echo $editBorrowerData['id']; ?>;
        loadBorrowedItems(borrowerId);
    }
    <?php endif; ?>
    
    // Helper function to load borrowed items
    function loadBorrowedItems(borrowerId) {
        console.log('borrowform.php: loadBorrowedItems called for ID:', borrowerId);
        fetch(`fetch_borrowed_items.php?form_id=${borrowerId}`)
            .then(response => {
                console.log('borrowform.php: Response status:', response.status);
                return response.json();
            })
            .then(items => {
                console.log('borrowform.php: Borrowed items received:', items);
                const tableBody = document.getElementById("borrowedItemsTable");
                if (!tableBody) {
                    console.error('borrowform.php: Could not find borrowedItemsTable element');
                    return;
                }
                tableBody.innerHTML = ""; // Clear previous rows

                if (items && items.length > 0) {
                    items.forEach(item => {
                        console.log('borrowform.php: Processing item:', item);
                        const row = `<tr>
                            <td>${item.item_name}</td>
                            <td>${item.quantity} ${item.unit}</td>
                        </tr>`;
                        tableBody.insertAdjacentHTML("beforeend", row);
                    });
                } else {
                    console.log('borrowform.php: No items found');
                    tableBody.innerHTML = "<tr><td colspan='2' style='text-align: center; color: #666;'>No borrowed items found</td></tr>";
                }
            })
            .catch(error => {
                console.error("borrowform.php: Error loading borrowed items:", error);
                const tableBody = document.getElementById("borrowedItemsTable");
                if (tableBody) {
                    tableBody.innerHTML = "<tr><td colspan='2' style='text-align: center; color: #666;'>Error loading items</td></tr>";
                }
            });
    }

    // Simple sort toggle functionality
    const sortBtn = document.getElementById('sortBtn');
    let isReversed = false; // Track current sort state

    // Toggle sort order
    sortBtn.addEventListener('click', function() {
        isReversed = !isReversed; // Toggle the state
        
        // Sort the table rows
        sortTableRows();
        
        // Update icon to show current state
        if (isReversed) {
            sortBtn.classList.add('reversed');
            sortBtn.title = "Newest First (Click to reverse)";
        } else {
            sortBtn.classList.remove('reversed');
            sortBtn.title = "Oldest First (Click to reverse)";
        }
    });

    // Function to sort table rows
    function sortTableRows() {
        const tbody = document.querySelector('.table-data .order table tbody');
        const rows = Array.from(tbody.querySelectorAll('.student-row'));
        
        rows.sort((a, b) => {
            const dateA = new Date(a.querySelector('td:nth-child(2)').textContent);
            const dateB = new Date(b.querySelector('td:nth-child(2)').textContent);
            
            if (isReversed) {
                return dateA - dateB; // Oldest first (reversed)
            } else {
                return dateB - dateA; // Newest first (normal)
            }
        });
        
        // Clear and re-append sorted rows
        rows.forEach(row => tbody.appendChild(row));
        
        console.log(`Sorted forms: ${isReversed ? 'Oldest first' : 'Newest first'}`);
    }

    // Search functionality
    const globalSearchForm = document.getElementById("globalSearchForm");
    const globalSearchInput = document.getElementById("globalSearchInput");

    if (globalSearchForm && globalSearchInput) {
        globalSearchForm.addEventListener("submit", function(e) {
            e.preventDefault();
            const query = globalSearchInput.value.trim().toLowerCase();
            
            studentRows.forEach(row => {
                const name = row.querySelector("td:first-child").textContent.toLowerCase();
                const status = row.querySelector("td:last-child").textContent.toLowerCase();
                
                if (name.includes(query) || status.includes(query)) {
                    row.style.display = "";
                } else {
                    row.style.display = "none";
                }
            });
        });

        // Live search as you type
        globalSearchInput.addEventListener("input", function() {
            const query = globalSearchInput.value.trim().toLowerCase();
            
            studentRows.forEach(row => {
                const name = row.querySelector("td:first-child").textContent.toLowerCase();
                const status = row.querySelector("td:last-child").textContent.toLowerCase();
                
                if (name.includes(query) || status.includes(query)) {
                    row.style.display = "";
                } else {
                    row.style.display = "none";
                }
            });
        });
    }

    // Notification functionality is now handled by notification.js
    
    // Populate form fields if borrower data is available in sessionStorage
    const borrowerData = sessionStorage.getItem('borrowerData');
    if (borrowerData) {
        try {
            const data = JSON.parse(borrowerData);
            console.log('Populating form with borrower data:', data);
            
            // Populate form fields
            const fields = {
                'id': data.id,
                'firstname': data.firstname,
                'lastname': data.lastname,
                'idnum': data.idnum,
                'department': data.department,
                'course': data.course,
                'email': data.email,
                'cpnnumber': data.cpnnumber
            };
            
            // Set values for each field
            Object.keys(fields).forEach(fieldName => {
                const field = document.getElementById(fieldName);
                if (field && fields[fieldName]) {
                    field.value = fields[fieldName];
                    console.log(`Set ${fieldName} to: ${fields[fieldName]}`);
                }
            });
            
            // Clear the sessionStorage after populating
            sessionStorage.removeItem('borrowerData');
            
        } catch (error) {
            console.error('Error parsing borrower data:', error);
        }
    }
});
</script>

<script src="script.js"></script>
<script src="notification.js"></script>
</body>
</html>
