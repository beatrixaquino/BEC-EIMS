<?php
// Include the database connection
include_once "dbconnect.php";

echo "<h2>Cleaning Up Duplicate Users</h2>";

// Find duplicate usernames
$sql = "SELECT username, COUNT(*) as count FROM users GROUP BY username HAVING COUNT(*) > 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<h3>Found duplicate usernames:</h3>";
    
    while($row = $result->fetch_assoc()) {
        $username = $row['username'];
        $count = $row['count'];
        
        echo "<p>Username '$username' appears $count times</p>";
        
        // Get all records for this username
        $sql2 = "SELECT * FROM users WHERE username = ? ORDER BY id";
        $stmt = $conn->prepare($sql2);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result2 = $stmt->get_result();
        
        echo "<table border='1'>";
        echo "<tr><th>ID</th><th>Username</th><th>Type</th><th>Status</th><th>Created</th></tr>";
        
        $first = true;
        while($user = $result2->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $user['id'] . "</td>";
            echo "<td>" . $user['username'] . "</td>";
            echo "<td>" . $user['acctype'] . "</td>";
            echo "<td>" . $user['status'] . "</td>";
            echo "<td>" . $user['created_at'] . "</td>";
            echo "</tr>";
            
            // Keep the first record, delete the rest
            if (!$first) {
                $delete_sql = "DELETE FROM users WHERE id = ?";
                $delete_stmt = $conn->prepare($delete_sql);
                $delete_stmt->bind_param("i", $user['id']);
                
                if ($delete_stmt->execute()) {
                    echo "<tr><td colspan='5' style='color: red;'>DELETED ID " . $user['id'] . "</td></tr>";
                } else {
                    echo "<tr><td colspan='5' style='color: red;'>ERROR deleting ID " . $user['id'] . ": " . $delete_stmt->error . "</td></tr>";
                }
                
                $delete_stmt->close();
            }
            
            $first = false;
        }
        echo "</table>";
        
        $stmt->close();
    }
} else {
    echo "<h3>No duplicate usernames found.</h3>";
}

// Show final state
echo "<h3>Final User List:</h3>";
$sql = "SELECT * FROM users ORDER BY id";
$result = $conn->query($sql);

echo "<table border='1'>";
echo "<tr><th>ID</th><th>Username</th><th>Type</th><th>Status</th><th>Created</th></tr>";

while($row = $result->fetch_assoc()) {
    echo "<tr>";
    echo "<td>" . $row['id'] . "</td>";
    echo "<td>" . $row['username'] . "</td>";
    echo "<td>" . $row['acctype'] . "</td>";
    echo "<td>" . $row['status'] . "</td>";
    echo "<td>" . $row['created_at'] . "</td>";
    echo "</tr>";
}
echo "</table>";

$conn->close();
?> 