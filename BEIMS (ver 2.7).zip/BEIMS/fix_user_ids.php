<?php
// Include the database connection
include_once "dbconnect.php";

echo "<h2>Checking User IDs</h2>";

// Check current users
$sql = "SELECT * FROM users ORDER BY id";
$result = $conn->query($sql);

echo "<h3>Current Users:</h3>";
echo "<table border='1'>";
echo "<tr><th>ID</th><th>Username</th><th>Type</th><th>Status</th><th>Created</th></tr>";

while($row = $result->fetch_assoc()) {
    echo "<tr>";
    echo "<td>" . $row['id'] . "</td>";
    echo "<td>" . $row['username'] . "</td>";
    echo "<td>" . $row['acctype'] . "</td>";
    echo "<td>" . $row['status'] . "</td>";
    echo "<td>" . $row['created_at'] . "</td>";
    echo "</tr>";
}
echo "</table>";

// Check if there are any records with ID 0
$sql = "SELECT COUNT(*) as count FROM users WHERE id = 0";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

if ($row['count'] > 0) {
    echo "<h3>Found " . $row['count'] . " records with ID 0. These need to be fixed.</h3>";
    
    // Get the next available ID
    $sql = "SELECT MAX(id) as max_id FROM users";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $next_id = $row['max_id'] + 1;
    
    echo "<p>Next available ID: " . $next_id . "</p>";
    
    // Update records with ID 0
    $sql = "UPDATE users SET id = ? WHERE id = 0 LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $next_id);
    
    if ($stmt->execute()) {
        echo "<p>Updated one record with ID 0 to ID " . $next_id . "</p>";
    } else {
        echo "<p>Error updating record: " . $stmt->error . "</p>";
    }
    
    $stmt->close();
} else {
    echo "<h3>No records with ID 0 found.</h3>";
}

$conn->close();
?> 